"""Chart for the 2026-27 outlook: model probability for each state, marked by the rule.
Usage: python outlook_chart.py outlook/outlook_2026_27.csv outlook/outlook_2026_27.png"""
import csv, sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

src, dst = sys.argv[1:3]
INK, TEAL, GREY, AMBER = '#17383a', '#286d62', '#9aa5a2', '#b5651d'
rows = list(csv.DictReader(open(src, encoding='utf-8')))
yes = sorted([r for r in rows if r['outlook_rule'] == 'likely'], key=lambda r: -float(r['rate_per_million_2025_26']))
no = sorted([r for r in rows if r['outlook_rule'] != 'likely'], key=lambda r: -float(r['model_probability_any']))
N = max(len(yes), len(no))
tx = [r for r in rows if r['state'] == 'Texas'][0]
fig, axes = plt.subplots(1, 2, figsize=(13.33, 7.5), sharex=True)
titles = (f'PEN recorded a count in 2025-26 ({len(yes)} states)\nordered by 2025-26 rate*; count in brackets',
          f'PEN recorded no count in 2025-26 ({len(no)} states)\nordered by model probability')
for ax, part, ttl in zip(axes, (yes, no), titles):
    ax.set_title(ttl, loc='left', fontsize=10.5, color=INK, x=-0.25)
    for k, r in enumerate(part):
        y = N - k; p = float(r['model_probability_any'])
        likely = r['outlook_rule'] == 'likely'
        hist = bool(r['note'])
        ax.plot([0, p], [y, y], color='#e3e9e7', lw=1.5, zorder=1)
        if likely:
            ax.scatter(p, y, s=70, color=TEAL, edgecolor='white', linewidth=1.5, zorder=3)
        else:
            ax.scatter(p, y, s=70, facecolor='white', edgecolor=AMBER if hist else GREY, linewidth=2, zorder=3)
        lab = r['state'] + (f'  ({int(r["recorded_2025_26"]):,})' if likely else '')
        ax.text(-0.02, y, lab, ha='right', va='center', fontsize=9.5, color=INK)
    ax.axvline(0.5, color='#7d8b88', lw=1, ls=(0, (4, 3)), zorder=0)
    ax.set_xlim(0, 0.7); ax.set_ylim(N - max(len(yes), len(no)) + 0.3, N + 0.7); ax.set_yticks([])
    for s in ('top', 'right', 'left'):
        ax.spines[s].set_visible(False)
    ax.spines['bottom'].set_color('#c3c9c7'); ax.tick_params(axis='x', colors='#46645f', labelsize=9)
    ax.set_xlabel('Model probability of any PEN-recorded ban in 2026-27', fontsize=9.5, color='#46645f')
fig.suptitle('2026-27 outlook as of November 17, 2026: past recorded status first, model alongside',
             x=0.02, ha='left', fontsize=14, color=INK, fontweight='bold')
fig.text(0.02, 0.905, 'The rule expects each state\'s 2025-26 status to repeat. Dots show the model\'s probability for the same state; '
         'dashed line = 0.5. Agreement between the two does not show either is right.', fontsize=9.5, color='#46645f')
handles = [Line2D([], [], marker='o', ls='', ms=8, mfc=TEAL, mec='white', label='Count in 2025-26'),
           Line2D([], [], marker='o', ls='', ms=8, mfc='white', mec=AMBER, mew=2, label='No 2025-26 count; entries in 2022-23'),
           Line2D([], [], marker='o', ls='', ms=8, mfc='white', mec=GREY, mew=2, label='No count in either year')]
fig.legend(handles=handles, loc='lower left', ncol=3, frameon=False, fontsize=9.5, bbox_to_anchor=(0.02, 0.05))
fig.text(0.02, 0.012, f'*Rate = 2025-26 instances per million, ACS 5-year 2019-23 population (the descriptive map uses the 2025 estimate: '
         f'Texas {float(tx["rate_per_million_2025_26"]):.1f} here, {float(tx["rate_per_million_2025_26_map"]):.1f} on the map; same {int(tx["recorded_2025_26"]):,} instances).\n'
         'Model: negative binomial, population offset + 2024 presidential margin, fitted to PEN 2025-26. Covers where PEN records bans, not where bans occur. '
         'In the 2022-23 to 2025-26 test the rule scored 36/50, the model 27/50.',
         ha='left', fontsize=8, color='#46645f')
plt.subplots_adjust(left=0.13, right=0.98, top=0.80, bottom=0.17, wspace=0.42)
fig.savefig(dst, dpi=200)
