"""Extract 2020 presidential margin by state from FEC 'Federal Elections 2020' (Excel).
Sheet '3. Table 2 Electoral & Pop Vote': columns D Biden, E Trump, F All Others, G Total Vote.
Margin = 100 * (Trump - Biden) / total votes, all candidates in the denominator (as for 2024).
Usage: python fec2020.py federalelections2020.xlsx STATE_2025_26_CSV margin_2020.csv"""
import csv, re, sys
import openpyxl
xlsx, st_csv, out = sys.argv[1:4]
abbr = {r['abbreviation']: r['state'] for r in csv.DictReader(open(st_csv, encoding='utf-8'))}
ws = openpyxl.load_workbook(xlsx, read_only=True, data_only=True)['3. Table 2 Electoral & Pop Vote']
rows, total = [], None
for r in ws.iter_rows(values_only=True):
    # 'ME*' and 'NE*': asterisk marks split electoral votes; popular votes are statewide.
    a = r[0].strip().rstrip('*') if isinstance(r[0], str) else r[0]
    if isinstance(a, str) and re.fullmatch(r'[A-Z]{2}', a):
        biden, trump, other, tot = (int(v) for v in r[3:7])
        assert biden + trump + other == tot, a
        rows.append((a, biden, trump, other, tot))
    elif isinstance(a, str) and a == 'Total:':
        total = tuple(int(v) for v in r[3:7])
assert len(rows) == 51, len(rows)
assert tuple(sum(x[i] for x in rows) for i in range(1, 5)) == total, 'state rows do not sum to the published total'
assert total == (81283501, 74223975, 2922155, 158429631)
with open(out, 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f); w.writerow(['state', 'abbreviation', 'biden_votes', 'trump_votes', 'other_votes', 'total_votes', 'republican_margin_pp'])
    for a, b, t, o, tot in rows:
        if a == 'DC':
            continue
        w.writerow([abbr[a], a, b, t, o, tot, round(100 * (t - b) / tot, 6)])
print('wrote', out, '| 50 states; state rows sum to FEC national totals')
