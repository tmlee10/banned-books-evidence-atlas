"""First forecast check: fit on 2022-23, predict 2025-26, compare with simple rules.

Every predictor is limited to what was public before the school year began:

  fit year 2022-23 (began July 2022)        test year 2025-26 (began July 2025)
  population  ACS 5-yr 2016-20 (Mar 2022)   ACS 5-yr 2019-23 (Dec 2024)
  demography  ACS 5-yr 2016-20 (Mar 2022)   ACS 5-yr 2019-23 (Dec 2024)
  urban share 2010 Census                   2020 Census (released 2023)
  election    2020 presidential margin      2024 presidential margin

Outcomes: PEN-recorded instances by state, 2022-23 (retained event index) and
2025-26 (published state map). The two come from different PEN sources with
different coverage, so this is a first check, not a validation.

Models (negative binomial, log population offset; nothing is fitted on 2025-26):
  pop       intercept only
  margin    + election margin per 10 points            (needs --margin2020)
  margin+D  + margin + one demographic measure, each measure tried separately
  D         + one demographic measure (no margin)
Demographic measures are standardised within each year (mean 0, sd 1 across the
50 states), so inflation and survey-level shifts do not move them.

Simple rules (baselines), using only 2022-23 outcomes:
  repeat    yes/no scores: a state records bans in 2025-26 if it did in 2022-23;
            ranking scores (spearman, top10): states ranked by their 2022-23 rate,
            because a yes/no rule cannot rank states
  base rate every state gets the 2022-23 share of states with bans (33/50)

Scores on 2025-26:
  accuracy   share of states whose any/none status is predicted correctly (0.5 cut-off)
  brier      mean squared error of the probability of any recorded ban (lower is better)
  auc        chance a state with bans is ranked above one without (0.5 = no skill);
             unaffected by the overall level, which tripled between the two years
  spearman   rank correlation of predicted and recorded rates, all 50 states
  top10      how many of the predicted ten highest-rate states are in the actual top ten
             (spearman and top10 are not applicable to the population-only model, which
             predicts the same rate in every state)

Usage:
  python forecast_test.py STATE_2022_23_CSV STATE_2025_26_CSV CENSUS_DIRS_JSON OUT_DIR [MARGIN_2020_CSV]
"""
import csv, json, os, re, sys
import numpy as np
from scipy.optimize import minimize
from scipy.special import gammaln, digamma

a22, a25, dirs_json, out = sys.argv[1:5]
m20_path = sys.argv[5] if len(sys.argv) > 5 else None
os.makedirs(out, exist_ok=True)
DIRS = json.load(open(dirs_json))
EXCL = ('District of Columbia', 'Puerto Rico')
NOTES = set()


def table(dirkey, name, wanted):
    d = DIRS[dirkey]
    meta = list(csv.reader(open(os.path.join(d, f'{name}-Column-Metadata.csv'), encoding='utf-8-sig')))
    codes = {}
    for k, pat in wanted.items():
        hits = [c for c, l in meta if re.fullmatch(pat, l)]
        assert hits, (name, pat)
        codes[k] = hits[0]
    rows = list(csv.DictReader(open(os.path.join(d, f'{name}-Data.csv'), encoding='utf-8-sig')))[1:]
    def num(v):
        # 2010 Census cells can carry a revision note, e.g. '4779736(r38235)'; the published
        # figure is the leading number and the note references a later count-question revision.
        m = re.match(r'^-?\d+(\.\d+)?', v)
        assert m, (name, v)
        if m.end() != len(v):
            NOTES.add(f'{name}: {v}')
        return float(m.group(0))
    res = {r['NAME']: {k: num(r[c]) for k, c in codes.items()} for r in rows if r['NAME'] not in EXCL}
    assert len(res) == 50, (name, len(res))
    return res, codes


DP05 = {'population': r'Estimate!!SEX AND AGE!!Total population',
        'under_18': r'Percent!!SEX AND AGE!!Total population!!Under 18 years',
        'hispanic': r'Percent!!HISPANIC OR LATINO AND RACE!!Total population!!Hispanic or Latino \(of any race\)',
        'white_nh': r'Percent!!HISPANIC OR LATINO AND RACE!!Total population!!Not Hispanic or Latino!!White alone',
        'black_nh': r'Percent!!HISPANIC OR LATINO AND RACE!!Total population!!Not Hispanic or Latino!!Black or African American alone'}
DP02 = {'bachelors': r"Percent!!EDUCATIONAL ATTAINMENT!!Population 25 years and over!!Bachelor's degree or higher"}
DP03 = {'median_income': r'Estimate!!INCOME AND BENEFITS \(IN \d{4} INFLATION-ADJUSTED DOLLARS\)!!Total households!!Median household income \(dollars\)'}
MEASURES = ['white_nh', 'hispanic', 'black_nh', 'under_18', 'bachelors', 'median_income', 'urban']
LABEL = {'white_nh': 'White, not Hispanic', 'hispanic': 'Hispanic or Latino', 'black_nh': 'Black, not Hispanic',
         'under_18': 'Under 18', 'bachelors': "Bachelor's degree or higher", 'median_income': 'Median household income',
         'urban': 'Urban residents'}


def year_inputs(acs_year, urban_table, urban_cols):
    d = {}
    for key, name, wanted in [('DP05', f'ACSDP5Y{acs_year}.DP05', DP05), ('DP02', f'ACSDP5Y{acs_year}.DP02', DP02),
                              ('DP03', f'ACSDP5Y{acs_year}.DP03', DP03)]:
        t, _ = table(key, name, wanted)
        for s, v in t.items():
            d.setdefault(s, {}).update(v)
    u, _ = table('P2', urban_table, urban_cols)
    for s, v in u.items():
        d[s]['urban'] = 100 * v['urban'] / v['total']
    return d


X22 = year_inputs('2020', 'DECENNIALSF12010.P2', {'total': r'Total', 'urban': r'Total!!Urban'})
X25 = year_inputs('2023', 'DECENNIALDHC2020.P2', {'total': r' !!Total:', 'urban': r' !!Total:!!Urban'})

y22 = {r['state']: int(r['event_rows']) for r in csv.DictReader(open(a22, encoding='utf-8'))}
b25 = list(csv.DictReader(open(a25, encoding='utf-8')))
y25 = {r['state']: int(r['instances']) for r in b25}
m24 = {r['state']: float(r['republican_margin_pp']) for r in b25}
m20 = None
if m20_path:
    m20 = {r['state']: float(r['republican_margin_pp']) for r in csv.DictReader(open(m20_path, encoding='utf-8'))}
    assert len(m20) == 50
assert sum(y22.values()) == 3362 and sum(y25.values()) == 11982
STATES = sorted(y25)
assert set(STATES) == set(y22) == set(X22) == set(X25)


def z(vals):
    v = np.asarray(vals, float); return (v - v.mean()) / v.std()


def design(X, margin, cols):
    pop = np.array([X[s]['population'] for s in STATES])
    parts = [np.ones(len(STATES))]
    for c in cols:
        if c == 'margin':
            parts.append(np.array([margin[s] for s in STATES]) / 10)
        else:
            parts.append(z([X[s][c] for s in STATES]))
    return np.column_stack(parts), np.log(pop / 1e6), pop


def nb_fit(x, off, y):
    p = x.shape[1]

    def nll(t):
        eta = np.clip(off + x @ t[:p], -40, 40); mu = np.exp(eta); size = np.exp(-t[-1])
        return -(gammaln(y + size) - gammaln(size) - gammaln(y + 1) + size * (np.log(size) - np.log(size + mu))
                 + y * (eta - np.log(size + mu))).sum()

    def grad(t):
        mu = np.exp(np.clip(off + x @ t[:p], -40, 40)); size = np.exp(-t[-1])
        gb = x.T @ ((mu - y) / (1 + mu / size))
        ds = digamma(y + size) - digamma(size) + np.log(size) + 1 - np.log(size + mu) - (size + y) / (size + mu)
        return np.r_[gb, size * ds.sum()]

    b = np.zeros(p); b[0] = np.log(max(y.sum(), .1) / np.exp(off).sum())
    sols = [minimize(nll, np.r_[b, np.log(a)], jac=grad, method='L-BFGS-B',
                     bounds=[(-30, 30)] * p + [(-10, 10)], options={'maxiter': 3000, 'ftol': 1e-12, 'gtol': 1e-7})
            for a in [1, 10, 40]]
    ok = [s for s in sols if s.success and np.isfinite(s.fun)]
    assert ok, [s.message for s in sols]
    r = min(ok, key=lambda s: s.fun)
    assert all(-10 + 1e-4 < r.x[-1] < 10 - 1e-4 for _ in [0]), 'dispersion at bound'
    return r.x, -r.fun


def p_any(mu, alpha):
    return 1 - (1 + alpha * mu) ** (-1 / alpha)


def spearman(a, b):
    from scipy.stats import spearmanr
    return float(spearmanr(a, b).statistic)


def auc(score, actual):
    pos = [s for s, a in zip(score, actual) if a]; neg = [s for s, a in zip(score, actual) if not a]
    tot = 0.0
    for p in pos:
        for n in neg:
            tot += 1 if p > n else (0.5 if p == n else 0)
    return tot / (len(pos) * len(neg))


def top10(pred_rate, act_rate):
    tp = set(np.argsort(-np.asarray(pred_rate), kind='stable')[:10]); ta = set(np.argsort(-np.asarray(act_rate), kind='stable')[:10])
    return len(tp & ta)


yv22 = np.array([y22[s] for s in STATES], float)
yv25 = np.array([y25[s] for s in STATES], float)
any25 = yv25 > 0
pop25 = np.array([X25[s]['population'] for s in STATES])
act_rate25 = yv25 / pop25 * 1e6
pop22 = np.array([X22[s]['population'] for s in STATES])
rate22 = yv22 / pop22 * 1e6

results = []
# baselines
status = (yv22 > 0).astype(float)
base = np.full(50, (yv22 > 0).mean())
results.append(dict(model='Rule: repeat 2022-23 status or rate', predictors='2022-23 status (yes/no scores); 2022-23 rate (ranking scores)',
                    accuracy=float(((status > .5) == any25).mean()), brier=float(((status - any25) ** 2).mean()),
                    auc=auc(status, any25), spearman=spearman(rate22, act_rate25), top10=top10(rate22, act_rate25)))
results.append(dict(model='Rule: base rate for every state', predictors=f'{int((yv22 > 0).sum())}/50 from 2022-23',
                    accuracy=float(((base > .5) == any25).mean()), brier=float(((base - any25) ** 2).mean()),
                    auc=0.5, spearman=float('nan'), top10=float('nan')))

specs = [('Model: population only', [])]
if m20:
    specs.append(('Model: + election margin', ['margin']))
    specs += [(f'Model: + margin + {LABEL[m]}', ['margin', m]) for m in MEASURES]
specs += [(f'Model: + {LABEL[m]} (no margin)', [m]) for m in MEASURES]

preds = {}
for name, cols in specs:
    x22, off22, _ = design(X22, m20, cols)
    theta, ll = nb_fit(x22, off22, yv22)
    p = x22.shape[1]; alpha = float(np.exp(theta[-1]))
    x25, off25, _ = design(X25, m24, cols)
    mu25 = np.exp(off25 + x25 @ theta[:p])
    pa = p_any(mu25, alpha)
    pr = mu25 / pop25 * 1e6
    preds[name] = dict(mu=mu25, p_any=pa)
    # With no covariates every state gets the same predicted rate, so a rank correlation
    # or top-ten pick would only order floating-point ties: report those as not applicable.
    ranks_ok = (pr.max() - pr.min()) > 1e-9 * pr.max()
    coef = {c: float(theta[i + 1]) for i, c in enumerate(cols)}
    results.append(dict(model=name, predictors=', '.join(cols) or 'population',
                        accuracy=float(((pa > .5) == any25).mean()), brier=float(((pa - any25) ** 2).mean()),
                        auc=auc(pa, any25),
                        spearman=spearman(pr, act_rate25) if ranks_ok else float('nan'),
                        top10=top10(pr, act_rate25) if ranks_ok else float('nan'),
                        fit_loglik_2022_23=ll, alpha=alpha, coefficients=json.dumps({k: round(v, 3) for k, v in coef.items()}),
                        predicted_total_2025_26=float(mu25.sum())))

keys = ['model', 'predictors', 'accuracy', 'brier', 'auc', 'spearman', 'top10', 'fit_loglik_2022_23', 'alpha',
        'coefficients', 'predicted_total_2025_26']
with open(os.path.join(out, 'forecast_scorecard.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=keys); w.writeheader()
    for r in results:
        w.writerow({k: (round(v, 4) if isinstance(v, float) else v) for k, v in r.items()})

# per-state predictions for the main models
main = [n for n, _ in specs if n in ('Model: population only', 'Model: + election margin')]
with open(os.path.join(out, 'forecast_states_2025_26.csv'), 'w', newline='', encoding='utf-8') as f:
    cols = ['state', 'recorded_2022_23', 'recorded_2025_26', 'any_2025_26'] + \
           [f'{n} | {k}' for n in main for k in ('predicted_instances', 'p_any')]
    w = csv.writer(f); w.writerow(cols)
    for i, s in enumerate(STATES):
        w.writerow([s, int(yv22[i]), int(yv25[i]), int(any25[i])] +
                   [round(float(preds[n][k][i]), 4) for n in main for k in ('mu', 'p_any')])

L = ['First forecast check: fit on 2022-23, predict 2025-26', '',
     f'2022-23: {int(yv22.sum()):,} recorded instances, {int((yv22 > 0).sum())} states with any. '
     f'2025-26: {int(yv25.sum()):,} instances, {int(any25.sum())} states with any.',
     'Election margin: ' + ('2020 for the fit, 2024 for the prediction.' if m20 else 'NOT INCLUDED (2020 results not supplied yet).'), '',
     f'{"":44s} {"accuracy":>8s} {"brier":>6s} {"auc":>5s} {"rho":>5s} {"top10":>5s} {"pred. total":>11s}']
for r in results:
    tot = f'{r["predicted_total_2025_26"]:,.0f}' if 'predicted_total_2025_26' in r else ''
    rho = '' if r['spearman'] != r['spearman'] else f'{r["spearman"]:.2f}'
    t10 = '' if r['top10'] != r['top10'] else f'{int(r["top10"])}'
    L.append(f'{r["model"]:44s} {r["accuracy"] * 50:5.0f}/50 {r["brier"]:6.3f} {r["auc"]:5.2f} {rho:>5s} {t10:>5s} {tot:>11s}')
L += ['', 'accuracy: states whose any/none status was predicted correctly (probability cut-off 0.5).',
      'brier: mean squared error of the probability of any recorded ban; lower is better.',
      'auc: chance a state with bans is ranked above one without; 0.5 = no better than chance.',
      'rho: rank correlation of predicted and recorded 2025-26 rates. top10: overlap with the actual top ten.',
      'For the rule, yes/no scores use 2022-23 status and ranking scores use 2022-23 rates.',
      'Blank rho/top10 for population only: it predicts the same rate everywhere, so it cannot rank states.',
      'Seven demographic measures are each tried separately and all are reported; one may score well by chance.',
      'Under 18 stood out in the 2025-26 profile, which uses the test-year outcome, so a good result for it',
      'should be read with extra caution.']
L += ['', f'Census cells with revision notes (leading published figure used): {len(NOTES)}'] + sorted('  ' + n for n in NOTES)
open(os.path.join(out, 'forecast_summary.txt'), 'w', encoding='utf-8').write('\n'.join(L) + '\n')
print('\n'.join(L))
