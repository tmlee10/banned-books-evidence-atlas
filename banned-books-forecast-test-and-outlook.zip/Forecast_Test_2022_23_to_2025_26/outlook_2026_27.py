"""2026-27 outlook as of November 17, 2026.

Primary: repeat each state's 2025-26 recorded status (yes/no) and rank by its
2025-26 rate, the approach that scored best in the 2022-23 -> 2025-26 test.
Alongside: the population + election-margin model (negative binomial, log
population offset), fitted to 2025-26 outcomes with predictors public before
2025-26 began, then applied to predictors public before 2026-27 began.

                 fit on 2025-26 outcomes            apply to 2026-27
  population     ACS 5-year 2019-23 (Dec 2024)      ACS 5-year 2020-24 (Dec 2025)
  election       2024 presidential margin           2024 presidential margin

PEN's 2025-26 results became available after the 2026-27 school year began, so this is an outlook as of November 17, 2026, not a forecast
that could have been issued before the school year started. It concerns where
PEN will record bans, not where bans will or will not occur.

Usage: python outlook_2026_27.py STATE_2022_23_CSV STATE_2025_26_CSV CENSUS_DIR OUT_DIR
"""
import csv, os, re, sys
import numpy as np
from scipy.optimize import minimize
from scipy.special import gammaln, digamma

a22, a25, cdir, out = sys.argv[1:5]
os.makedirs(out, exist_ok=True)
EXCL = ('District of Columbia', 'Puerto Rico')


def acs_pop(year):
    name = f'ACSDP5Y{year}.DP05'
    meta = list(csv.reader(open(os.path.join(cdir, f'{name}-Column-Metadata.csv'), encoding='utf-8-sig')))
    code = [c for c, l in meta if l == 'Estimate!!SEX AND AGE!!Total population'][0]
    rows = list(csv.DictReader(open(os.path.join(cdir, f'{name}-Data.csv'), encoding='utf-8-sig')))[1:]
    d = {r['NAME']: float(r[code]) for r in rows if r['NAME'] not in EXCL}
    assert len(d) == 50
    return d


y22 = {r['state']: int(r['event_rows']) for r in csv.DictReader(open(a22, encoding='utf-8'))}
b25 = list(csv.DictReader(open(a25, encoding='utf-8')))
STATES = sorted(r['state'] for r in b25)
y25 = {r['state']: int(r['instances']) for r in b25}
ab = {r['state']: r['abbreviation'] for r in b25}
m24 = {r['state']: float(r['republican_margin_pp']) for r in b25}
map_rate = {r['state']: float(r['instances_per_million']) for r in b25}   # 2025 population estimate, as on the map
pop_fit, pop_out = acs_pop('2023'), acs_pop('2024')
assert sum(y25.values()) == 11982 and sum(1 for v in y25.values() if v) == 23


def nb_fit(x, off, y):
    p = x.shape[1]

    def nll(t):
        eta = off + x @ t[:p]; mu = np.exp(eta); size = np.exp(-t[-1])
        return -(gammaln(y + size) - gammaln(size) - gammaln(y + 1) + size * (np.log(size) - np.log(size + mu))
                 + y * (eta - np.log(size + mu))).sum()

    def grad(t):
        mu = np.exp(off + x @ t[:p]); size = np.exp(-t[-1])
        gb = x.T @ ((mu - y) / (1 + mu / size))
        ds = digamma(y + size) - digamma(size) + np.log(size) + 1 - np.log(size + mu) - (size + y) / (size + mu)
        return np.r_[gb, size * ds.sum()]

    b = np.zeros(p); b[0] = np.log(y.sum() / np.exp(off).sum())
    sols = [minimize(nll, np.r_[b, np.log(a)], jac=grad, method='L-BFGS-B', bounds=[(-30, 30)] * p + [(-10, 10)],
                     options={'maxiter': 3000, 'ftol': 1e-12, 'gtol': 1e-7}) for a in [1, 10, 40]]
    r = min((s for s in sols if s.success), key=lambda s: s.fun)
    return r.x


def X(pop):
    return (np.column_stack([np.ones(50), [m24[s] / 10 for s in STATES]]),
            np.log(np.array([pop[s] for s in STATES]) / 1e6))


y = np.array([y25[s] for s in STATES], float)
x_fit, off_fit = X(pop_fit)
theta = nb_fit(x_fit, off_fit, y)
alpha = float(np.exp(theta[-1]))
x_out, off_out = X(pop_out)
mu = np.exp(off_out + x_out @ theta[:2])
p_any = 1 - (1 + alpha * mu) ** (-1 / alpha)
rate_model = mu / np.exp(off_out)          # per million
rate25 = np.array([y25[s] / pop_fit[s] * 1e6 for s in STATES])

order_rule = sorted(range(50), key=lambda i: (-rate25[i], STATES[i]))
rank_rule = {i: (order_rule.index(i) + 1 if rate25[i] > 0 else None) for i in range(50)}
order_model = sorted(range(50), key=lambda i: (-p_any[i], STATES[i]))
rank_model = {i: order_model.index(i) + 1 for i in range(50)}

rows = []
for i, s in enumerate(STATES):
    rule_yes = y25[s] > 0
    model_yes = p_any[i] > 0.5
    if rule_yes and model_yes:
        agree = 'both: likely'
    elif not rule_yes and not model_yes:
        agree = 'both: unlikely'
    elif rule_yes:
        agree = 'rule yes, model no'
    else:
        agree = 'model yes, rule no'
    note = ''
    if not rule_yes and y22[s] > 0:
        note = 'no 2025-26 count, but entries in 2022-23'
        if model_yes:
            note += '; methods disagree: monitor'
    rows.append({'state': s, 'abbreviation': ab[s], 'recorded_2022_23': y22[s], 'recorded_2025_26': y25[s],
                 'rate_per_million_2025_26': round(rate25[i], 2),
                 'rate_per_million_2025_26_map': round(map_rate[s], 2),
                 'outlook_rule': 'likely' if rule_yes else 'not expected',
                 'rule_rank_by_2025_26_rate': rank_rule[i] or '',
                 'model_probability_any': round(float(p_any[i]), 3),
                 'model_rank': rank_model[i],
                 'model_expected_instances': round(float(mu[i]), 1),
                 'rule_and_model': agree, 'note': note})

rows.sort(key=lambda r: (r['outlook_rule'] != 'likely', r['rule_rank_by_2025_26_rate'] or 99, -r['model_probability_any']))
with open(os.path.join(out, 'outlook_2026_27.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

from collections import Counter
cnt = Counter(r['rule_and_model'] for r in rows)
L = ['2026-27 outlook as of November 17, 2026', '',
     'Primary: repeat 2025-26 recorded status; rank by 2025-26 rate. Alongside: population + 2024 margin model.',
     f'Model fitted to 2025-26: margin coefficient {theta[1]:.3f} per 10 points (rate ratio {np.exp(theta[1]):.2f}), dispersion {alpha:.2f}.', '',
     'Rate denominator: rate_per_million_2025_26 divides PEN\'s 2025-26 instances by the ACS 5-year 2019-23',
     'population (the figure available before 2025-26 began). The descriptive map divides the same instances',
     'by the 2025 population estimate (rate_per_million_2025_26_map); e.g. Texas 8,193 instances = '
     f'{y25["Texas"] / pop_fit["Texas"] * 1e6:.1f} per million here, {map_rate["Texas"]:.1f} on the map.', '',
     f'Rule: {sum(1 for r in rows if r["outlook_rule"] == "likely")} states with a PEN count in 2025-26 (expected to repeat); 27 with none.',
     'Agreement between rule and model (model "yes" = probability above 0.5). Agreement between two',
     'predictions does not show that either is right:'] + \
    [f'  {v:2d}  {k}' for k, v in sorted(cnt.items())] + ['',
     f'{"State":16s} {"25-26":>6s} {"rate":>7s} {"rule":>13s} {"model p":>8s}  agreement']
for r in rows:
    L.append(f'{r["state"]:16s} {r["recorded_2025_26"]:6d} {r["rate_per_million_2025_26"]:7.2f} {r["outlook_rule"]:>13s} '
             f'{r["model_probability_any"]:8.3f}  {r["rule_and_model"]}{"  (" + r["note"] + ")" if r["note"] else ""}')
big = [s for s in STATES if y22[s] >= 100]; small = [s for s in STATES if 0 < y22[s] < 100]
new = [s for s in STATES if y25[s] and not y22[s]]
L += ['', 'How the rule fared last time (2022-23 -> 2025-26):',
      f'  states with 100+ entries in 2022-23: {sum(1 for s in big if y25[s])} of {len(big)} recorded again',
      f'  states with 1-99 entries in 2022-23: {sum(1 for s in small if y25[s])} of {len(small)} recorded again',
      f'  states new in 2025-26: {len(new)} ({", ".join(new)})',
      f'  So the rule is firmest for the 2025-26 states with 100+ entries: '
      f'{", ".join(s for s in STATES if y25[s] >= 100)}.',
      f'Worth monitoring (earlier entries, no 2025-26 count, methods disagree; not validated predictions): '
      f'{", ".join(r["state"] for r in rows if "monitor" in r["note"])}.',
      f'Model probabilities range {p_any.min():.2f}-{p_any.max():.2f}; none is far above 0.5, so model "yes" is weak.']
L += ['', 'This is an outlook for where PEN will record bans in 2026-27, as of November 17, 2026. It uses PEN\'s',
      '2025-26 results, which became available after the school year began. In the one test available, the rule beat the',
      'model (36 vs 27 of 50 states), and coverage differs between PEN\'s years. A state marked "not expected"',
      'may still have bans that PEN does not record. It cannot reliably name new states: only two appeared',
      'between 2022-23 and 2025-26.']
open(os.path.join(out, 'outlook_summary.txt'), 'w', encoding='utf-8').write('\n'.join(L) + '\n')
print('\n'.join(L))
