First forecast check (fit on 2022-23, predict 2025-26) and
2026-27 outlook as of November 17, 2026
Prepared November 17, 2026

QUESTION
  Using only information public before each school year began, does a model
  fitted to 2022-23 predict where PEN recorded school book bans in 2025-26
  better than simply assuming each state's 2022-23 status repeats?

PREDICTORS (public before the school year began)
                fit: 2022-23 (began July 2022)       test: 2025-26 (began July 2025)
  population    ACS 5-year 2016-20 (March 2022)       ACS 5-year 2019-23 (December 2024)
  demographics  ACS 5-year 2016-20                    ACS 5-year 2019-23
  urban share   2010 Census                           2020 Census (released 2023)
  election      2020 presidential margin (FEC)        2024 presidential margin (FEC)
  Margins use all candidates in the denominator. The 2020 state rows in the
  FEC workbook sum exactly to its published national totals. Demographic
  measures are standardised within each year. Nothing is fitted on 2025-26.

OUTCOMES
  PEN-recorded instances by state: 2022-23 from the retained event index
  (3,362; 33 states with any), 2025-26 from PEN's published state map
  (11,982; 23 states with any). The sources differ in coverage, so this is a
  first check on one pair of years, not proof of forecasting reliability.

RESULT (results/forecast_summary.txt has the full table)
                                     any/none   rank   top-ten
                                     correct    rho    overlap
  Rule: repeat 2022-23 status or rate  36/50    0.51      5
  Model: population only               23/50    n/a      n/a
  Model: + election margin             27/50    0.23      3
  Model: + margin + one demographic    26-28/50 0.21-0.29 3-4
  Model: one demographic, no margin    23-26/50 -0.14-0.28 1-3

  - For the rule, the yes/no score uses 2022-23 status and the ranking scores
    use 2022-23 rates; a yes/no rule alone cannot rank states.
  - The population-only model predicts the same rate in every state, so it has
    no ranking (n/a).
  - Adding the election margin improves status accuracy (23 to 27 of 50) and
    gives a ranking (rho 0.23). Its probability score is slightly worse
    (Brier 0.259 to 0.261; lower is better).
  - The margin model predicted Ohio and Maryland, the two states with a 2025-26
    count and no 2022-23 entry, which the rule missed. It also predicted a
    count in 11 states where PEN recorded none and the rule was right
    (Alabama, Alaska, Arizona, Connecticut, Illinois, Louisiana, Mississippi,
    Montana, Nevada, New Mexico, Washington).
  - No model beats the simple rule on getting each state's status right, on
    ranking states, or on picking the top ten.
  - Adding a demographic measure changes little. The best (urban share,
    bachelor's degree) move scores by small amounts, and with seven measures
    tried, one is expected to look better by chance.
  - On the score least affected by the overall level (AUC: the chance a state
    with bans is ranked above one without), rule and models are level at
    about 0.72-0.77.
  - The models' probability scores (Brier about 0.26) look better than the rule's
    (0.28) only because the rule gives hard yes/no answers, which are
    penalised heavily when wrong.
  - All models predict about 2,700-3,300 instances, against 11,982 recorded.
    The level is set by 2022-23 and cannot anticipate a tripling.

WHAT THIS MEANS
  On this check, past status is the best guide to which states record bans.
  A model combining past status with the election margin might do better, but
  testing it needs a third year of comparable state data.

2026-27 OUTLOOK AS OF NOVEMBER 17, 2026 (outlook/)
  PEN's 2025-26 results became available after the 2026-27 school year
  began, so this is an outlook as of today, not a forecast that could have
  been made before the year started. It is about where PEN will record bans.

  Starting point (the rule): each state's 2025-26 recorded status repeats,
  ranked by its 2025-26 rate. PEN recorded a count in 23 states and none in
  27.
  Rate denominator: the outlook's rate divides PEN's 2025-26 instances by the
  ACS 5-year 2019-23 population, the figure available before 2025-26 began.
  The descriptive map divides the same instances by the 2025 population
  estimate. Texas: 8,193 instances = 276.4 per million here, 258.4 on the
  map. The CSV carries both (rate_per_million_2025_26 and
  rate_per_million_2025_26_map).
  Alongside (the model): population + 2024 margin, fitted to 2025-26 with
  ACS 5-year 2019-23 population, applied with ACS 5-year 2020-24 population
  (released December 2025) and the 2024 margin. Margin coefficient 1.21 per
  10 points (rate ratio 3.35).

  Rule and model agree on 30 states (12 likely, 18 unlikely) and differ on 20.
  Agreement between two predictions does not show that either is right; the
  evidence on accuracy is the historical test (rule 36/50, model 27/50).
  - 11 rule likely, model below 0.5: Iowa, Minnesota, Michigan, Georgia,
    New Hampshire, Pennsylvania, Colorado, Maryland, New Jersey,
    North Carolina, California.
  - 9 model above 0.5, rule not expected: West Virginia, Oklahoma, Alabama,
    Kentucky, Louisiana, North Dakota, Mississippi, South Dakota, Nebraska.
    Six of these (West Virginia, Oklahoma, Kentucky, North Dakota,
    South Dakota, Nebraska) are worth monitoring because they had 2022-23
    entries and the two methods disagree. They are not validated
    predictions.
  Model probabilities run only from 0.03 to 0.63, so a model "yes" is weak;
  Kansas (0.501) and Nebraska (0.508) sit on the cut-off.

  How firm the rule is, judged by the last change (2022-23 to 2025-26):
  all 6 states with 100+ entries in 2022-23 were recorded again (though
  Missouri, Pennsylvania and South Carolina far fewer times); 15 of the 27
  with 1-99 entries were. The 2025-26 states with 100+ entries are Texas,
  Florida, Ohio and Utah. Thirteen 2025-26 states have fewer than 10 entries,
  and seven have one or two.

  Limits: one test; coverage differs between PEN's years; "not expected"
  means PEN recorded none, not that no bans occur; only two states were
  new between the last two years, so new states cannot be named reliably.

FILES
  forecast_test.py      the test
  fec2020.py            extracts 2020 margins from the FEC workbook
  census_dirs.json      points the test at sources/census
  sources/              PEN state tables, FEC 2020 workbook, extracted margins,
                        ACS 5-year 2016-20 and 2019-23 tables,
                        ACS 5-year 2020-24 DP05 (outlook population), 2010 and 2020
                        urban/rural tables, SHA256SUMS.txt
  results/forecast_scorecard.csv     every model and rule, all scores, coefficients
  results/forecast_states_2025_26.csv  per-state predictions and outcomes
  results/forecast_summary.txt
  outlook_2026_27.py    the 2026-27 outlook
  outlook_chart.py      its chart
  outlook/outlook_2026_27.csv   50 states: rule, model probability, ranks, agreement
  outlook/outlook_summary.txt
  outlook/outlook_2026_27.png

RERUN
  python fec2020.py sources/fec/federalelections2020.xlsx sources/state_analysis_2025_2026.csv sources/margin_2020.csv
  python forecast_test.py sources/state_analysis_2022_2023.csv sources/state_analysis_2025_2026.csv census_dirs.json results sources/margin_2020.csv
  python outlook_2026_27.py sources/state_analysis_2022_2023.csv sources/state_analysis_2025_2026.csv sources/census outlook
  python outlook_chart.py outlook/outlook_2026_27.csv outlook/outlook_2026_27.png

CORRECTIONS, NOVEMBER 17, 2026
  Baseline relabelled "repeat 2022-23 status or rate"; population-only ranking
  scores reported as not applicable (they ordered tied values); "improves on
  every score" replaced with the actual changes, including the slightly worse
  Brier score.
  Outlook: rate denominator labelled and the map-based rate added; chart
  panels labelled by what PEN recorded in 2025-26; the six states described
  as worth monitoring, not as predictions; agreement between methods not
  presented as evidence of accuracy.
