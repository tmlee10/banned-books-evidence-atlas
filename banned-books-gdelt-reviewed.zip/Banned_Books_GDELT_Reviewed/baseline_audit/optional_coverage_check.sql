-- NOT EXECUTED. Inspect the BigQuery scan estimate first.
-- Checks the date with zero returned candidates; this is not a topic query.
SELECT COUNT(*) AS all_gkg_rows_on_partition_date
FROM `gdelt-bq.gdeltv2.gkg_partitioned`
WHERE _PARTITIONTIME >= TIMESTAMP('2022-11-11')
  AND _PARTITIONTIME < TIMESTAMP('2022-11-12');
