-- User-executed query, school year 2022-2023. No row limit.
WITH news AS (
  SELECT GKGRECORDID AS record_id, DATE AS recorded_at,
    SourceCommonName AS source, DocumentIdentifier AS url,
    REGEXP_EXTRACT(Extras, r'<PAGE_TITLE>(.*?)</PAGE_TITLE>') AS title
  FROM `gdelt-bq.gdeltv2.gkg_partitioned`
  WHERE _PARTITIONTIME >= TIMESTAMP('2022-07-01')
    AND _PARTITIONTIME < TIMESTAMP('2023-07-01')
), prepared AS (
  SELECT *, LOWER(CONCAT(COALESCE(title, ''), ' ',
    REPLACE(REGEXP_REPLACE(COALESCE(url, ''), r'^https?://[^/]+', ''), '_', ' ')
  )) AS search_text FROM news
)
SELECT record_id, recorded_at, source, url, title
FROM prepared
WHERE REGEXP_CONTAINS(search_text, r'\b(books?|libraries|library|librarians?)\b')
  AND REGEXP_CONTAINS(search_text, r'\b(bans?|banned|banning|censor[a-z]*|challenges?|challenged|challenging|remov[a-z]*|restrict[a-z]*)\b')
ORDER BY recorded_at, record_id;
