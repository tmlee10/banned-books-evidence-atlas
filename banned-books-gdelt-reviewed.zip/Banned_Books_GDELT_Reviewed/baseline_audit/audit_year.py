"""Offline audit of the user-executed BigQuery export; Python standard library only.
Run: python audit_year.py
No network calls, article verification, NCES assignment, or causal analysis.
"""
from pathlib import Path
import csv, collections, datetime as dt, hashlib, html, json, re
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs'
OUT.mkdir(exist_ok=True)
def read(name):
    with (ROOT/'inputs'/name).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))
def write(name, rows, fields):
    with (OUT/name).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
def headline(s):
    return re.sub(r'\s+', ' ', html.unescape(s).casefold()).strip()
def words(s):
    return ' '+re.sub(r'[^a-z0-9]+',' ',html.unescape(s).lower()).strip()+' '
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

rows=read('gdelt_full_year_raw.csv')
pen=read('pen_events.csv')
july=read('gdelt_july_checkpoint.csv')
urls=collections.Counter(r['url'] for r in rows)
heads=collections.Counter(headline(r['title']) for r in rows if r['title'].strip())
months=collections.Counter(r['recorded_at'][:6] for r in rows)
days=collections.Counter(r['recorded_at'][:8] for r in rows)
districts=collections.Counter((r['state'],r['district']) for r in pen)
missing_days=[]
daily=[]
for i in range(365):
    d=dt.date(2022,7,1)+dt.timedelta(days=i)
    n=days[d.strftime('%Y%m%d')]
    daily.append({'date':d.isoformat(),'candidate_records':n})
    if not n: missing_days.append(d.isoformat())
review=[]; links=[]
direct=re.compile(r'\b(?:book\s+bans?|book\s+banning|banned\s+books?|banning\s+books?|book\s+censorship)\b')
for r in rows:
    # All rows are retained. Flags prioritize review; they do not decide inclusion.
    text=headline(r['title'])+' '+urlsplit(r['url']).path.lower().replace('-',' ').replace('_',' ')
    cue='direct_book_ban_phrase' if direct.search(text) else 'other_keyword_match'
    rr=dict(r,title_decoded=html.unescape(r['title']),exact_url_occurrences=urls[r['url']],
        normalized_headline_occurrences=heads.get(headline(r['title']),0),
        review_priority_cue=cue,review_status='pending',in_scope='',library_setting='',
        verified_state='',verified_district='',verified_nces_id='',verified_publication_date='',
        evidence_url='',review_notes='')
    review.append(rr)
    evidence=words(r['title']+' '+urlsplit(r['url']).path)
    for (state,district),n in sorted(districts.items()):
        if words(district) in evidence:
            links.append({'record_id':r['record_id'],'url':r['url'],'title':html.unescape(r['title']),
                'candidate_state':state,'candidate_district':district,
                'state_name_present_in_title_or_path':words(state) in evidence,
                'match_rule':'complete PEN district name after punctuation/case normalization',
                'pen_school_year_instances':n,'link_status':'unverified_name_match',
                'nces_id':'','review_decision':'','review_evidence_url':'','review_notes':''})

checks={
 'record_ids_unique':len({r['record_id'] for r in rows})==len(rows),
 'all_dates_parse_and_in_school_year':all(dt.datetime(2022,7,1)<=dt.datetime.strptime(r['recorded_at'],'%Y%m%d%H%M%S')<dt.datetime(2023,7,1) for r in rows),
 'monthly_counts_reconcile':sum(months.values())==len(rows),
 'daily_counts_reconcile':sum(x['candidate_records'] for x in daily)==len(rows),
 'review_queue_preserves_every_row':len(review)==len(rows),
 'july_checkpoint_records_identical':{tuple(r.items()) for r in july}=={tuple(r.items()) for r in rows if r['recorded_at'].startswith('202207')},
 'pen_baseline_retains_3362_rows':len(pen)==3362,
}
assert all(checks.values()), checks
stats={
 'returned_records':len(rows),'distinct_record_ids':len({r['record_id'] for r in rows}),
 'distinct_urls':len(urls),'repeated_url_extra_occurrences':sum(n-1 for n in urls.values()),
 'repeated_url_groups':sum(n>1 for n in urls.values()),
 'distinct_source_field_values':len({r['source'] for r in rows}),
 'missing_fields':{k:sum(not r[k].strip() for r in rows) for k in rows[0]},
 'distinct_nonblank_normalized_headlines':len(heads),
 'repeated_nonblank_headline_groups':sum(n>1 for n in heads.values()),
 'rows_in_repeated_nonblank_headline_groups':sum(n for n in heads.values() if n>1),
 'dates_with_candidates':len(days),'dates_without_candidates':missing_days,
 'monthly_candidate_counts':dict(sorted(months.items())),
 'district_name_candidate_pairs':len(links),
 'records_with_district_name_candidate':len({x['record_id'] for x in links}),
 'distinct_candidate_districts':len({(x['candidate_state'],x['candidate_district']) for x in links}),
 'candidate_pairs_with_state_name_context':sum(x['state_name_present_in_title_or_path'] for x in links),
 'verified_district_links':0,'pen_baseline_rows':len(pen),'pen_district_state_pairs':len(districts),
 'checks':checks,
 'input_sha256':{p.name:sha(p) for p in sorted((ROOT/'inputs').glob('*.csv'))},
}
write('review_queue.csv',review,list(review[0]))
write('district_name_candidates.csv',links,['record_id','url','title','candidate_state','candidate_district','state_name_present_in_title_or_path','match_rule','pen_school_year_instances','link_status','nces_id','review_decision','review_evidence_url','review_notes'])
write('monthly_candidate_counts.csv',[{'month':m,'candidate_records':n} for m,n in sorted(months.items())],['month','candidate_records'])
write('daily_candidate_counts.csv',daily,['date','candidate_records'])
write('repeated_urls.csv',[{'url':u,'occurrences':n} for u,n in sorted(urls.items()) if n>1],['url','occurrences'])
write('repeated_headlines.csv',[{'normalized_headline':h,'occurrences':n} for h,n in sorted(heads.items(),key=lambda x:(-x[1],x[0])) if n>1],['normalized_headline','occurrences'])
(OUT/'audit_summary.json').write_text(json.dumps(stats,indent=2)+'\n')
report=f'''BANNED BOOKS: GDELT FULL-YEAR EXTRACTION AUDIT
Period: July 1, 2022 through June 30, 2023
Audit date: October 2, 2026

COMPLETED WORK
The user executed the supplied GoogleSQL query in BigQuery Sandbox. The job
screened title and URL metadata in gdelt-bq.gdeltv2.gkg_partitioned. The
uploaded job screen reports 71.67 GB processed and a duration of 4.444 seconds.
This is scanned data volume, not the size or count of relevant articles.

The export contains {stats['returned_records']:,} records, {stats['distinct_urls']:,}
distinct URLs, and {stats['distinct_source_field_values']:,} source field values.
There are {stats['repeated_url_extra_occurrences']} extra occurrences of exact URLs.
Two titles are blank. All original records are retained in the review queue.
There are {stats['repeated_nonblank_headline_groups']:,} repeated nonblank headline
groups covering {stats['rows_in_repeated_nonblank_headline_groups']:,} records.
An identical headline is a flag for review, not proof of identical article text.

Candidate records occur on {stats['dates_with_candidates']} dates. No candidate was
returned for {', '.join(missing_days)}. This does not establish a GDELT outage or
an absence of book-ban reporting. The optional coverage query can distinguish
zero retrieved candidates from a date with no underlying rows.

The July checkpoint exactly matches July in the full-year export. Do not append
the July file or the earlier one-day file to the annual dataset.

PREPARATION FOR PEN MATCHING
The unchanged PEN baseline contains {len(pen):,} rows and {len(districts)} distinct
state/district pairs. Complete district-name matching against news titles and
URL paths produced {len(links)} possible record/district pairs spanning
{stats['distinct_candidate_districts']} districts. {stats['candidate_pairs_with_state_name_context']}
pairs also contain the corresponding state name. Every link remains unverified.
No NCES IDs were assigned. Short district names, aliases, acronym-only references,
article-body mentions and districts outside the PEN baseline are not recovered
by this conservative initial rule. No timing or outcome model was fitted.

INTERPRETATION
This completes a full-school-year metadata extraction and structural audit.
It does not complete the news-to-ban analysis. The results include international
coverage, opinion, public libraries, publisher editing, reading challenges and
other unrelated material. English search words limit retrieval; some non-English
pages can enter through English URL text. Recall has not been measured.
Neither source domain nor a place mentioned in a headline proves event location.
GDELT recorded_at is not a verified publication date or the date of a restriction.
Monthly candidate counts are retrieval diagnostics, not ban totals or a validated
measure of U.S. school-book-ban attention. Syndication must be distinguished from
independent reporting before aggregation. A full-year query does not establish
that GDELT covered every relevant news story.

NEXT ANALYSIS STEPS
1. Review scope and institution type, retaining reasons for exclusions.
2. Resolve repeated URLs, syndicated stories and materially updated articles.
3. Read source articles to verify district, state, publication date and context.
4. Check district identities against NCES; leave uncertain identities unresolved.
5. Match to PEN using compatible dates and restriction definitions. Respect PEN
   date precision; do not turn school-year or seasonal dates into exact months.
6. Build descriptive news measures only after these checks; assess coverage and
   alternative aggregation choices before timing or association models.

REPRODUCTION
Run python audit_year.py from this folder. Python standard library only.
All seven audit assertions passed. No records have been silently deleted and
no topic flag or name match is labeled as a verified finding.
'''
(ROOT/'GDELT_Full_Year_Audit.txt').write_text(report)
print(json.dumps(stats,indent=2))
