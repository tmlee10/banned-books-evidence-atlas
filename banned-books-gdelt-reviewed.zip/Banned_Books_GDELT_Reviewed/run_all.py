#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys
root = Path(__file__).resolve().parent
for script in ["baseline_audit/audit_year.py", "review/build_review.py", "review/build_linkage.py", "review/expand_candidates.py", "review/build_expansion.py", "review/build_continuation.py", "review/build_content_review.py", "review/build_passage_triage.py", "review/build_identity_review.py", "review/build_primary_review.py", "review/build_case_timelines.py", "review/build_hillsborough_review.py", "review/build_followup_review.py", "review/build_sample_review.py", "review/build_sample_followup.py", "review/build_date_review.py"]:
    print("Running", script, flush=True)
    subprocess.run([sys.executable, str(root/script)], cwd=root, check=True)
print("Done. Open review/outputs/GDELT_District_Link_Review.html")
