#!/usr/bin/env python3
"""Offline historical identity and article/PEN linkage audit. Python 3 stdlib.

Evidence judgments in inputs/ are reviewed inputs, not algorithmic discoveries.
No fuzzy matching, estimated dates, zero-filled panel, or model estimation.
Run build_review.py first, then this file. It adds to the base HTML report.
"""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timedelta
import csv, hashlib, html, json, zipfile, xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / 'baseline_audit'
if not BASE.exists():
    BASE = HERE.parent / 'gdelt_full_year' / 'package'
OUT = HERE / 'outputs'

def load(name):
    return json.loads((HERE/'inputs'/name).read_text())

def read(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def write(name, rows):
    with (OUT/name).open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)

sources = load('historical_sources.json')
for s in sources:
    assert hashlib.sha256((HERE/'inputs'/s['file']).read_bytes()).hexdigest() == s['sha256']

lea = read(HERE/'inputs/nces_district_office_locations_2223.csv')
sch = read(HERE/'inputs/nces_public_school_locations_2223.csv')
assert len(lea) == 19714 and len(sch) == 102268
assert {r['SCHOOLYEAR'] for r in lea+sch} == {'2022-2023'}
by_id = defaultdict(list)
schools = defaultdict(list)
for r in lea: by_id[r['LEAID']].append(r)
for r in sch: schools[r['LEAID']].append(r)
aliases = load('historical_identity_decisions.json')
historical = []
for a in aliases:
    rs = by_id[a['nces_id']]
    assert len(rs) == 1, (a, rs)
    r = rs[0]
    assert (r['NAME'], r['STATE']) == (a['historical_name'], a['historical_state'])
    ss = schools[a['nces_id']]
    assert ss and all(s['STATE'] == r['STATE'] for s in ss)
    historical.append({**a, 'school_year':r['SCHOOLYEAR'],
      'source_objectid':r['OBJECTID'], 'school_location_rows':len(ss),
      'source_file':'nces_district_office_locations_2223.csv',
      'enrollment_validated':'no','boundary_validated':'no'})
write('historical_nces_validation.csv', historical)
hc = {(r['candidate_state'],r['candidate_district']):r for r in historical}

pen = {int(r['source_row']):r for r in read(BASE/'inputs/pen_events.csv')}
assert len(pen) == 3362
# Check preserved event rows against the original workbook, not only a derivative CSV.
workbook = HERE/'inputs/pen_2022_2023.xlsx'
assert hashlib.sha256(workbook.read_bytes()).hexdigest() == 'b5222b5b87fc2ad66c58a22b726eed1ed9169ccfb5e66acbea2b23074981aafe'
ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(workbook) as z:
    ss=ET.fromstring(z.read('xl/sharedStrings.xml'))
    strings=[''.join(t.text or '' for t in e.iter('{'+ns['m']+'}t')) for e in ss]
    cells={}
    for row in ET.fromstring(z.read('xl/worksheets/sheet2.xml')).find('m:sheetData',ns):
        for c in row:
            v=c.find('m:v',ns); val=v.text if v is not None else ''
            cells[c.get('r')]=(strings[int(val)] if c.get('t')=='s' and val else val,c.get('s'))
    styles=ET.fromstring(z.read('xl/styles.xml'))
    formats={f.get('numFmtId'):f.get('formatCode') for f in styles.find('m:numFmts',ns)}
    xfs=styles.find('m:cellXfs',ns)
for ix,p in pen.items():
    for col,field in [('A','title'),('B','author'),('G','state'),('H','district'),('I','date_excel_serial_or_text'),('J','status')]:
        assert cells.get(f'{col}{ix}',('',None))[0].strip()==p[field].strip(),(ix,field)
    try:
        float(p['date_excel_serial_or_text'])
        style=cells[f'I{ix}'][1]
        assert formats.get(xfs[int(style)].get('numFmtId'),'').replace('"','') == 'mmmm yyyy'
    except ValueError:
        pass
review = read(OUT/'candidate_review.csv')
articles = {int(r['candidate_index']):r for r in review}
decisions = load('title_link_decisions.json')
scopes = load('article_title_review_scope.json')
links = []
for ix, d in enumerate(decisions, 1):
    a = articles[d['candidate_index']]
    assert a['review_decision'] == 'district_topic_confirmed'
    p = pen[int(d['pen_source_row'])] if d['pen_source_row'] else None
    month = ''; precision = ''; rawdate = ''; penid = ''
    if p:
        assert (p['state'],p['district']) == (a['verified_state'], a['verified_district'])
        assert p['title'] == d['expected_pen_title'] and p['author'] == d['expected_pen_author']
        rawdate = p['date_excel_serial_or_text']
        try:
            month = (datetime(1899,12,30)+timedelta(days=float(rawdate))).strftime('%Y-%m')
            precision = 'month_only_source_format'
        except ValueError:
            precision = 'school_year_only' if rawdate.startswith('AY ') else 'season_or_other_text'
        penid = p['sheet'] + ':' + p['source_row']
    date_ok = a['article_date_type']=='published' and not a['timing_warning']
    numeric_order = ''; lag = ''
    rejected = d['title_link_decision']=='rejected_author_conflict'
    if p and not rejected and month and date_ok:
        am = a['article_date'][:7]
        lag = (int(am[:4])-int(month[:4]))*12 + int(am[5:])-int(month[5:])
        numeric_order = 'earlier_month' if lag<0 else 'later_month' if lag>0 else 'same_month_order_unknown'
    # Only one author-labelled list has concordant month and restriction-stage evidence.
    # This flag is for a descriptive case audit, NEVER for a model or first-onset lag.
    case_eligible = (d['title_link_decision']=='title_author_district_supported'
        and d['episode_assessment']=='reported_removal_stage_with_same_publication_month' and date_ok and bool(month))
    links.append({
      'link_review_id':f'L{ix:03d}', **d,
      'record_id':a['record_id'],'state':a['verified_state'],'district':a['verified_district'],
      'historical_nces_id':hc[(a['verified_state'],a['verified_district'])]['nces_id'],
      'reporting_family':a['reporting_family'],
      'gdelt_recorded_at':a['gdelt_recorded_at'],
      'article_date':a['article_date'],'article_date_type':a['article_date_type'],
      'pen_row_id':penid,'pen_status':p['status'] if p else '',
      'pen_date_as_received':rawdate,'pen_month':month,'pen_date_precision':precision,
      'arithmetic_month_offset_not_event_lag':lag,
      'arithmetic_order_not_first_onset':numeric_order,
      'descriptive_stage_comparison_eligible':'yes' if case_eligible else 'no',
      'model_eligible':'no'})
write('article_pen_link_review.csv',links)
write('article_title_review_scope.csv',scopes)
write('linkage_exceptions.csv',[r for r in links if r['descriptive_stage_comparison_eligible']=='no'])

# One row per PEN row in the restricted concordance audit: no article multipliers.
accepted = [r for r in links if r['descriptive_stage_comparison_eligible']=='yes']
case_rows = []
for key in sorted({r['pen_row_id'] for r in accepted}):
    rr = [r for r in accepted if r['pen_row_id']==key]
    first = rr[0]
    case_rows.append({'pen_row_id':key, 'state':first['state'],'district':first['district'],
      'title':first['expected_pen_title'],'author':first['expected_pen_author'],
      'pen_month':first['pen_month'],'article_month':first['article_date'][:7],
      'arithmetic_order':first['arithmetic_order_not_first_onset'],
      'reviewed_link_ids':'|'.join(r['link_review_id'] for r in rr),
      'reporting_family_count':len({r['reporting_family'] for r in rr}),
      'interpretation':'Later review/removal stage, not first restriction onset; all share one list article.'})
write('restriction_stage_concordance.csv',case_rows)

for a in review:
    h = hc[(a['candidate_state'],a['candidate_district'])]
    a['historical_2022_2023_validation']='historical_name_id_state_confirmed'
    a['verified_historical_nces_id']=h['nces_id']
    a['nces_evidence_url']=sources[1]['catalog_url']
    ll = [r for r in links if str(r['candidate_index'])==a['candidate_index']]
    a['pen_event_link_status']='title_pair_reviewed_see_link_ledger' if ll else 'no_title_pair_established'
write('candidate_review.csv',review)
write('confirmed_district_topic_links.csv',[r for r in review if r['review_decision']=='district_topic_confirmed'])
write('unresolved_article_links.csv',[r for r in review if r['review_decision']!='district_topic_confirmed'])
crosswalk=load('nces_crosswalk.json')
for r in crosswalk:
    h=hc[(r['candidate_state'],r['candidate_district'])]
    r['historical_2022_2023_validation']='historical_name_id_state_confirmed'
    r['historical_nces_name']=h['historical_name']
    r['historical_nces_source']=sources[1]['catalog_url']
    r['historical_limits']='Enrollment, staffing, district eligibility and boundaries not validated.'
write('nces_identity_crosswalk.csv',crosswalk)

summary={
 'review_date':'2026-10-02','stage':'Historical NCES identity and selected title linkage',
 'historical_nces_districts_verified':len(historical),
 'nces_district_office_source_rows':len(lea),'nces_school_location_source_rows':len(sch),
 'supported_articles_assessed_for_title_linkage':len(scopes),
 'reviewed_title_pairs':len(links),
 'articles_with_reviewed_title_pairs':len({r['candidate_index'] for r in links}),
 'title_link_decisions':dict(Counter(r['title_link_decision'] for r in links)),
 'unique_pen_rows_with_title_author_district_support':len({r['pen_row_id'] for r in links if r['title_link_decision']=='title_author_district_supported'}),
 'descriptive_stage_concordant_pen_rows':len(case_rows),
 'stage_concordance_districts':len({r['district'] for r in case_rows}),
 'stage_concordance_article_families':len({r['reporting_family'] for r in accepted}),
 'stage_comparison_order':dict(Counter(r['arithmetic_order'] for r in case_rows)),
 'model_eligible_records':0,
 'checks':{
   'source_hashes_verified':True,
   'pen_rows_and_month_formats_verified_against_workbook':True,
   'all_33_historical_name_id_state_verified':len(historical)==33,
   'all_article_scopes_accounted':{r['candidate_index']for r in scopes}=={int(r['candidate_index']) for r in review if r['review_decision']=='district_topic_confirmed'},
   'no_duplicate_article_pen_pairs':len({(r['candidate_index'],r['pen_row_id'],r['article_title'])for r in links})==len(links),
   'no_cross_district_links':True,
   'author_conflict_not_accepted':all(r['descriptive_stage_comparison_eligible']=='no' and r['arithmetic_month_offset_not_event_lag']=='' for r in links if r['title_link_decision']=='rejected_author_conflict'),
   'no_season_dates_imputed':all(not r['pen_month'] for r in links if r['pen_date_precision']=='season_or_other_text'),
   'no_publication_date_imputed':all(r['arithmetic_month_offset_not_event_lag']=='' for r in links if r['article_date_type']!='published'),
   'no_model_rows_promoted':all(r['model_eligible']=='no' for r in links),
   'all_concordance_same_month':all(r['arithmetic_order']=='same_month_order_unknown' for r in case_rows),
   'original_raw_export_unchanged':hashlib.sha256((BASE/'inputs/gdelt_full_year_raw.csv').read_bytes()).hexdigest()=='88a6e77fb209d3f8b095e6dd90fe9ea82d5138bbb61ad996191322533c5774f0'
 }}
assert all(summary['checks'].values()),summary['checks']
(OUT/'linkage_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
initial=json.loads((OUT/'first_pass_summary.json').read_text())
initial['scope']='District-topic review with subsequent historical identity and selected title linkage'
initial['historical_nces_validated_districts']=len(historical)
initial['title_linkage_summary']='linkage_summary.json'
initial['checks']['no_unverified_model_rows']=all(r['model_eligible']=='no' for r in review)
initial['checks']['historical_ids_validated']=all(r['verified_historical_nces_id'] for r in review)
(OUT/'review_summary.json').write_text(json.dumps(initial,indent=2)+'\n')

def esc(s): return html.escape(str(s))
def table(headers,rows):
    return '<table><thead><tr>'+''.join('<th>'+esc(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+esc(x)+'</td>' for x in r)+'</tr>' for r in rows)+'</tbody></table>'

report=(OUT/'first_pass_review.html').read_text()
start=report.index('<h1>');end=report.index('<div class="grid">')
report=report[:start]+'<h1>Historical district verification and title linkage</h1>'+report[end:]
pstart=report.index('<p>All 33 candidate district identities');pend=report.index('<h2>Review totals',pstart)
report=report[:pstart]+'''<p>All 33 candidate district identities now match the official NCES EDGE 2022–2023 district-office file by reviewed name, seven-digit LEA ID and state. The download contains 19,714 district-office records; a second official file contains 102,268 school-location records. All 33 IDs also occur in the latter with the expected state. These checks verify historical identity, not enrollment, staffing or boundary stability. The downloads, hashes and reviewed name aliases are included.</p>'''+report[pend:]
report=report.replace('<td>Historical NCES matches validated</td><td>0</td>','<td>Historical NCES name/ID/state matches validated</td><td>33</td>')
new='''<h2>What the title review added</h2><p>The second pass checked selected named titles and negative controls in the 33 supported articles. Each proposed link retains the original PEN sheet and row number, title, author, date value and status. This is a correspondence audit, not an exhaustive inventory of every title mentioned in the articles.</p>'''
new+=table(['Measure','Result'],[
 ('Article/title pairs reviewed',len(links)),
 ('Articles containing reviewed pairs',summary['articles_with_reviewed_title_pairs']),
 ('Distinct PEN rows with title, author and district support',summary['unique_pen_rows_with_title_author_district_support']),
 ('PEN rows in the strict restriction-stage month comparison',len(case_rows)),
 ('Districts / reporting families contributing to that comparison',f"{summary['stage_concordance_districts']} / {summary['stage_concordance_article_families']}"),
 ('Model-ready observations',0)])
new+='''<p><strong>The 22 strict comparison rows all come from one Alpine article and its November 2022 removal list.</strong> Their PEN month and publication month agree. The article gives an as-of date, not an individual decision date for each title, and does not independently verify the classroom scope recorded in PEN. They are not 22 independent observations of news timing. The August article already described temporary restrictions on the same books, so November cannot be interpreted as their first restriction date. No daily lag or causal sequence is estimated.</p>
<h2>Issues that change a timing analysis</h2>'''
new+=table(['Case','Evidence comparison','Treatment'],[
 ('Sarasota / Choke','Article: Chuck Palahniuk. PEN row 2960: Obert Skye, Pillage series.','Reject this title join; retain both source records unchanged.'),
 ('Central Bucks / two titles','PEN: December 2022. News distinguishes early review, returned copies and May 2023 removal decisions.','Keep stages separate. A five-month subtraction is not automatically a reporting delay.'),
 ('Alpine / overlapping lists','August temporary removals precede November review outcomes.','Earlier coverage does not mean publicity preceded the first restriction.'),
 ('Davis / Bible','PEN has The Bible, Unknown author, May 2023; June article specifies King James edition.','Work-family match only; edition remains unresolved.'),
 ('Brevard / Bible','Generic review coverage; annual PEN rows include multiple Bible-related titles.','No generic-word join to all Bible titles.'),
 ('Lake / And Tango Makes Three','PEN: Fall 2022. June litigation article attributes a December restriction to the complaint.','No invented PEN month. Preserve source precision and attribution.'),
 ('Portage / Push','Article reports a removal without its start date; PEN month is December and status is pending investigation.','Title identity supported; onset and status not independently reconciled.'),
 ('Dearborn / six titles','Title and author agree with PEN; current article has no visible publication date.','Retain identity links; exclude from publication-month comparison.')])
new+='''<p>News items about retained books, the Book of Mormon challenge and unrelated historical litigation remain in the exception ledger. Unmatched titles are not evidence of zero bans. The title ledger’s arithmetic month offset is provided only for auditing: it compares two source fields and must not be used as an event-onset lag.</p>
<p>Sources: <a href="https://catalog.data.gov/dataset/school-district-office-locations-2022-23">NCES district-office catalog</a>; <a href="https://catalog.data.gov/dataset/public-school-locations-2022-23">NCES school-location catalog</a>; <a href="https://www.kuer.org/education/2022-11-29/these-are-the-22-books-removed-from-utahs-alpine-school-district">Alpine November list</a>; <a href="https://lehifreepress.com/2022/08/03/alpine-school-district-temporarily-removes-controversial-books-board-crafting-book-review-policy/">Alpine August reporting</a>; <a href="https://patch.com/florida/sarasota/3-more-books-challenged-sarasota-county-schools-district">Sarasota article</a>. Row-level source URLs are in <code>article_pen_link_review.csv</code>.</p>'''
report=report.replace('<h2>Problems caught by reading the articles</h2>',new+'<h2>Other problems caught by reading the articles</h2>')
report=report.replace('Articles have not yet been matched to individual PEN title events.','Selected title/district correspondences are now linked to preserved PEN rows. Event onset remains unresolved for most pairs.')
report=report.replace('<li>Run <code>python review/build_review.py</code> to regenerate the review CSV files, summary and this report.</li>', '<li>Run <code>python review/build_review.py</code> to regenerate the first-pass review.</li><li>Run <code>python review/build_linkage.py</code> to apply historical checks and title linkage, and regenerate this expanded report.</li>')
report=report.replace('All ten consistency checks should pass.','The checks in both review_summary.json and linkage_summary.json must pass.')
report=report.replace('Confirm historical NCES IDs and the full eligible-district population against 2022–2023 CCD data.','Use the historical identity crosswalk to build the full eligible-district population and acquire time-matched enrollment and staffing. Identity verification alone does not establish eligibility.')
report=report.replace('Verify title-level PEN links and restriction dates; distinguish challenges, removals, returns, litigation and commentary.','Resolve the flagged author/edition and restriction-stage differences using district records. Independently review the curated title links.')
report=report.replace('The report and website’s substantive results have not been replaced with these incomplete coverage measures.','The main research report and website have not been changed. These audit findings do not support a new substantive model or forecast.')
(OUT/'GDELT_District_Link_Review.html').write_text(report)
print(json.dumps(summary,indent=2))
