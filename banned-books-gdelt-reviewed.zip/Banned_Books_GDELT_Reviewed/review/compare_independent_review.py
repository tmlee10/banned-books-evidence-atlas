#!/usr/bin/env python3
"""Validate completed human responses and compare them with the frozen sample.
Reports disagreements only; never changes judgments or certifies independence.
Usage: python review/compare_independent_review.py path/to/responses.json
"""
from pathlib import Path
from datetime import date
from collections import Counter
import csv,json,re,sys
H=Path(__file__).resolve().parent

def valid_date(value,precision):
 if precision=='unknown':return value==''
 try:
  if precision=='month':return bool(re.fullmatch(r'\d{4}-\d{2}',value)) and date.fromisoformat(value+'-01') is not None
  if precision=='day':return bool(re.fullmatch(r'\d{4}-\d{2}-\d{2}',value)) and date.fromisoformat(value) is not None
 except ValueError:return False
 return False

def compare(data,baseline):
 errors=[]
 if data.get('protocol')!='banned-books-independent-review-v13':errors.append('Protocol does not match.')
 if not str(data.get('reviewer','')).strip():errors.append('Reviewer name or ID is missing.')
 if not valid_date(data.get('review_date',''),'day'):errors.append('Review date is missing or invalid.')
 if data.get('independent_first_pass') is not True:errors.append('Independent first pass has not been attested.')
 records=data.get('records',[]);expected={r['record_id']:r for r in baseline}
 ids=[r.get('record_id','') for r in records]
 if len(ids)!=36 or len(set(ids))!=36 or set(ids)!=set(expected):errors.append('Exactly the 36 selected record IDs are required.')
 verdicts={'supported_school_topic','outside_school_scope','noncontent_match','unresolved'}
 results=[]
 for r in records:
  rid=r.get('record_id','');b=expected.get(rid)
  if not b:continue
  if r.get('topic_verdict') not in verdicts:errors.append(rid+': missing or invalid topic classification.')
  if r.get('access_status') not in ('readable','partial','unavailable'):errors.append(rid+': missing access status.')
  if r.get('topic_verdict')!='unresolved' and r.get('access_status')!='readable':errors.append(rid+': substantive classification requires readable article evidence.')
  if r.get('district_status') not in ('confirmed','no_single_district','unresolved'):errors.append(rid+': missing district status.')
  if r.get('district_status')=='confirmed':
   if not re.fullmatch(r'\d{7}',r.get('nces_id','')) or not r.get('district_name') or not re.fullmatch('[A-Z]{2}',r.get('district_state','')):errors.append(rid+': confirmed district needs name, state and seven-digit NCES ID.')
  elif r.get('nces_id'):errors.append(rid+': NCES ID supplied without confirmed district status.')
  if r.get('access_status')=='readable' and not r.get('reviewed_url','').startswith(('https://','http://')):errors.append(rid+': reviewed source URL is missing.')
  if len(r.get('evidence_note','').strip())<20:errors.append(rid+': explanatory evidence note is missing or too short.')
  if not r.get('event_stage','').strip():errors.append(rid+': event stage or unknown is required.')
  if not valid_date(r.get('event_date',''),r.get('date_precision','')):errors.append(rid+': event date and precision disagree.')
  pub=r.get('publisher_date','')
  if pub and not (valid_date(pub,'day') or valid_date(pub,'month')):errors.append(rid+': invalid publication date.')
  results.append(dict(record_id=rid,prior_topic=b['verdict'],reviewer_topic=r.get('topic_verdict',''),topic_agreement=b['verdict']==r.get('topic_verdict'),prior_nces_id=b['reviewed_nces_id'],reviewer_nces_id=r.get('nces_id',''),district_comparison='not_comparable' if r.get('district_status')=='unresolved' or not b['reviewed_nces_id'] else 'same_id' if r.get('nces_id')==b['reviewed_nces_id'] else 'different_or_unassigned',adjudication='pending'))
 if errors:return dict(status='incomplete_or_invalid',errors=errors,independent_review_completed=False)
 return dict(status='complete_response_set_received_not_adjudicated',reviewer=data['reviewer'],review_date=data['review_date'],independence='self_attested_not_independently_verified',records=results,topic_agreements=sum(r['topic_agreement'] for r in results),topic_disagreements=sum(not r['topic_agreement'] for r in results),district_comparisons=dict(Counter(r['district_comparison'] for r in results)),research_records_modified=False,limitation='Agreement with earlier AI judgments is not proof of accuracy. Source evidence and disagreements require adjudication.')
if __name__=='__main__':
 if len(sys.argv)!=2:raise SystemExit(__doc__)
 data=json.loads(Path(sys.argv[1]).read_text());baseline=list(csv.DictReader((H/'outputs/sample_review_v13.csv').open()))
 result=compare(data,baseline);print(json.dumps(result,indent=2));raise SystemExit(2 if result['status']=='incomplete_or_invalid' else 0)
