#!/usr/bin/env python3
"""Reproduce the first-pass review outputs from preserved evidence decisions.

Python 3 standard library only. Run: python review/build_review.py
Human/assistant evidence decisions are inputs, not recreated by this script.
No network requests, credentials, paid services, or model estimation.
"""
from pathlib import Path
import csv, json, hashlib, html
from collections import Counter, defaultdict
from datetime import datetime

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / 'baseline_audit'
if not BASE.exists():
    BASE = HERE.parent / 'gdelt_full_year' / 'package'
OUT = HERE / 'outputs'
OUT.mkdir(exist_ok=True)

def readcsv(p):
    with p.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def writecsv(name, rows, fields=None):
    fields = fields or list(rows[0])
    with (OUT/name).open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(rows)

def load(name):
    return json.loads((HERE/'inputs'/name).read_text())

candidates = readcsv(BASE/'outputs/district_name_candidates.csv')
raw = {r['record_id']:r for r in readcsv(BASE/'outputs/review_queue.csv')}
decisions = {r['candidate_index']:r for r in load('article_decisions.json')}
attempts = {r['i']:r for r in load('url_review_attempts.json')}
crosswalk = load('nces_crosswalk.json')
cw = {(r['candidate_state'], r['candidate_district']):r for r in crosswalk}

# Evidence-based reporting families; grouping is not a claim of independent events.
groups = {
    'AP_Tulsa_20220729':([11,17], 'AP credit and matching district statement; brief/full versions'),
    'WHYY_CentralBucks_ReviewCopies':([34,35], 'Same reporter and matching article text'),
    'WHYY_CentralBucks_60Challenges':([38,42,46], 'Original, republication and attributed audio summary; related reporting family'),
    'KUTV_Davis_20230607':([94,97], 'Same byline, date and matching article text'),
}
membership = {i:(g,note) for g,(ids,note) in groups.items() for i in ids}
rows=[]
for i,c in enumerate(candidates):
    r=raw[c['record_id']]; a=attempts[i]; d=decisions.get(i)
    x=cw[(c['candidate_state'],c['candidate_district'])]
    access=a['access']
    if not d and access=='retrieved':
        access='insufficient_article_text_on_followup'
    day=d['article_date'] if d else ''
    dtype=d['article_date_type'] if d else 'unavailable'
    timing=''
    if day and day.replace('-','') > r['recorded_at'][:8]:
        timing='visible_article_date_after_gdelt_record; do_not_treat_as_first_publication'
    g,note=membership.get(i,(f'candidate_{i:03d}','No verified republication link assigned'))
    rows.append({
      'candidate_index':i,'record_id':c['record_id'],'gdelt_recorded_at':r['recorded_at'],
      'url':c['url'],'title':c['title'],'candidate_state':c['candidate_state'],
      'candidate_district':c['candidate_district'],'url_access_result':access,
      'review_decision':'district_topic_confirmed' if d else 'unresolved_article_evidence',
      'verified_state':c['candidate_state'] if d else '',
      'verified_district':c['candidate_district'] if d else '',
      'setting':d['setting'] if d else '', 'topic':d['topic'] if d else '',
      'article_date':day,'article_date_type':dtype,'timing_warning':timing,
      'nces_identity_candidate':x['nces_id'], 'nces_identity_status':x['identity_status'],
      'historical_2022_2023_validation':x['historical_2022_2023_validation'],
      'verified_historical_nces_id':'','nces_evidence_url':x['source_url'],
      'evidence_url':d['evidence_url'] if d else c['url'],
      'evidence_ref':d['evidence_ref'] if d else a['ref'],
      'reporting_family':g if d else '', 'family_basis':note if d else '',
      'pen_event_link_status':'not_verified',
      'model_eligible':'no',
      'review_notes':d['review_notes'] if d else 'Original URL attempted. Usable article evidence was not available; not a rejection or a confirmed event.',
    })

writecsv('candidate_review.csv',rows)
writecsv('nces_identity_crosswalk.csv',crosswalk)
confirmed=[r for r in rows if r['review_decision']=='district_topic_confirmed']
writecsv('confirmed_district_topic_links.csv',confirmed)
writecsv('unresolved_article_links.csv',[r for r in rows if r['review_decision']!='district_topic_confirmed'])

# Exact duplicate URLs and headline repetitions are clues, not automatic event collapse.
urlgroups=defaultdict(list); titlegroups=defaultdict(list); sluggroups=defaultdict(list)
from urllib.parse import urlsplit
import re, unicodedata
for i,c in enumerate(candidates):
    urlgroups[c['url']].append(i)
    t=re.sub(r'[^a-z0-9]+',' ',html.unescape(c['title']).lower()).strip()
    if t: titlegroups[t].append(i)
    path=urlsplit(c['url']).path.rstrip('/').split('/')[-1]
    if len(path)>35: sluggroups[path].append(i)
repetitions=[]
for kind,gs in [('exact_url',urlgroups),('normalized_headline',titlegroups),('long_url_slug',sluggroups)]:
    for key,ids in gs.items():
        if len(ids)>1:
            repetitions.append({'cue_type':kind,'cue_value':key,'candidate_indices':'|'.join(map(str,ids)),
              'record_count':len(ids),'decision':'same_URL_repeated' if kind=='exact_url' else 'possible_republication_not_proven',
              'handling':'Preserve all records; do not count as independent events.'})
writecsv('repetition_review.csv',repetitions)
writecsv('confirmed_reporting_families.csv',[{'family':g,'candidate_indices':'|'.join(map(str,ids)),
     'records':len(ids),'basis':note} for g,(ids,note) in groups.items()])

# Positive-only coverage table. Missing cells are deliberately NOT filled with zero.
pubrows=[r for r in confirmed if r['article_date_type']=='published' and not r['timing_warning']]
monthly=defaultdict(list)
for r in pubrows:
    monthly[(r['verified_state'],r['verified_district'],r['article_date'][:7])].append(r)
writecsv('reviewed_coverage_by_month.csv',[{'state':s,'district':d,'publication_month':m,
    'reviewed_article_records':len(rs),'reporting_families_observed':len({r['reporting_family'] for r in rs}),
    'coverage_status':'partial_selected_sample_not_a_complete_news_series'}
    for (s,d,m),rs in sorted(monthly.items())])

checks={
 'candidate_count_114':len(rows)==114,
 'every_candidate_attempted':set(attempts)==set(range(114)),
 'unique_record_ids':len({r['record_id'] for r in rows})==114,
 'decision_ids_match_source':all(candidates[i]['record_id']==d['record_id'] for i,d in decisions.items()),
 'crosswalk_all_candidate_districts':len(cw)==33 and all((r['candidate_state'],r['candidate_district']) in cw for r in rows),
 'nces_ids_seven_digits':all(re.fullmatch(r'\d{7}',r['nces_id']) for r in crosswalk),
 'no_unresolved_record_promoted':all(not r['verified_district'] for r in rows if r['review_decision']!='district_topic_confirmed'),
 'no_unverified_model_rows':all(r['model_eligible']=='no' and not r['verified_historical_nces_id'] for r in rows),
 'no_updated_only_dates_in_monthly_counts':len(pubrows)==27,
 'decisions_partition_candidates':len(confirmed)+sum(r['review_decision']=='unresolved_article_evidence' for r in rows)==114,
}
assert all(checks.values()), checks
summary={
 'review_date':'2026-10-02','scope':'First-pass evidence review of literal-name candidates only',
 'full_year_keyword_records':len(raw),'candidate_records':len(rows),
 'candidate_districts':len(cw),'district_topic_confirmed_records':len(confirmed),
 'unresolved_records':len(rows)-len(confirmed),
 'confirmed_districts':len({(r['verified_state'],r['verified_district']) for r in confirmed}),
 'publication_date_visible_records':len(pubrows),
 'updated_date_only_records':sum(r['article_date_type']=='updated_only' for r in confirmed),
 'date_not_visible_records':sum(r['article_date_type']=='not_visible' for r in confirmed),
 'visible_date_after_gdelt_records':sum(bool(r['timing_warning']) for r in confirmed),
 'documented_republication_or_derivative_families':len(groups),
 'reviewed_reporting_units_after_family_grouping':len({r['reporting_family'] for r in confirmed}),
 'historical_nces_validated_districts':0,
 'model_eligible_records':0,
 'access_results':dict(Counter(r['url_access_result'] for r in rows)),
 'checks':checks,
}
(OUT/'review_summary.json').write_text(json.dumps(summary,indent=2)+'\n')

def esc(v): return html.escape(str(v))
def table(heads, data):
    return '<table><thead><tr>'+''.join('<th>'+esc(x)+'</th>' for x in heads)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+esc(x)+'</td>' for x in row)+'</tr>' for row in data)+'</tbody></table>'

report='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>GDELT district-link review</title><style>
body{font-family:Arial,sans-serif;color:#14283a;background:#f1f5f7;margin:0;line-height:1.55}main{max-width:1020px;margin:32px auto;background:white;padding:44px;border-top:8px solid #167b85}h1{font-size:34px;line-height:1.2}h2{margin-top:34px;color:#135d66}p,li{max-width:900px}small,.sub{color:#526674}.callout{background:#eaf5f5;padding:18px 24px;border-left:4px solid #167b85}table{border-collapse:collapse;width:100%;font-size:14px;margin:20px 0}td,th{border-bottom:1px solid #ccd7dd;padding:10px;vertical-align:top;text-align:left}th{background:#e9f0f4}a{color:#136b7c}code{background:#eef2f5;padding:3px 6px} .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:15px}.card{background:#f1f5f7;padding:16px}.num{font-size:32px;font-weight:bold;display:block}@media(max-width:700px){main{margin:0;padding:22px}.grid{grid-template-columns:1fr}table{font-size:12px}}@media print{body{background:white}main{margin:0;padding:0}h2{break-after:avoid}tr{break-inside:avoid}}
</style><main><p class="sub">BANNED BOOKS · GDELT EXTENSION · REVIEWED 2 OCTOBER 2026</p><h1>District links: what the first review supports</h1>
<div class="grid"><div class="card"><span class="num">114</span>candidate records reviewed for access</div><div class="card"><span class="num">33</span>district-topic links supported by article evidence</div><div class="card"><span class="num">81</span>records still unresolved</div></div>
<p class="callout">This is a data-validation result. It is not a count of book bans, a complete measure of news attention, or a test of whether publicity caused restrictions.</p>
<h2>What was checked</h2><p>The annual BigQuery export contains 15,767 keyword-matching GDELT records from July 2022 through June 2023. A literal district-name screen selected 114 records associated with 33 PEN districts. Each candidate URL was attempted. Available article text was reviewed for the school setting, district and state, subject, visible date, and evidence of republication. An inaccessible page was left unresolved.</p>
<p>All 33 candidate district identities were located in indexed NCES directory evidence. The crosswalk records whether a directory text or only an excerpt was available. Direct NCES retrieval timed out for several checks. These are identity leads for historical validation: 2022–2023 membership, boundaries, enrollment and staffing have not been verified. The historical NCES-ID field is therefore blank.</p>
<h2>Review totals</h2>'''
report+=table(['Measure','Result'],[
 ('Article-supported district-topic links',len(confirmed)),('Districts represented by supported links',summary['confirmed_districts']),
 ('Unresolved article records',81),('Failed original URL fetches',78),('Insufficient usable article body',3),
 ('Supported links with visible publication dates',27),('Supported links with update dates only',2),('Supported links without visible dates',4),
 ('Documented republication/derivative families',4),('Reporting units after these limited groupings',28),
 ('Historical NCES matches validated',0),('Records ready for the proposed model',0)])
report+='''<p>The unresolved share measures this review’s access limitations, not the district-name screen’s accuracy. The 28 reporting units are provisional families, not proven independent stories. Other related or syndicated stories may remain.</p>
<h2>Problems caught by reading the articles</h2>
<ul><li><strong>Publisher location can be misleading.</strong> The ABC6 and WPDE items describe Davis School District in Utah. They carry the same KUTV reporting; their publishers do not locate the event in Ohio or South Carolina. <a href="https://abc6onyourside.com/news/nation-world/utah-superintendent-says-policy-that-led-to-bible-ban-was-followed-appropriately-davis-school-district-dr-dan-linford-valid-appeals-parents-protest-book-review-committee">KUTV republication</a>.</li>
<li><strong>A review is not necessarily a removal.</strong> Central Bucks articles describe purchasing review copies and considering additional challenges. Later articles describe decisions to remove two books and retain three. These are different stages, not interchangeable ban counts. <a href="https://whyy.org/articles/central-bucks-school-district-buying-books-consider-banning/">February reporting</a>; <a href="https://www.inquirer.com/news/central-bucks-bans-gender-queer-this-book-is-gay-20230512.html">May reporting</a>.</li>
<li><strong>An updated date can move a story across months.</strong> One WHYY record entered GDELT on January 25, 2023, while the current page displays a February 3 update. That update cannot stand in for the first publication date. <a href="https://whyy.org/articles/central-bucks-school-district-lgbtq-book-ban-family-research-council/">Source page</a>.</li>
<li><strong>Later news can concern an earlier restriction.</strong> The June 20 Lake County article describes litigation about a restriction alleged to have begun in December 2022. June is not the restriction month. <a href="https://www.clickorlando.com/news/local/2023/06/20/author-parents-sue-lake-county-schools-over-banned-book/">Lake County article</a>.</li>
<li><strong>Some retrospective coverage crosses school-year boundaries.</strong> The May 19, 2023 federal letter on Forsyth records removal instructions from January 2022 and a return decision in August 2022. It provides historical evidence, not a new May 2023 restriction. The unavailable original GDELT press-release URL remains unresolved; the letter is separately logged as corroboration. <a href="https://www.ed.gov/sites/ed/files/about/offices/list/ocr/docs/investigations/more/04221281-a.pdf">Historical OCR letter</a>.</li></ul>
<h2>Why the timing model is not ready</h2><p>The candidate screen searched only district names already present in the PEN event file. It misses aliases and shorter names, and it excludes districts absent from that list. Using this selected sample to compare banning and non-banning districts would introduce selection bias. Absence of a matching article is also not evidence of zero news coverage.</p>
<p>The package includes a positive-only monthly table for the 27 supported records with visible publication dates. It is a review-coverage table, not a district-month analysis panel. Blank district-months have not been converted to zeros. Publication dates are visible-page evidence, not immutable archived first-publication timestamps.</p>
<p>PEN month-only dates must remain month-only. Articles have not yet been matched to individual PEN title events. No regression, causal estimate, Ohio forecast, or statewide news trend was produced from this review.</p>
<h2>Reproduce the outputs</h2><ol><li>Unzip the package without changing its folder structure.</li><li>Run <code>python baseline_audit/audit_year.py</code> to reproduce the original export audit.</li><li>Run <code>python review/build_review.py</code> to regenerate the review CSV files, summary and this report.</li><li>Compare the output totals with <code>review/outputs/review_summary.json</code>. All ten consistency checks should pass.</li></ol>
<p>The article decisions and NCES evidence crosswalk are preserved as inputs. The script reproduces their aggregation; it does not independently reproduce the judgment of reading an article. Evidence URLs and short notes allow a second reviewer to audit those decisions. Full publisher articles are not redistributed.</p>
<h2>Next evidence required</h2><ol><li>Recover usable text for unresolved links through permitted sources or leave them out with an explicit coverage flag.</li><li>Confirm historical NCES IDs and the full eligible-district population against 2022–2023 CCD data.</li><li>Expand matching beyond complete names; test aliases on a sample and assess missed districts.</li><li>Verify title-level PEN links and restriction dates; distinguish challenges, removals, returns, litigation and commentary.</li><li>Only then build the district-month panel and assess whether the evidence supports a timing analysis.</li></ol>
<p class="sub">No additional BigQuery query or paid service was used for this review. The report and website’s substantive results have not been replaced with these incomplete coverage measures.</p></main></html>'''
(OUT/'GDELT_District_Link_Review.html').write_text(report,encoding='utf-8')
(OUT/'first_pass_review.html').write_text(report,encoding='utf-8')
(OUT/'first_pass_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
