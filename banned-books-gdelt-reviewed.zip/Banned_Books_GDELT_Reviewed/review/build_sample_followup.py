#!/usr/bin/env python3
"""Apply a frozen follow-up to the unchanged v11 sample. Offline, standard library."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timedelta
import csv,json,hashlib,html,re
H=Path(__file__).resolve().parent;I=H/'inputs';O=H/'outputs'
def read(n):return list(csv.DictReader((O/n).open(encoding='utf-8-sig',newline='')))
def write(n,rows):
 with (O/n).open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def e(x):return html.escape(str(x))
F=json.loads((I/'sample_followup_v12.json').read_text());A=json.loads((I/'sample_followup_access_v12.json').read_text());d=F['decision'];rid=d['record_id'];p=F['primary_receipt']
assert hashlib.sha256((I/p['pdf_path']).read_bytes()).hexdigest()==p['pdf_sha256']
base=read('sample_review_v11.csv');assert len(A)==20 and {r['record_id'] for r in A}=={r['record_id'] for r in base if r['verdict']=='unresolved'}
rows=[dict(r) for r in base]
for r in rows:
 if r['record_id']==rid:r.update(d,candidate_result='at_least_one_supported_candidate',access_status='original_body_reviewed')
assert sum(a!=b for a,b in zip(base,rows))==1
counts=Counter(r['verdict'] for r in rows);assert counts==dict(supported_school_topic=13,outside_school_scope=2,noncontent_match=2,unresolved=19)
pairs=read('sample_candidate_pairs_v11.csv')
for r in pairs:
 if r['record_id']==rid:
  r.update(reviewed_nces_id=d['reviewed_nces_id'],verdict='supported_candidate' if r['resolved_alias_nces_id']==d['reviewed_nces_id'] else 'rejected_candidate',evidence_note=d['evidence_summary'])
assert Counter(r['verdict'] for r in pairs)==dict(supported_candidate=10,rejected_candidate=34,unresolved=50)
month=read('sample_month_summary_v11.csv')
for r in month:
 sub=[x for x in rows if x['sample_month']==r['month']];c=Counter(x['verdict'] for x in sub);r.update(school_topic=c['supported_school_topic'],outside_school_or_noncontent=c['outside_school_scope']+c['noncontent_match'],unresolved=c['unresolved'])
off=list(csv.DictReader((I/'nces_district_office_locations_2223.csv').open(encoding='utf-8-sig')));schools=list(csv.DictReader((I/'nces_public_school_locations_2223.csv').open(encoding='utf-8-sig')))
n=next(r for r in off if r['LEAID']==d['reviewed_nces_id']);assert n['NAME']==d['reviewed_district'] and n['STATE']=='UT'
ss=[s for s in schools if s['LEAID']==n['LEAID']];assert ss and all(s['STATE']=='UT' for s in ss)
identity=read('sample_identity_checks_v11.csv');identity.append(dict(record_id=rid,nces_id=n['LEAID'],district=n['NAME'],state=n['STATE'],directory_year=n['SCHOOLYEAR'],school_rows_same_id=len(ss),basis='CNN district and state + district minutes address + official NCES 2022–2023 office/school files',independent_human_review='pending'))
source=read('sample_source_register_v11.csv')
for r in source:
 if r['record_id']==rid:r.update(reviewed_url=d['source_url'],evidence_basis=d['evidence_basis'],checked_utc=F['cnn_receipt']['checked_utc'],response_sha256=F['cnn_receipt']['sha256'],text_cache_sha256=d['cache_sha256'],web_fallback='not_used_for_decision')
penpath=H.parent/'baseline_audit/inputs/pen_events.csv'
if not penpath.exists():penpath=H.parent/'gdelt_full_year/package/inputs/pen_events.csv'
pen=list(csv.DictReader(penpath.open()));b=next(r for r in pen if r['source_row']=='3196');assert b['title']=='The Bible' and b['district']=='Davis School District'
pm=(datetime(1899,12,30)+timedelta(days=float(b['date_excel_serial_or_text']))).strftime('%Y-%m')
outcome=[dict(record_id=rid,nces_id=n['LEAID'],district=n['NAME'],state='UT',title='The Bible (King James Version)',pen_source_row='3196',pen_month=pm,pen_status=b['status'],decision_date='2023-06-20',decision='board_voted_to_reinstate',vote_for=7,vote_against=0,copies_described=8,copies_are_not_ban_instances='yes',primary_source_url=p['pdf_url'],primary_source_path=p['pdf_path'],primary_source_sha256=p['pdf_sha256'],source_page=2,minutes_status='posted_version_1_unsigned_approval_not_separately_verified',restriction_onset='',actual_reshelving_date='',duration_days='',accepted_onset_link='no',model_eligible='no',independent_human_review='pending',limit='Board decision date only. PEN month and CNN publication date are not onset or implementation dates.')]
current=read('current_record_review_v11.csv');rm={r['record_id']:r for r in rows}
for r in current:
 s=rm.get(r['record_id']);r.update(sample_review_v12=s['verdict'] if s else 'not_selected',sample_nces_id_v12=s['reviewed_nces_id'] if s else '',sample_candidate_result_v12=s['candidate_result'] if s else 'not_selected',sample_review_note_v12=s['evidence_summary'] if s else '',accepted_event_link_v12='no');assert r['model_eligible']=='no'
summary=dict(review_version=12,review_date='2026-10-03',frame_records=1054,sample_records=36,months=12,article_verdicts=dict(counts),candidate_results=dict(Counter(r['candidate_result'] for r in rows)),candidate_pairs=len(pairs),candidate_pair_verdicts=dict(Counter(r['verdict'] for r in pairs)),reviewed_districts=len(identity),reviewed_states=len({r['state'] for r in identity}),followup_records=20,changed_article_decisions=1,title_probes_v11=32,title_district_correspondences_v11=12,additional_title_district_correspondences=1,primary_board_decisions_added=1,new_accepted_dated_restriction_onset_links=0,model_eligible_records=0,additional_BigQuery_jobs=0,independent_human_review='pending')
for name,rs in [('sample_review_v12.csv',rows),('sample_candidate_pairs_v12.csv',pairs),('sample_month_summary_v12.csv',month),('sample_identity_checks_v12.csv',identity),('sample_source_register_v12.csv',source),('sample_followup_access_v12.csv',A),('sample_outcome_followup_v12.csv',outcome),('current_record_review_v12.csv',current)]:write(name,rs)
(O/'sample_summary_v12.json').write_text(json.dumps(summary,indent=2)+'\n')
page=(O/'GDELT_Validation_Sample.html').read_text();(O/'GDELT_Validation_Sample_v11.html').write_text(page)
page=page.replace('2 OCTOBER 2026','3 OCTOBER 2026 · FOLLOW-UP').replace('<b>12</b>School-book','<b>13</b>School-book').replace('<b>20</b>Article','<b>19</b>Article').replace('Eight records support at least one original district candidate; eight support none; twenty remain unresolved.','Nine records support at least one original district candidate; eight support none; nineteen remain unresolved.')
section='''<h2>What changed in this follow-up</h2><p>All 20 unresolved records received an access or corroboration follow-up. One original body was recovered: CNN’s Davis School District story. Nineteen selected records remain unresolved. Readable coverage elsewhere was retained as corroboration, without assuming it was identical to an inaccessible selected article.</p><h3>Davis, Utah: a documented reinstatement decision</h3><p>The district’s June 20, 2023 minutes record a 7–0 vote to reinstate the King James Bible at all school levels where it had been removed. The minutes describe eight copies, not eight ban instances. Public comments included residents and a school librarian. This establishes a board decision alongside public participation; it does not establish that opposition caused the decision.</p><p>The posted minutes are version 1 with blank signature fields; later approval was not separately checked. The record does not establish the initial removal date or when each copy returned to circulation. No duration is calculated. PEN row 3196 lists <i>The Bible</i> in Davis with an April 2023 month; CNN’s publication date is June 21. These dates describe different fields and remain separate.</p><p><a href="https://meetings.boardbook.org/Documents/DownloadPDF/3987392?org=914">District minutes, page 2</a> · <a href="https://us.cnn.com/2023/06/21/us/utah-davis-school-district-reversal-bible-school-libraries/">CNN article</a>. The official minutes and checksum are included in the research ZIP. The article text is not redistributed.</p>'''
page=page.replace('<h2>How the sample was selected</h2>',section+'<h2>How the sample was selected</h2>',1)
# Replace the monthly table body only.
pos=page.index('<h2>Monthly review coverage</h2>');start=page.index('<tbody>',pos)+7;end=page.index('</tbody>',start)
page=page[:start]+''.join('<tr>'+''.join('<td>'+e(r[k])+'</td>' for k in ['month','frame_records','sample_records','school_topic','outside_school_or_noncontent','unresolved'])+'</tr>' for r in month)+page[end:]
# Replace the exact CNN decision row without rewriting any other reviewed decision.
row35=next(r for r in rows if r['record_id']==rid)
pattern=r'<tr><td>35\..*?</tr>'
replacement=f'<tr><td>35. <a href="{e(d["source_url"])}">{e(row35["title"])}</a><br><small>{rid}</small></td><td>School topic supported</td><td>Davis District (UT)<br><small>at least one supported candidate</small></td><td>{e(d["evidence_summary"])}</td></tr>'
page,nsub=re.subn(pattern,replacement,page,flags=re.S);assert nsub==1
page=page.replace('Thirty-two selected title probes produced twelve title–district correspondences.','The original 32 title probes produced 12 title–district correspondences. This follow-up adds a separate Bible–Davis correspondence and a primary board-decision record.')
page=page.replace('They are not twelve newly verified restriction events.','These correspondences are not newly verified restriction onsets.')
page=page.replace('The final script, <code>review/build_sample_review.py</code>, recreates the sample and aggregates frozen review judgments.','The scripts <code>review/build_sample_review.py</code> and <code>review/build_sample_followup.py</code> recreate the fixed sample and apply the frozen follow-up.')
page=page.replace('<code>sample_review_v11.csv</code>','<code>sample_review_v12.csv</code>').replace('<code>sample_candidate_pairs_v11.csv</code>','<code>sample_candidate_pairs_v12.csv</code>')
page=page.replace('resolve original-page access for the 20 unresolved records','resolve original-page access for the remaining 19 records')
page=re.sub(r'<p><small>No additional BigQuery query.*?</small></p>','<p><small>Review version 12, October 3, 2026. No additional BigQuery query or paid service was used. Earlier versioned files are retained as audit history.</small></p>',page,flags=re.S)
(O/'GDELT_Validation_Sample.html').write_text(page)
report=O/'GDELT_District_Link_Review.html';t=report.read_text();t=re.sub(r'<!-- SAMPLE FOLLOWUP START -->.*?<!-- SAMPLE FOLLOWUP END -->','',t,flags=re.S)
t=t.replace('Latest update: fixed 36-record validation sample','Earlier pass: fixed 36-record validation sample')
fragment='<!-- SAMPLE FOLLOWUP START --><section><h2>Latest update: original article recovered and Davis vote checked</h2><p><b>Version 12.</b> The unchanged 36-record sample now contains 13 supported school-topic records, four other records and 19 unresolved records. Nine support an original district candidate. One primary reinstatement decision is added; no new restriction onset or duration is accepted.</p>'+section+'</section><!-- SAMPLE FOLLOWUP END -->'
t=t.replace('<!-- SAMPLE REVIEW START -->',fragment+'<!-- SAMPLE REVIEW START -->',1);report.write_text(t)
print(json.dumps(summary,indent=2))
