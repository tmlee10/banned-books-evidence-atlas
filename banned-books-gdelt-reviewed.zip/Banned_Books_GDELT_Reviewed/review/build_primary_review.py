#!/usr/bin/env python3
"""Reproduce the six-case primary-source review from frozen, auditable inputs."""
from pathlib import Path
from collections import Counter
import csv,json,hashlib,html,re
H=Path(__file__).resolve().parent;I=H/'inputs';O=H/'outputs'
def load(n):return json.loads((I/n).read_text())
def write(n,rows):
 with (O/n).open('w',encoding='utf-8',newline='')as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
review=load('primary_outcome_review_v7.json');sources=load('primary_source_register_v7.json');attempts=load('primary_access_log_v7.json')
by={r['record_id']:r for r in review};sb={s['source_id']:s for s in sources}
assert len(by)==len(review)==6
for s in sources:assert hashlib.sha256((I/s['evidence_file']).read_bytes()).hexdigest()==s['evidence_sha256']
for r in review:
 for sid in filter(None,r['source_ids'].split(';')):assert sid in sb
 assert r['model_eligible']=='no' and not r['first_inaccessibility_date'] and not r['restriction_duration']
 assert bool(r['primary_confirmed_decision_date'])==(r['primary_review_status']=='confirmed')
write('primary_outcome_review.csv',review);write('primary_source_register.csv',sources)
with (O/'identity_record_review.csv').open(encoding='utf-8-sig',newline='')as f:base=list(csv.DictReader(f))
combined=[]
for b in base:
 r=by.get(b['record_id']);x=dict(b)
 for k in ['primary_review_status','primary_confirmed_decision_date','primary_confirmed_stage','source_ids','primary_evidence_summary','evidence_limits']:
  x[k+'_v7']=r[k]if r else'not_selected_for_v7'if k=='primary_review_status'else''
 combined.append(x)
assert len(combined)==1054 and sum(r['model_eligible']=='yes'for r in combined)==0
write('primary_record_review.csv',combined)
work=[]
for r in review:
 work.append(dict(record_id=r['record_id'],district=r['district'],primary_review_status=r['primary_review_status'],next_action='Independent review of sources and title/PEN linkage; establish access history separately.'if r['primary_review_status']=='confirmed'else'Obtain full approved June 1 decision minutes; compare retained titles and tally.'if r['state']=='CT'else'Obtain June 13 committee minutes or review official recording; verify no-vote procedure.'if r['state']=='MA'else'Obtain March 28 decision minutes; verify tally, scope and implementation separately.'))
write('primary_validation_worklist.csv',work)
counts=dict(Counter(r['primary_review_status']for r in review))
summary=dict(selected_outcomes_reviewed=6,status_counts=counts,confirmed_decision_dates=3,source_register_entries=len(sources),archived_pdf_excerpts=3,webpage_review_notes=2,first_inaccessibility_dates_established=0,independent_human_review_complete=False,model_eligible_records=0,additional_BigQuery_jobs=0,website_updated=False,candidate_records=1054,uncached_records_awaiting_substantive_review=382)
(O/'primary_review_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
e=html.escape
section='''<!-- PRIMARY REVIEW START --><section><h2>Latest update: primary records for six selected outcomes</h2>
<div class="callout"><b>2 October 2026 — version 7.</b> Official records confirm the decision and date in three selected cases. Two other cases have partial primary support, and one remains unconfirmed because the archive did not expose the relevant record. These six cases were selected for procedural review; they are not six verified bans or a representative sample.</div>
<p><b>RQ3:</b> What happened when a district reviewed a challenged book with input from librarians and local residents?</p>
<h3>Decision evidence</h3><table><tr><th>District</th><th>Primary status / date</th><th>What the official evidence supports</th><th>Remaining limit</th></tr>'''
for r in review:
 links=[]
 for sid in filter(None,r['source_ids'].split(';')):
  s=sb[sid];links.append(f'<a href="{e(s["url"],quote=True)}">{e(sid.replace("_"," "))}</a>')
 section+=f'<tr><td>{e(r["district"])}, {r["state"]}</td><td>{e(r["primary_review_status"].replace("_"," "))}<br>{e(r["primary_confirmed_decision_date"] or "No primary-confirmed decision date")}</td><td>{e(r["primary_evidence_summary"])}<br><small>{" · ".join(links)}</small></td><td>{e(r["evidence_limits"])}</td></tr>'
section+='''</table><h3>Corrections and boundaries</h3>
<p>Mead's decision date is now September 12, 2022, replacing the earlier month-only precision in the primary fields. Its minutes record four opposing votes and one abstention on the library-policy revision. Old Rochester's minutes record two separate 7–1 retention votes on June 21, 2023. Forsyth's district register identifies April 18, 2023 as the retention date for <i>Endlessly Ever After</i>, but does not verify the news account's participation or attendance details.</p>
<p>Old Rochester's June minutes were approved September 6; Mead's September 12 minutes were approved September 26. The Old Rochester file linked under June 21 is an agenda packet with older minutes, so the actual June decision was checked in the September packet. The distinction matters: a proposed action is not evidence of an adopted decision.</p>
<p>For Newtown, indexed draft-minute text and a later approval record were located, but the full decision text was not acquired. A vote approving minutes must not be confused with the vote on the books. Hillsborough's district notice confirms a scheduled appeal meeting, not its outcome. Ludlow's corrected news account still describes a proposal that was not put to a vote; the official archive has not yet corroborated it.</p>
<p>These records do not establish when a book first became unavailable, how long a restriction lasted, or whether public participation changed the decision. A retention decision does not itself prove that an implemented ban was reversed. Current retrospective sources cannot be treated as information available to a historical forecasting model.</p>
<h3>How to reproduce and inspect this pass</h3>
<ol><li>Read the six frozen reviews in <code>primary_outcome_review_v7.json</code>.</li><li>Check the source URLs, original PDF page numbers and SHA-256 values in <code>primary_source_register.csv</code>. The package includes selected official minute pages and short webpage review notes. Notes are reviewer summaries, not full source copies.</li><li>Read <code>primary_access_log_v7.json</code> for unsuccessful and partial retrievals. A missing document is an evidence gap, not proof that no action occurred.</li><li>Run <code>python run_all.py</code> from the extracted package. The final script is <code>review/build_primary_review.py</code>.</li><li>Use <code>primary_record_review.csv</code> as the latest combined table. Earlier reported fields remain unchanged for audit history. The new primary fields apply only to the six selected records; linked story copies were not automatically promoted.</li></ol>
<p>The package still contains 1,054 candidate records. The 382 uncached records remain substantively unreviewed, and no record is eligible for a national timing model. Independent human review remains pending. No BigQuery job, paid extraction, website publication, causal estimate or Ohio forecast was added.</p>
<h3>Remaining work</h3><p>Retrieve the outstanding decision records, independently check the three confirmed cases, and then link their titles and stages to PEN records. Descriptive case timelines can follow that linkage; they must not treat policy proposals or retained books as newly imposed bans.</p></section><!-- PRIMARY REVIEW END -->'''
p=O/'GDELT_District_Link_Review.html';doc=p.read_text();doc=re.sub(r'<!-- PRIMARY REVIEW START -->.*?<!-- PRIMARY REVIEW END -->','',doc,flags=re.S)
doc=doc.replace('<h1>Historical district verification and title linkage</h1>','<h1>Historical district verification and title linkage</h1>'+section)
doc=doc.replace('<h2>Latest update: district identities and selected outcomes</h2>','<h2>Earlier pass: district identities and selected news outcomes</h2>')
p.write_text(doc)
print(json.dumps(summary,indent=2))
