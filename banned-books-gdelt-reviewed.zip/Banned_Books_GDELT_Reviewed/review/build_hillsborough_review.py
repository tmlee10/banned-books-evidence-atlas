#!/usr/bin/env python3
"""Reproduce one reviewed Hillsborough linkage offline. Python standard library only.
Frozen review judgments are not independent validation or causal evidence.
"""
from pathlib import Path
from datetime import datetime,timedelta
from collections import Counter
import csv,json,hashlib,html,re,zipfile,xml.etree.ElementTree as ET
H=Path(__file__).resolve().parent;I=H/'inputs';O=H/'outputs'
B=H.parent/'baseline_audit'
if not B.exists():B=H.parent/'gdelt_full_year/package'
def read(p):
 with p.open(encoding='utf-8-sig',newline='')as f:return list(csv.DictReader(f))
def write(n,rows):
 with (O/n).open('w',encoding='utf-8',newline='')as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def load(n):return json.loads((I/n).read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(s):return ' '.join(s.casefold().split())
c=load('hillsborough_decision_v9.json');sources=load('hillsborough_sources_v9.json')
for s in sources:assert digest(I/s['included_path'])==s['included_sha256'],s['source_id']
assert digest(I/'pen_2022_2023.xlsx')=='b5222b5b87fc2ad66c58a22b726eed1ed9169ccfb5e66acbea2b23074981aafe'
assert digest(B/'inputs/gdelt_full_year_raw.csv')=='88a6e77fb209d3f8b095e6dd90fe9ea82d5138bbb61ad996191322533c5774f0'
pen=read(B/'inputs/pen_events.csv');assert len(pen)==3362
# District alias is explicitly reviewed in v6/v7, not a fuzzy match.
district_rows=[r for r in pen if r['state']=='Florida' and norm(r['district'])==norm(c['district'])]
match=[r for r in district_rows if norm(r['title'])==norm(c['title']) and r['author']==c['pen_author']]
assert len(district_rows)==len(match)==1
p=match[0];assert p['sheet']+':'+p['source_row']==c['pen_row_id']
assert p['status']==c['pen_status'] and p['origin']==c['pen_origin']
# Inspect the actual date cell format; the serial day is NOT event-day precision.
ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(I/'pen_2022_2023.xlsx')as z:
 sheet=ET.fromstring(z.read('xl/worksheets/sheet2.xml'))
 cell=sheet.find('.//m:c[@r="I658"]',ns);serial=cell.find('m:v',ns).text
 styles=ET.fromstring(z.read('xl/styles.xml'))
 fmtid=styles.find('m:cellXfs',ns)[int(cell.attrib['s'])].attrib['numFmtId']
 formats={x.attrib['numFmtId']:x.attrib['formatCode']for x in styles.findall('m:numFmts/m:numFmt',ns)}
 fmt=formats[fmtid];assert fmt=='mmmm yyyy'
month=(datetime(1899,12,30)+timedelta(days=float(serial))).strftime('%Y-%m')
assert month==c['pen_month']=='2023-04'
assert c['decision_date']=='2023-03-28' and month!=c['decision_date'][:7]
base=read(O/'case_timeline_record_review.csv');assert len(base)==1054
record=next(r for r in base if r['record_id']==c['record_id'])
assert record['identity_nces_ids_v6']==c['nces_id']
news=next(r for r in load('selected_outcome_review_v6.json')if r['record_id']==c['record_id'])
link=dict(record_id=c['record_id'],nces_id=c['nces_id'],district=c['district'],title=c['title'],author=c['author'],pen_row_id=c['pen_row_id'],pen_source_rows_searched=len(pen),pen_district_rows=len(district_rows),pen_date_raw=serial,pen_date_format=fmt,pen_month=month,decision_date=c['decision_date'],decision_date_basis='Webcast opening plus archive page; not PEN day precision',official_scope=c['official_scope'],pen_status=c['pen_status'],pen_origin=c['pen_origin'],author_match=c['author_match'],link_status=c['link_status'],scope_reconciliation=c['scope_reconciliation'],date_conflict='PEN April 2023 differs from March 28 board decision; cause unresolved',event_link_accepted='no',first_inaccessibility_date='',restriction_duration='',model_eligible='no',independent_human_review='pending')
write('hillsborough_pen_link.csv',[link]);write('hillsborough_source_register.csv',sources)
# Current six-case outcome table supersedes v7 only for this selected record.
primary=load('primary_outcome_review_v7.json')
for x in primary:
 x['review_version_current']='v7'
 if x['record_id']==c['record_id']:
  x.update(primary_review_status=c['primary_review_status'],primary_confirmed_decision_date=c['decision_date'],primary_confirmed_stage=c['decision_stage'],source_ids=c['source_ids'],source_locator='Webcast: opening date and final vote; archive agenda item 1.01; FLDOE PDF pages 1 and 9.',primary_evidence_summary='Caption transcript records 4-3 middle-school removal; state annual report lists same district, title and author.',approval_status='Caption transcript and annual report; approved minutes not acquired.',evidence_limits='PEN month only; transcript header metadata inconsistent; grade scope preserved separately; first inaccessibility unknown; independent human/video check pending.',review_version_current='v9')
write('selected_primary_outcomes_current.csv',primary)
current=[]
for r in base:
 x=dict(r);selected=r['record_id']==c['record_id']
 x['primary_review_status_current']=c['primary_review_status']if selected else r['primary_review_status_v7']
 x['primary_decision_date_current']=c['decision_date']if selected else r['primary_confirmed_decision_date_v7']
 x['pen_review_v9']=c['link_status']if selected else'not_selected_for_v9'
 x['candidate_pen_row_v9']=c['pen_row_id']if selected else''
 x['accepted_pen_row_v9']=''
 x['date_conflict_v9']='PEN April 2023; board decision March 28, 2023'if selected else''
 x['scope_conflict_v9']=c['scope_reconciliation']if selected else''
 current.append(x)
write('hillsborough_record_review.csv',current)
rows=[]
def add(date,precision,typ,description,source,limit):
 rows.append(dict(record_id=c['record_id'],nces_id=c['nces_id'],date=date,date_precision=precision,record_type=typ,description=description,source=source,limitation=limit,model_eligible='no'))
add('2023-03-21','day','district_notice','Notice of March 28 appeal meeting','hillsborough_notice','Scheduled meeting, not a decision.')
add(month,'month','pen_index','One preserved title-district entry',c['pen_row_id'],'Within-month day unknown; no lag calculated.')
add(c['decision_date'],'day','board_decision','4-3 middle-school removal vote','hillsborough_webcast_transcript_v9;hillsborough_webcast_meeting_v9','Decision day; no exact time, physical withdrawal or duration established.')
add(news['displayed_publication_date'],'day_displayed','selected_news','Selected WMNF story',news['source_url'],'Not established as first coverage; historical body availability unverified; within-day order unestablished.')
add(datetime.strptime(record['gdelt_recorded_at'],'%Y%m%d%H%M%S').strftime('%Y-%m-%dT%H:%M:%SZ'),'second_UTC','gdelt_record','Selected GDELT timestamp',c['record_id'],'Not a publication or restriction date; UTC and local news dates are different clocks.')
add('2022-2023','school_year','state_report','Hillsborough: 3 objections, 1 removal','fldoe_objections_2022_23_v9','School-year corroboration; not three bans or an exact decision date.')
write('hillsborough_chronology.csv',rows)
summary=dict(review_version=9,selected_cases_this_pass=1,title_author_district_candidates_this_pass=1,accepted_new_pen_event_links=0,date_conflicts=1,pen_rows_added=0,pen_index_rows=3362,candidate_rows=1054,primary_confirmed_selected_cases=4,partial_primary_selected_cases=1,primary_unconfirmed_selected_cases=1,model_eligible_records=0,independent_human_review='pending',website_updated=False,additional_BigQuery_jobs=0)
(O/'hillsborough_review_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert sum(bool(x['accepted_pen_row_v9'])for x in current)==0
assert sum(bool(x['candidate_pen_row_v9'])for x in current)==1
assert all(x['model_eligible']=='no'for x in current)
# Self-contained visual evidence table. Rows are record types, not time-scale positions.
e=html.escape
svg=['<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="690" viewBox="0 0 1200 690" role="img" aria-labelledby="hill-title hill-desc">','<title id="hill-title">Hillsborough: one reviewed removal, several date fields</title>','<desc id="hill-desc">April 2023 PEN entry; March 28 board vote; March 28 news date; March 29 UTC GDELT timestamp; school-year state confirmation. Dates have different precision. No duration or causal effect estimated.</desc>','<rect width="1200" height="690" fill="#f4f7fa"/>']
def txt(x,y,s,size=19,fill='#173348',weight='normal'):
 svg.append(f'<text x="{x}" y="{y}" font-family="Arial,sans-serif" font-size="{size}" fill="{fill}" font-weight="{weight}">{e(s)}</text>')
txt(36,48,'Hillsborough: one removal, several date fields',30,weight='bold');txt(36,82,'This Book Is Gay · Juno Dawson · NCES 1200870',20)
visual=[('PEN index','April 2023','Month only; differs from board decision month'),('Board decision','28 March 2023','4–3 vote; all district middle schools'),('Selected news page','28 March 2023','WMNF publication label; first coverage unknown'),('GDELT record','29 March 2023, 04:00 UTC','Index timestamp; not the event date'),('Florida annual report','2022–2023 school year','One removal; same title and author')]
for i,(a,b,d)in enumerate(visual):
 y=111+i*83;svg.append(f'<rect x="24" y="{y}" width="1152" height="73" rx="7" fill="white"/>');txt(40,y+31,a,20,weight='bold');txt(330,y+31,b,22,fill='#12695f',weight='bold');txt(330,y+57,d,17,fill='#536b7b')
txt(36,564,'Title and district match; the event link remains provisional.',22,weight='bold')
txt(36,597,'PEN month differs from decision month. Scope and access duration remain unresolved.',18)
txt(36,628,'Rows show evidence types, not elapsed time. Same-day order is not established.',18)
txt(36,660,'Sources: PEN workbook, HCPS webcast archive, Florida DOE, WMNF and GDELT.',16,fill='#536b7b')
svg.append('</svg>');figure='\n'.join(svg);(O/'hillsborough_evidence_chronology.svg').write_text(figure)
section='''<!-- HILLSBOROUGH REVIEW START --><section><h2>Latest update: Hillsborough vote verified; PEN date conflict found</h2>
<div class="callout"><b>2 October 2026 — version 9.</b> One title–author–district candidate was found, but its PEN month conflicts with the board decision month. The event linkage remains provisional; no ban instance is added. Four of the six selected case decisions now have primary-source support for the outcome and day.</div>
<p>The board webcast's opening identifies March 28, 2023. At the end of the meeting, the final motion seeks removal of <i>This Book Is Gay</i> from all Hillsborough middle schools and passes 4–3. Public comment includes a media specialist advocating retention. The Florida Department of Education's 2022–2023 report independently lists Hillsborough, the same title and Juno Dawson, with three objections and one removal.</p>
'''+figure.replace('width="1200" height="690"','style="width:100%;height:auto"',1)+'''
<h3>What matched, and what did not</h3><p>The preserved PEN workbook has one Hillsborough entry: <i>This Book Is Gay</i>, author recorded as <i>Dawson, Juno</i>, on row 658 of <i>Sorted by Author &amp; Title</i>. The explicit author-name equivalence and reviewed district identity support the title and district identification. The date cell is formatted <code>mmmm yyyy</code> and supports April 2023 only. This differs from the March 28 board decision. Whether PEN recorded a later implementation, a reporting month or another date convention is unresolved. Converting its Excel serial does not supply an exact ban day, and April must not be replaced with March without evidence.</p>
<h3>What stays unresolved</h3><ul><li>PEN labels the entry <i>Banned from Libraries and Classrooms</i>; the transcript supports a middle-school removal order. Both source labels are retained. No high-school removal is inferred.</li><li>The transcript has conflicting header metadata: its HTML title references December 2022 and its body heading gives 4 p.m. The spoken opening, linked meeting page and prior district notice agree on March 28, 2023. No exact decision time is assigned.</li><li>This evidence includes caption text, not approved minutes or an independently reviewed video. Independent human review remains pending.</li><li>The physical date when access first ended, any later reversal and restriction duration remain unknown. PEN's origin field remains <i>Unclear</i>.</li></ul>
<h3>How to reproduce this step</h3><ol><li>Run the earlier workbook-to-CSV check and verify the unchanged source hashes.</li><li>Filter the 3,362 PEN rows to Florida and the reviewed Hillsborough district name; this returns one row.</li><li>Compare the title and the explicitly reviewed author-name forms; inspect the original date-cell number format.</li><li>Compare the resulting April interval with the March 28 board decision day. Flag the discrepancy and keep the event link provisional. Preserve both scope labels.</li><li>Export the link, source register, separate date fields and current six-case outcome table. Leave model eligibility off.</li></ol>
<h3>Relevance to the research question</h3><p><b>RQ3:</b> What happened when a district reviewed a challenged book with input from librarians and local residents?</p><p>This case adds a removal outcome to the three previously confirmed retention or policy-rejection examples. The presence of public objections and professional input does not by itself predict the outcome. These selected cases are not a representative comparison and cannot estimate the effect of resistance.</p>
<h3>Files and evidence</h3><p>The latest 1,054-row review table is <code>hillsborough_record_review.csv</code>. Current selected outcomes are in <code>selected_primary_outcomes_current.csv</code>; Newtown and Ludlow still need decision verification. This pass also provides <code>hillsborough_pen_link.csv</code>, <code>hillsborough_chronology.csv</code>, <code>hillsborough_source_register.csv</code>, <code>hillsborough_evidence_chronology.svg</code> and <code>hillsborough_review_summary.json</code>. Earlier versioned fields remain as audit history.</p><ul>'''
for s in sources:section+=f'<li><a href="{e(s["source_url"],quote=True)}">{e(s["source_id"])}</a>: {e(s["locator"])}</li>'
section+='''</ul><p>The ZIP includes the official state PDF and short transcript/archive review notes with original-file hashes. Re-running the package reproduces the frozen judgments; it does not independently adjudicate them. No new BigQuery query, forecast, causal model or website publication was performed.</p></section><!-- HILLSBOROUGH REVIEW END -->'''
report=O/'GDELT_District_Link_Review.html';doc=report.read_text();doc=re.sub(r'<!-- HILLSBOROUGH REVIEW START -->.*?<!-- HILLSBOROUGH REVIEW END -->','',doc,flags=re.S)
doc=doc.replace('<h1>Historical district verification and title linkage</h1>','<h1>Historical district verification and title linkage</h1>'+section).replace('<h2>Latest update: selected-case PEN lookup and chronology</h2>','<h2>Earlier pass: selected-case PEN lookup and chronology</h2>')
report.write_text(doc);print(json.dumps(summary,indent=2))
