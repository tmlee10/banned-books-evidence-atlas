#!/usr/bin/env python3
"""Rebuild alias adjudication and historical enrollment audit from frozen inputs."""
from pathlib import Path
import csv,json,hashlib,collections,html,re
H=Path(__file__).resolve().parent;I=H/'inputs';O=H/'outputs'
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
def dump(n,r):
 with (O/n).open('w',newline='',encoding='utf-8')as f:
  w=csv.DictWriter(f,fieldnames=list(r[0]));w.writeheader();w.writerows(r)
def j(n):return json.loads((I/n).read_text())
checks={}
def check(n,v):
 checks[n]=bool(v)
 if not v:raise AssertionError(n)
meta=j('enrollment_source.json');p=I/meta['extract']
check('enrollment_extract_hash',hashlib.sha256(p.read_bytes()).hexdigest()==meta['extract_sha256'])
en=read(p);typ=meta['analysis_denominator'];den={r['LEAID']:r for r in en if r['TOTAL_INDICATOR']==typ};tot={r['LEAID']:r for r in en if r['TOTAL_INDICATOR']=='Education Unit Total'}
check('unique_total_per_ID_and_type',len(en)==len(den)+len(tot)==37202)
check('same_IDs_in_both_total_types',den.keys()==tot.keys())
check('membership_school_year',all(r['SCHOOL_YEAR']=='2022-2023'for r in en))
off={r['LEAID']:r for r in read(I/'nces_district_office_locations_2223.csv')}
ident=read(O/'historical_nces_validation.csv');dec=j('expanded_article_decisions.json');aliases=j('expanded_identity_decisions.json')
for r in aliases:
 a=off[r['nces_id']];check('reviewed_alias_'+r['nces_id'],a['NAME']==r['historical_name']and a['STATE']==r['historical_state'])
lookup={(r['state'],r['pen_district']):r['nces_id']for r in aliases}
oldids={r['nces_id']for r in ident}
newids={r['confirmed_nces_id']for r in dec if r['confirmed_nces_id']}-oldids
joined=[]
for id in sorted(oldids|newids):
 e=den[id];t=tot[id];a=off[id]
 check('enrollment_state_'+id,e['ST']==a['STATE'])
 check('usable_enrollment_'+id,e['STUDENT_COUNT'].isdigit()and int(e['STUDENT_COUNT'])>0 and e['DMS_FLAG']=='Derived')
 joined.append({'nces_id':id,'historical_name':a['NAME'],'state':a['STATE'],'enrollment_name':e['LEA_NAME'],'school_year':e['SCHOOL_YEAR'],'enrollment_excluding_adult':e['STUDENT_COUNT'],'denominator_flag':e['DMS_FLAG'],'total_including_adult':t['STUDENT_COUNT'],'adult_count_difference':int(t['STUDENT_COUNT'])-int(e['STUDENT_COUNT']),'source_csv_record':e['source_csv_record'],'validation_cohort':'original_33'if id in oldids else 'new_article_geography','study_eligibility':'not_yet_reviewed','model_eligible':'no'})
dump('historical_enrollment_join.csv',joined)
# Full source-registry join is a starting inventory, not an eligible comparison frame.
frame=[]
for id,a in off.items():
 e=den.get(id,{})
 frame.append({'nces_id':id,'name':a['NAME'],'state':a['STATE'],'enrollment_excluding_adult':e.get('STUDENT_COUNT',''),'enrollment_flag':e.get('DMS_FLAG','no_membership_row'),'identity_join':'exact_LEAID','study_eligibility':'not_yet_reviewed','absent_PEN_record_is_zero':'no'})
dump('district_frame_inventory.csv',frame)
q=read(O/'expanded_alias_candidates.csv');prior=read(O/'candidate_review.csv');oldrecords={r['record_id']for r in prior};dmap={r['record_id']:r for r in dec}
check('reviewed_records_in_new_queue',set(dmap)<={r['record_id']for r in q}-oldrecords)
for r in q:
 d=dmap.get(r['record_id']);r['review_date']='';r['resolved_nces_id']='';r['review_basis']=''
 if d:
  r['review_date']=d['review_date'];id=r['candidate_nces_id']or lookup.get((r['state'],r['candidate_district']),'')
  if d['access_status']=='unresolved_access':r['review_status']='unresolved_access'
  elif id==d['confirmed_nces_id']:r['review_status']='supported_district_topic';r['resolved_nces_id']=id
  else:r['review_status']='rejected_geographic_or_name_match'
  r['review_basis']=d['evidence_summary']
 elif r['record_id']in oldrecords:r['review_status']='refer_to_original_candidate_review'
dump('expanded_candidate_adjudication.csv',q)
links=[]
for d in dec:
 x={**d,'title_pen_link_status':'not_reviewed_in_expansion','first_restriction_date_verified':'no'}
 if d['confirmed_nces_id']:x['historical_name']=off[d['confirmed_nces_id']]['NAME'];x['state']=off[d['confirmed_nces_id']]['STATE']
 else:x['historical_name']='';x['state']=''
 links.append(x)
dump('expanded_article_review.csv',links)
pending=[r for r in q if r['record_id']not in oldrecords and r['review_status']in ('pending_not_confirmed','unresolved_access')]
dump('expanded_pending_queue.csv',pending)
s=json.loads((O/'expanded_alias_summary.json').read_text());s.update({'new_records_review_attempted':len(dec),'new_records_body_supported':sum(bool(r['confirmed_nces_id'])for r in dec),'new_records_access_unresolved':sum(r['access_status']=='unresolved_access'for r in dec),'new_records_not_attempted':len({r['record_id']for r in q}-oldrecords-set(dmap)),'reviewed_pair_status_counts':dict(collections.Counter(r['review_status']for r in q if r['record_id']in dmap)),'enrollment_extract_rows':len(en),'enrollment_agencies':len(den),'enrollment_derived_flag_counts':dict(collections.Counter(r['DMS_FLAG']for r in den.values())),'enrollment_original_verified_districts':len(oldids),'enrollment_additional_article_districts':len(newids),'eligible_district_frame_completed':False,'model_ready':False})
check('six_supported_new_articles',s['new_records_body_supported']==6)
check('new_records_partition',s['new_records_not_attempted']+len(dec)==s['new_candidate_records_not_in_original_screen'])
check('no_suppressed_value_converted_to_zero',all(r['enrollment_excluding_adult']==den[r['nces_id']]['STUDENT_COUNT']for r in frame if r['nces_id']in den))
check('no_model_eligibility_in_review',all(r['model_eligible']=='no'for r in links+joined))
s['checks']=checks;(O/'expansion_summary.json').write_text(json.dumps(s,indent=2)+'\n')
# Idempotent HTML appendix; original review totals retain their original scope.
p=O/'GDELT_District_Link_Review.html';doc=p.read_text();doc=re.sub(r'<!-- EXPANSION START -->.*?<!-- EXPANSION END -->','',doc,flags=re.S)
doc=doc.replace('<h2>Earlier review passes: retained results</h2>','')
esc=html.escape
section=f'''<!-- EXPANSION START --><section><h2>Expanded screening and enrollment — latest pass</h2>
<div class="callout"><b>Completed:</b> all 15,767 annual records screened with broader district aliases; enrollment joined for 33 previously verified districts and four additional article-linked districts. <b>Still pending:</b> complete article review, district eligibility, primary-source episode dates and a defensible district-month model.</div>
<p>The expanded screen produced {s['candidate_pairs']:,} record/entity pairs across {s['candidate_records']:,} records, including {s['new_candidate_records_not_in_original_screen']:,} records missed by the original literal-name screen. These are leads, not ban events. All 114 original records were recovered.</p>
<p>The first purposive review batch attempted 15 new records: six supported district-topic coverage and nine could not be read. The remaining {s['new_records_not_attempted']:,} have not been attempted. This is not a random validation sample and does not estimate matching accuracy. The full pending queue is included.</p>
<h3>Why article-level review matters</h3><table><thead><tr><th>District / publication</th><th>Verified coverage and timing limit</th></tr></thead><tbody>'''
for r in links:
 if r['confirmed_nces_id']:section+=f'<tr><td>{esc(r["historical_name"])} ({esc(r["state"])})<br><a href="{esc(r["url"],quote=True)}">{r["publication_date"]}</a></td><td>{esc(r["evidence_summary"])}</td></tr>'
section+='''</tbody></table><p>Name matching also returned Wake County for “in wake of,” San Antonio ISD for a story about North East ISD, and districts in other states with similar names. These incorrect candidate pairs are explicitly rejected in the adjudication file. Two PEN aliases, Keller and Conway, are linked only after manual geography and historical-name checks. Confirmed article links are deduplicated by record and resolved ID; duplicate alias pairs are not separate articles.</p>
<h3>Historical enrollment</h3>'''
section+=f'''<p>The official NCES 2022–2023 LEA membership release provides two retained total rows for each of {len(den):,} agencies. The analysis denominator excludes adult education; original totals and source flags remain available for comparison. All {len(joined)} reviewed district joins have positive derived enrollment. Missing, suppressed and unreported values elsewhere stay as published.</p>
<p>The {len(frame):,}-row district-office inventory is joined by exact seven-digit LEA ID. It includes agencies whose study eligibility has not been checked. It is not yet a national comparison population; unmatched PEN records cannot be interpreted as zero bans. The 19,834 candidate keys also include unresolved PEN aliases and must not be counted as distinct districts.</p>
<p><a href="{meta['catalog_url']}">NCES release description</a> · <a href="{meta['download_url']}">Original membership ZIP</a>. The package includes the 37,202-row total extract, CSV source-row references, source and extract hashes, and extraction code. The 1.43 GB source archive is omitted from the delivery ZIP.</p>
<h3>What can be concluded now</h3><p>The broader search improves coverage and reveals matching errors. Enrollment now supplies a time-matched denominator for reviewed districts. Neither change establishes whether media attention preceded first restrictions across districts. The previous 22-row Alpine month/stage comparison is unchanged. New articles have not yet undergone title-level PEN linkage. No causal model, forecast or website update was produced in this pass.</p>
<p>Next: review the remaining candidates and inaccessible pages; reconcile title, stage and restriction dates against primary district records; screen agency types and operational status for the eligible population; review coding independently before estimating a timing model. All work in this pass used the preserved export and public downloads, with no additional BigQuery query or paid service.</p>
<p><b>Reproduce:</b> run <code>python run_all.py</code> after unzipping. Frozen review decisions are inputs; the program does not pretend to regenerate human article judgments. See <code>expansion_summary.json</code> for {len(checks)} additional passing checks.</p></section><!-- EXPANSION END -->'''
doc=doc.replace('Use the historical identity crosswalk to build the full eligible-district population and acquire time-matched enrollment and staffing. Identity verification alone does not establish eligibility.','Use the new enrollment inventory to define the eligible district population; verify agency types and operating status, then obtain staffing measures where justified.')
doc=doc.replace('Expand matching beyond complete names; test aliases on a sample and assess missed districts.','Finish reviewing the expanded alias queue and audit missed districts. The first 15-record batch is not a representative validation sample.')
doc=doc.replace('<h1>Historical district verification and title linkage</h1>','<h1>Historical district verification and title linkage</h1>'+section+'<h2>Earlier review passes: retained results</h2>');p.write_text(doc)
print(json.dumps({k:v for k,v in s.items()if k!='checks'},indent=2));print('Additional checks:',len(checks),'passed')
