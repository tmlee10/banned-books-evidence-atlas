#!/usr/bin/env python3
"""Offline selected-case PEN lookup and evidence chronology. Python stdlib only.
No absent match becomes zero bans; no GDELT timestamp becomes a ban date.
"""
from pathlib import Path
from collections import Counter
from datetime import datetime,timedelta
import csv,json,hashlib,html,re,unicodedata
H=Path(__file__).resolve().parent;I=H/'inputs';O=H/'outputs'
B=H.parent/'baseline_audit'
if not B.exists():B=H.parent/'gdelt_full_year/package'
def load(n):return json.loads((I/n).read_text())
def read(p):
 with p.open(encoding='utf-8-sig',newline='')as f:return list(csv.DictReader(f))
def write(n,rs):
 with (O/n).open('w',encoding='utf-8',newline='')as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
def norm(s):return ' '.join(unicodedata.normalize('NFKC',s).casefold().split())
def month(raw):
 try:return (datetime(1899,12,30)+timedelta(days=float(raw))).strftime('%Y-%m')
 except ValueError:return ''
scopes=load('selected_case_scope_v8.json');primary={r['record_id']:r for r in load('primary_outcome_review_v7.json')};news={r['record_id']:r for r in load('selected_outcome_review_v6.json')};sources={r['source_id']:r for r in load('primary_source_register_v7.json')}
base=read(O/'primary_record_review.csv');records={r['record_id']:r for r in base};pen=read(B/'inputs/pen_events.csv')
assert len(pen)==3362
assert hashlib.sha256((I/'pen_2022_2023.xlsx').read_bytes()).hexdigest()=='b5222b5b87fc2ad66c58a22b726eed1ed9169ccfb5e66acbea2b23074981aafe'
# build_linkage.py, run earlier in run_all.py, checks every source row against the workbook.
pen_url='https://docs.google.com/spreadsheets/d/1a6v7R7pidO7TIwRZTIh9T6c0--QNNVufcUUrDcz2GJM/edit'
audit=[];links=[];excluded=[];timeline=[]
for c in scopes:
 rid=c['record_id'];p=primary[rid];n=news[rid];r=records[rid]
 assert p['primary_review_status']=='confirmed' and c['nces_id']==p['nces_id']
 sr=[x for x in pen if norm(x['state'])==norm(c['state'])]
 dr=[x for x in sr if norm(x['district'])in{norm(a)for a in c['pen_district_aliases']}]
 matches=[x for x in dr if norm(x['title'])in{norm(t)for t in c['titles']}]
 audit.append(dict(nces_id=c['nces_id'],district=c['district_label'],state=c['state'],pen_school_year='2022-2023',index_rows_searched=len(pen),state_rows=len(sr),state_districts=';'.join(sorted({x['district']for x in sr})),district_aliases_tested=';'.join(c['pen_district_aliases']),district_rows=len(dr),selected_title_district_rows=len(matches),missing_match_meaning='No corresponding row found in this preserved index; not evidence of zero bans or full coverage.',scope_note=c['scope_note']))
 for title in c['titles']or['']:
  tr=[x for x in pen if title and norm(x['title'])==norm(title)];td=[x for x in dr if title and norm(x['title'])==norm(title)]
  assert not td,'New candidate requires title/author/stage review; do not silently auto-link.'
  links.append(dict(record_id=rid,nces_id=c['nces_id'],district=c['district_label'],state=c['state'],title=title,case_type=c['case_type'],primary_decision_date=p['primary_confirmed_decision_date'],primary_stage=p['primary_confirmed_stage'],national_exact_title_rows=len(tr)if title else'',district_title_candidate_rows=len(td)if title else'',link_status='no_title_level_join_for_policy_proposal'if not title else'no_title_district_row_in_preserved_index',accepted_pen_row_ids='',author_review='not_reached_no_title_district_candidate',episode_link='not_established',restriction_duration='',first_inaccessibility_date='',model_eligible='no'))
 # Preserve tempting partial matches to expose why they were not linked.
 for x in pen:
  samet=norm(x['title'])in{norm(t)for t in c['titles']};samed=x in dr
  if samet or samed:
   excluded.append(dict(case_record_id=rid,case_district=c['district_label'],case_titles=';'.join(c['titles']),pen_row_id=x['sheet']+':'+x['source_row'],pen_state=x['state'],pen_district=x['district'],pen_title=x['title'],pen_author=x['author'],pen_date_as_received=x['date_excel_serial_or_text'],pen_month=month(x['date_excel_serial_or_text']),pen_status=x['status'],exclusion_reason='Different title in same district'if samed else'Title appears in a different state/district',accepted_link='no',source_url=pen_url))
 def add(date,typ,label,source,precision,note):
  timeline.append(dict(record_id=rid,nces_id=c['nces_id'],district=c['district_label'],date=date,date_precision=precision,record_type=typ,label=label,source_reference=source,evidence_limit=note,within_day_order='not_established',model_eligible='no'))
 add(p['primary_confirmed_decision_date'],'official_decision',p['primary_confirmed_stage'],p['source_ids'],'day','Decision date; not first inaccessibility or duration.')
 add(n['displayed_publication_date'],'selected_news_publication','Displayed publication date of selected story',n['source_url'],'day_displayed_on_cached_page','Current cached page reviewed; historical body availability and first coverage are unverified.')
 stamp=datetime.strptime(r['gdelt_recorded_at'],'%Y%m%d%H%M%S').strftime('%Y-%m-%dT%H:%M:%SZ')
 add(stamp,'gdelt_record','Selected GDELT record',rid,'second_UTC','GDELT record timestamp, not an event date, publication time or first index appearance.')
 if c['approval_date']:add(c['approval_date'],'minutes_approval','Minutes approved',c['approval_source_id'],'day','Administrative approval of earlier minutes; not a new book decision.')
write('selected_case_pen_scope.csv',audit);write('selected_decision_pen_links.csv',links);write('selected_pen_candidate_exclusions.csv',excluded)
timeline.sort(key=lambda x:(x['nces_id'],x['date'][:10],x['record_type']))
write('selected_case_timeline.csv',timeline)
current=[];ss={c['record_id']:c for c in scopes}
for r in base:
 x=dict(r);c=ss.get(r['record_id']);x['selected_case_pen_review_v8']='no_title_level_join_for_policy_proposal'if c and not c['titles']else'no_title_district_row_in_preserved_index'if c else'not_selected_for_v8';x['accepted_pen_rows_v8']='';current.append(x)
write('case_timeline_record_review.csv',current)
summary=dict(review_date='2026-10-02',selected_cases=len(scopes),title_district_searches=sum(len(c['titles'])for c in scopes),policy_proposals_without_title=1,accepted_new_pen_links=0,excluded_partial_matches=len(excluded),same_district_other_title_rows=sum(x['exclusion_reason']=='Different title in same district'for x in excluded),chronology_records=len(timeline),model_eligible_records=0,candidate_records=len(current),website_updated=False,additional_BigQuery_jobs=0)
(O/'case_timeline_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert len(links)==4 and len(excluded)==29 and len(timeline)==11 and len(current)==1054
# A dated evidence view; column spacing encodes source type, not elapsed time.
e=html.escape
svg=['<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="720" viewBox="0 0 1200 720" role="img" aria-labelledby="t d">','<title id="t">Three selected case chronologies</title>','<desc id="d">Official decisions, displayed news dates and GDELT record times for Mead, Forsyth County and Old Rochester. No matching title-district PEN entries were found. Layout is by record type, not elapsed time.</desc>','<rect width="1200" height="720" fill="#f4f7fa"/>']
def text(x,y,s,size=18,fill='#173348',weight='normal'):
 svg.append(f'<text x="{x}" y="{y}" font-family="Arial, sans-serif" font-size="{size}" fill="{fill}" font-weight="{weight}">{e(s)}</text>')
text(38,48,'Three selected case chronologies',32,weight='bold');text(38,80,'Confirmed decisions, selected reporting and recorded timestamps',20)
for x,label in [(300,'Official decision'),(590,'Displayed news date'),(875,'GDELT record (UTC)')]:text(x,125,label,18,weight='bold')
for i,c in enumerate(scopes):
 y=151+i*153;rid=c['record_id'];p=primary[rid];n=news[rid];stamp=datetime.strptime(records[rid]['gdelt_recorded_at'],'%Y%m%d%H%M%S')
 svg.append(f'<rect x="24" y="{y}" width="1152" height="139" rx="8" fill="white"/>')
 text(40,y+32,c['district_label'],20,weight='bold');text(40,y+59,c['state'],16,fill='#536b7b')
 text(300,y+32,p['primary_confirmed_decision_date'],22,fill='#12695f',weight='bold');text(590,y+32,n['displayed_publication_date'],22,weight='bold');text(875,y+32,stamp.strftime('%Y-%m-%d'),22,fill='#925019',weight='bold');text(875,y+57,stamp.strftime('%H:%M:%S UTC'),16,fill='#925019')
 label='Policy revision rejected'if not c['titles']else'Book retained'if len(c['titles'])==1 else'Two titles retained'
 text(300,y+59,label,16);text(590,y+59,'Selected story; not first coverage',15)
 title='; '.join(c['titles'])or'No title-specific removal order';text(40,y+94,title,17)
 foot='Minutes approved '+c['approval_date']if c['approval_date']else'Official appeal register; attendance and vote tally not checked'
 text(40,y+121,foot,15,fill='#536b7b')
text(38,646,'PEN 2022–2023 lookup: no matching title–district row for these selected decisions.',19,weight='bold')
text(38,675,'Columns show record types, not elapsed time. Same-day order is unknown.',17)
text(38,700,'Sources: district records, reviewed news pages, preserved GDELT records and PEN workbook.',15,fill='#536b7b');svg.append('</svg>');figure='\n'.join(svg)
(O/'selected_case_chronologies.svg').write_text(figure)
section='''<!-- CASE TIMELINE START --><section><h2>Latest update: selected-case PEN lookup and chronology</h2>
<div class="callout"><b>2 October 2026 — version 8.</b> Three confirmed decisions were checked against all 3,362 rows in the preserved 2022–2023 PEN index. No matching title-and-district row was found for the three selected titles. Mead's rejected policy proposal has no title-specific join. No new ban-event link has been accepted.</div>
<p>Old Rochester retained <i>Felix Ever After</i> and <i>Push</i>; Forsyth retained <i>Endlessly Ever After</i>; Mead declined the proposed library-policy revision. A news item about a challenge or retention can be relevant to RQ3 without being a PEN ban instance.</p>
'''+figure.replace('width="1200" height="720"','style="width:100%;height:auto"',1)+'''
<h3>What the lookup found</h3><table><tr><th>Case</th><th>Rows in PEN for this district</th><th>Selected title match</th><th>Interpretation</th></tr>'''
for a in audit:
 note='Four June 2023 entries concern Oryx and Crake, Dime, Perfect and Tilt. None is Endlessly Ever After.'if a['state']=='Georgia'else'Only Abington Public Schools appears in the Massachusetts rows; it is a different district.'if a['state']=='Massachusetts'else'No Washington rows occur in this preserved index. The reviewed decision is a policy proposal, not a title removal.'
 section+=f'<tr><td>{e(a["district"])}</td><td>{a["district_rows"]}</td><td>{"Not applicable: policy proposal"if a["state"]=="Washington"else"None found"}</td><td>{note}</td></tr>'
section+='''</table><p>The district-row counts describe this index only. They are not estimates of all bans, and missing matches must not become zero-event observations. Five national entries for <i>Felix Ever After</i> and 20 for <i>Push</i> belong to other state/district combinations. Joining on title alone would assign those events to the wrong place.</p>
<h3>Dates and evidence</h3><p>The chronology keeps three clocks separate: the official decision day, the date displayed on the selected news page, and the GDELT record timestamp. Where a decision and article share a calendar date, their order within that day is unknown. The reviewed articles are not established as the first coverage of these cases. News-page bodies were retrieved retrospectively; the original text available on the displayed publication date has not been verified.</p>
<p>Old Rochester's September 6, 2023 approval of June minutes falls outside the July 2022–June 2023 study window and is included only as later documentary corroboration. Mead's September 26 approval likewise confirms the earlier minutes, not a second policy decision. No approval date is used as a restriction date.</p>
<h3>Reproducible steps</h3><ol><li>Use the three confirmed cases from version 7; leave the other three outcomes unresolved.</li><li>Validate the preserved workbook and all 3,362 derivative rows using the earlier workbook check in the pipeline.</li><li>Compare state and explicitly reviewed district names before comparing titles. Normalize only Unicode, case and whitespace; do not silently fuzzy-match.</li><li>Record every partial match rejected for another district or another title. No candidate reached author/episode acceptance in this pass.</li><li>Build the dated evidence table from confirmed decision dates, reviewed publication labels and preserved GDELT timestamps. Keep unknown access dates blank.</li></ol>
<p><code>selected_case_pen_scope.csv</code> records the search scope; <code>selected_decision_pen_links.csv</code> records three title searches and one policy case; <code>selected_pen_candidate_exclusions.csv</code> records 29 rejected partial matches; <code>selected_case_timeline.csv</code> contains 11 chronology entries; <code>selected_case_chronologies.svg</code> is the reusable figure. The latest all-record table is <code>case_timeline_record_review.csv</code>.</p>
<p><b>RQ3:</b> What happened when a district reviewed a challenged book with input from librarians and local residents?</p>
<p>These selected examples document procedures and outcomes. They cannot estimate whether librarian involvement or public objections caused retention, or compare treated and untreated districts. The study still needs additional outcome records, independent review, and matched observations before such comparisons. All model-eligibility flags remain no. No new BigQuery query or website publication occurred.</p></section><!-- CASE TIMELINE END -->'''
p=O/'GDELT_District_Link_Review.html';doc=p.read_text();doc=re.sub(r'<!-- CASE TIMELINE START -->.*?<!-- CASE TIMELINE END -->','',doc,flags=re.S);doc=doc.replace('<h1>Historical district verification and title linkage</h1>','<h1>Historical district verification and title linkage</h1>'+section).replace('<h2>Latest update: primary records for six selected outcomes</h2>','<h2>Earlier pass: primary records for six selected outcomes</h2>');p.write_text(doc)
print(json.dumps(summary,indent=2))
