#!/usr/bin/env python3
"""Optional network audit. Public GETs only; obey robots; never log in or bypass blocks.
The offline analysis uses the frozen access ledger and does not run this collector.
"""
from pathlib import Path
import csv,json,time,hashlib,re,threading,urllib.request,urllib.error,urllib.parse,urllib.robotparser,ipaddress
from concurrent.futures import ThreadPoolExecutor,as_completed
from html.parser import HTMLParser
from datetime import datetime,timezone
H=Path(__file__).resolve().parent;I=H/'inputs';C=H/'retrieval_cache';C.mkdir(exist_ok=True)
UA='BannedBooksResearchAudit/1.0';MAX=4*1024*1024
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
opener=urllib.request.build_opener(NoRedirect())
locks={};rules={};last={};delays={};guard=threading.Lock()
def safe(u):
 p=urllib.parse.urlsplit(u);host=p.hostname or ''
 if p.scheme not in ('https','http')or p.username or p.password or p.port not in(None,80,443)or '.'not in host or host.endswith(('.local','.internal','.localhost')):return False
 try:ipaddress.ip_address(host);return False
 except ValueError:return True

def get(u,limit=MAX):
 req=urllib.request.Request(u,headers={'User-Agent':UA,'Accept':'text/html,application/xhtml+xml;q=0.9,*/*;q=0.1'})
 try:
  with opener.open(req,timeout=10)as f:return f.status,dict(f.headers),f.read(limit+1)
 except urllib.error.HTTPError as e:return e.code,dict(e.headers),b''

def allowed(u):
 p=urllib.parse.urlsplit(u);origin=p.scheme+'://'+p.netloc
 with guard:lock=locks.setdefault(origin,threading.Lock())
 with lock:
  if origin not in rules:
   try:
    status,headers,b=get(origin+'/robots.txt',512*1024)
    if status==200:
     rp=urllib.robotparser.RobotFileParser();rp.parse(b.decode('utf-8',errors='replace').splitlines());rules[origin]=(rp,'robots_200')
    elif status in(404,410):rules[origin]=(True,'robots_absent_'+str(status))
    else:rules[origin]=(False,'robots_unresolved_'+str(status))
   except Exception as e:rules[origin]=(False,'robots_error_'+type(e).__name__)
  rp,basis=rules[origin]
  if isinstance(rp,bool):delays[origin]=1;return rp,basis,origin
  delay=rp.crawl_delay(UA)or rp.crawl_delay('*')or 1
  delays[origin]=max(1,delay)
  if delay>10:return False,'robots_crawl_delay_exceeds_audit_limit',origin
  return rp.can_fetch(UA,u),basis,origin
class Text(HTMLParser):
 def __init__(self):super().__init__();self.skip=0;self.parts=[];self.title=[];self.intitle=False;self.meta=[]
 def handle_starttag(self,t,a):
  d=dict(a)
  if t in ('script','style','noscript','svg'):self.skip+=1
  if t=='title':self.intitle=True
  if t=='meta'and any(k in (d.get('property','')+d.get('name','')).lower()for k in ['publish','modified','date']):self.meta.append(d)
 def handle_endtag(self,t):
  if t in ('script','style','noscript','svg')and self.skip:self.skip-=1
  if t=='title':self.intitle=False
 def handle_data(self,d):
  if not self.skip:
   if d.strip():self.parts.append(d.strip())
   if self.intitle:self.title.append(d.strip())

def audit(r):
 u=r['url'];base={'record_id':r['record_id'],'url':u,'checked_utc':datetime.now(timezone.utc).isoformat(),'access_status':'','http_status':'','final_url':u,'robots_basis':'','bytes':0,'sha256':'','page_title':'','text_chars':0,'date_metadata_json':'[]','review_status':'machine_access_check_only'}
 try:
  for _ in range(6):
   if not safe(u):base['access_status']='unsafe_or_nonpublic_url_skipped';return base
   ok,basis,origin=allowed(u);base['robots_basis']=basis
   if not ok:base['access_status']='robots_disallowed_or_unresolved';return base
   with locks[origin]:
    pause=max(0,delays.get(origin,1)-(time.monotonic()-last.get(origin,0)))
    if pause:time.sleep(pause)
    status,headers,b=get(u);last[origin]=time.monotonic()
   base['http_status']=status;base['final_url']=u
   if status in(301,302,303,307,308):
    loc=headers.get('Location')or headers.get('location')
    if not loc:base['access_status']='redirect_without_location';return base
    u=urllib.parse.urljoin(u,loc);continue
   if status!=200:base['access_status']='http_'+str(status);return base
   if len(b)>MAX:base['access_status']='page_exceeds_size_limit';return base
   base['bytes']=len(b);base['sha256']=hashlib.sha256(b).hexdigest()
   ct=headers.get('Content-Type',headers.get('content-type','')).lower()
   if 'html'not in ct:base['access_status']='non_html_response';return base
   enc=re.search(r'charset=([\w-]+)',ct);enc=enc.group(1)if enc else'utf-8'
   try:s=b.decode(enc,errors='replace')
   except LookupError:s=b.decode('utf-8',errors='replace')
   p=Text();p.feed(s);txt='\n'.join(p.parts);base['page_title']=' '.join(p.title)[:500];base['text_chars']=len(txt);base['date_metadata_json']=json.dumps(p.meta)
   title=base['page_title'].lower()
   if any(x in title for x in ['access denied','just a moment','verify you are human','robot or human','attention required','enable cookies']):base['access_status']='challenge_page_not_bypassed'
   elif len(txt)<800:base['access_status']='short_or_empty_page'
   else:base['access_status']='html_retrieved_unreviewed';(C/(r['record_id']+'.txt')).write_text(txt,encoding='utf-8')
   return base
  base['access_status']='redirect_limit';return base
 except Exception as e:base['access_status']='network_error_'+type(e).__name__;return base

if __name__=='__main__':
 rows=list(csv.DictReader((H/'outputs/expanded_pending_queue.csv').open()));done={x['record_id']for x in json.loads((I/'expanded_article_decisions.json').read_text())};todo={}
 for r in sorted(rows,key=lambda r:(-int(r['priority_score']),r['record_id'])):
  if r['record_id']not in done:todo.setdefault(r['record_id'],r)
 log=I/'public_access_attempts.jsonl';prior={}
 if log.exists():
  for l in log.read_text().splitlines():
   x=json.loads(l);prior[x['record_id']]=x
 todo=[r for k,r in todo.items()if k not in prior]
 print('Remaining public URLs:',len(todo),flush=True)
 with log.open('a')as f,ThreadPoolExecutor(max_workers=8)as pool:
  jobs=[pool.submit(audit,r)for r in todo]
  for i,job in enumerate(as_completed(jobs),1):
   x=job.result();f.write(json.dumps(x)+'\n');f.flush()
   if i%25==0:print('Checked',i,'of',len(todo),flush=True)
 print('Access audit finished',flush=True)
