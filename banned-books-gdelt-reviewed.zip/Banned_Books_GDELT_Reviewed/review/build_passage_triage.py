#!/usr/bin/env python3
"""Reproduce passage triage from frozen judgments, offline, without new queries.
This stage does not validate district identity, event onset or causal claims.
"""
from pathlib import Path
from collections import Counter,defaultdict
import csv,json,html,re
H=Path(__file__).resolve().parent;I=H/'inputs';O=H/'outputs'
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(name,rows):
 with (O/name).open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
D=json.loads((I/'passage_triage_decisions.json').read_text())
base=read(O/'latest_record_review.csv');byid={r['record_id']:r for r in base}
inv={r['record_id']:r for r in json.loads((I/'cached_page_inventory.json').read_text())}
assert len(D)==359 and len({d['record_id']for d in D})==359
for d in D:
 b=byid[d['record_id']]
 assert b['content_review_status']=='not_substantively_reviewed' and b['cached_page_available']=='yes'
 assert b['url']==d['url'] and d['cache_sha256']==inv[d['record_id']]['cache_sha256']
 assert d['model_eligible']=='no' and d['independent_human_review']=='pending'
dm={d['record_id']:d for d in D};latest=[]
for b in base:
 a=dict(b);a['prior_content_review_status']=b['content_review_status'];a['district_name_lead']='';a['passage_review_limit']=''
 if b['record_id']in dm:
  d=dm[b['record_id']];a['content_review_status']=d['decision'];a['review_basis']=d['review_basis'];a['review_note']=d['evidence_note'];a['review_cohort']='remaining_cache_triage'
  a['district_name_lead']=d['district_name_lead'];a['passage_review_limit']='Selected excerpt only; full context, identity and dates remain unvalidated.'
  # No speculative NCES joins or dates are introduced by passage triage.
  a['confirmed_nces_id']='';a['story_family_id']='';a['model_eligible']='no'
 latest.append(a)
write('cache_triage_record_review.csv',latest);write('cache_triage_decisions.csv',D)
remaining=[]
for r in latest:
 status=r['content_review_status']
 if status=='not_substantively_reviewed':action='Find an accessible public or primary source; do not infer from headline.'
 elif status=='unresolved_article_evidence':action='Obtain readable relevant evidence; leave missing until obtained.'
 elif status=='passage_supports_district_topic':action='Read full context; validate NCES district, story relationships, policy stage and dates.'
 elif status.startswith('passage_'):action='Confirm excerpt-based scope judgment before final exclusion.'
 elif status=='supported_district_topic':action='Independent human review; validate story grouping and restriction onset before modeling.'
 else:continue
 remaining.append(dict(record_id=r['record_id'],status=status,next_action=action,title=r['title'],url=r['url'],district_name_lead=r['district_name_lead'],review_note=r['review_note']))
write('validation_worklist.csv',remaining)
# Equal selected excerpts are only review leads. They do not establish full-body
# equality, common authorship or independent event counts. No rows are collapsed.
groups=defaultdict(list)
for d in D:
 if d['selected_passage_sha256'] and d['selected_passage_characters']>=200:groups[d['selected_passage_sha256']].append(d)
repeats=[]
for digest,rs in sorted(groups.items()):
 if len(rs)<2:continue
 for d in rs:repeats.append(dict(passage_group=digest,record_id=d['record_id'],url=d['url'],records_in_group=len(rs),basis='identical selected excerpt only',verified_story_family='no',collapse_records='no'))
if repeats:write('identical_passage_review_leads.csv',repeats)
counts=Counter(r['content_review_status']for r in latest);batch=Counter(d['decision']for d in D)
summary=dict(candidate_records=len(latest),remaining_cache_records_assessed=len(D),selected_passage_reviews=sum(d['review_basis']=='assistant_selected_passage_triage'for d in D),encoded_access_assessments=sum(d['review_basis']=='encoded_body_access_assessment'for d in D),batch_counts=dict(batch),combined_counts=dict(counts),cached_records_without_any_review_disposition=sum(r['content_review_status']=='not_substantively_reviewed'and r['cached_page_available']=='yes'for r in latest),uncached_records_not_substantively_reviewed=sum(r['content_review_status']=='not_substantively_reviewed'and r['cached_page_available']=='no'for r in latest),earlier_supported_district_topic_records=sum(r['content_review_status']=='supported_district_topic'for r in latest),new_district_topic_passage_leads=batch['passage_supports_district_topic'],new_confirmed_district_links=0,identical_selected_passage_groups=len({r['passage_group']for r in repeats}),records_collapsed=0,full_article_review_complete=False,independent_human_review_complete=False,model_eligible_records=sum(r['model_eligible']=='yes'for r in latest),additional_BigQuery_jobs=0,website_updated=False)
assert sum(counts.values())==1054 and summary['cached_records_without_any_review_disposition']==0
assert summary['uncached_records_not_substantively_reviewed']==382 and summary['model_eligible_records']==0
(O/'cache_triage_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
e=html.escape
section=f'''<!-- PASSAGE TRIAGE START --><section><h2>Latest update: all remaining cached records assessed</h2>
<div class="callout"><b>2 October 2026.</b> The 359 previously unreviewed cached records now have a disposition: 278 received selected-passage review and 81 received an encoded-page access assessment. This completes the cache triage. Full article verification and independent human review remain unfinished.</div>
<p>The earlier 206 supported district-topic records remain separate from <b>{batch['passage_supports_district_topic']} new passage-level leads</b>. This pass creates no confirmed NCES links and no new ban counts. News about a proposal, lawsuit, retention decision or public meeting is relevant to the topic without establishing a restriction.</p>
<h3>Results of this pass</h3><table><tr><th>Disposition</th><th>Records</th><th>Meaning</th></tr>'''
meaning={'passage_supports_district_topic':'Relevant local school topic appears in the selected passage; district identity and full context pending.','passage_outside_school_scope':'Selected passage concerns another setting, such as a public library, prison or non-U.S. school. Provisional scope decision.','passage_noncontent_match':'Selected passage uses challenge or restriction in an unrelated sense. Provisional scope decision.','passage_context_only':'General, historical or policy context; no district restriction established by the passage.','unresolved_article_evidence':'Encoded, empty, boilerplate, incomplete or insufficiently specific evidence. No inferred outcome.'}
for k,v in sorted(batch.items()):section+=f'<tr><td>{e(k.replace("_"," "))}</td><td>{v}</td><td>{e(meaning[k])}</td></tr>'
section+='''</table><h3>What the evidence can and cannot show</h3>
<p>Several passages describe rejected proposals or books retained after review, including Mead, Forsyth County, Newtown, Ludlow and Old Rochester. Others describe requests, campaign promises or committee recommendations. These stages need separate coding. They cannot all be counted as bans.</p>
<p>Current pages for Hillsborough, Newtown, Orange Unified and other districts include outcomes or updates that differ from the earlier captured headline. The GDELT timestamp is a news-record timestamp. It does not establish when student access changed, or that the current page text was available then. Models must use only information available before a forecast period.</p>
<p>Caption-only matches remain weaker leads. District names such as Madison, Hempfield and Rochester require exact geographic verification. A library located in a city is not automatically part of the city's school system. No person’s beliefs or motives are inferred from district characteristics.</p>
<h3>Method and audit trail</h3>
<p>The assistant read selected passages from 278 cached records. A deterministic extractor selected unique long lines and filtered common boilerplate; it can still select captions or miss relevant text. Per-record notes, source URLs, cache hashes, passage lengths and passage hashes are frozen in the input JSON. The report does not claim a complete read of every article. Two passages visibly contained encoded text despite the earlier quality heuristic missing them; both remain unresolved. The 81 other encoded pages were assessed for access only and were not decoded.</p>'''
section+=f'''<p>There are {summary['identical_selected_passage_groups']} groups with identical selected passages. These are possible repeats to check against full article provenance; they are not newly verified story families. No records were collapsed. The previous 28 verified/comparison-supported families remain limited to their earlier review batch.</p>
<h3>What remains</h3><p><b>382 records still have no usable cached text and have not received substantive review.</b> Their recorded access outcomes are retained. The new {batch['passage_supports_district_topic']} district-topic leads need full-context review, exact NCES matching, repetition checks and defensible dates. Unresolved excerpts need accessible source evidence; missing evidence must not become zero bans.</p>
<p><b>RQ3:</b> What happened when a district reviewed a challenged book with input from librarians and local residents?</p>
<p>District matching will use the NCES directory and manual review where necessary. Every event must have a school year; months require source support or a precision flag. Exact and probable duplicates will be documented before combination. Statewide restrictions remain separate. Counts must reconcile with PEN definitions, and missingness must be reported by state and school year. The evidence assembled so far does not estimate the effect of public opposition.</p>
<h3>Files and reproduction</h3><p>Use <code>cache_triage_record_review.csv</code> for all 1,054 current dispositions, <code>cache_triage_decisions.csv</code> for this pass, and <code>validation_worklist.csv</code> for next actions. Earlier files beginning <code>latest_</code> represent the preceding full-content pass and are retained for comparison. Run <code>python run_all.py</code> to reproduce the package offline. Frozen judgments are inputs, not independent validation. Full third-party article text is excluded.</p>
<p>No additional BigQuery job or paid extraction was run. The public website has not been changed by this review.</p>
<details><summary>Open all 359 decisions and source links</summary><table><tr><th>Source</th><th>Disposition</th><th>Evidence note</th></tr>'''
for d in D:
 r=byid[d['record_id']];section+=f'<tr><td><a href="{e(d["url"],quote=True)}">{e(r["title"])}</a><br><small>{e(d["record_id"])}</small></td><td>{e(d["decision"].replace("_"," "))}</td><td>{e(d["evidence_note"])}</td></tr>'
section+='</table></details></section><!-- PASSAGE TRIAGE END -->'
p=O/'GDELT_District_Link_Review.html';doc=p.read_text();doc=re.sub(r'<!-- PASSAGE TRIAGE START -->.*?<!-- PASSAGE TRIAGE END -->','',doc,flags=re.S)
doc=doc.replace('<h1>Historical district verification and title linkage</h1>','<h1>Historical district verification and title linkage</h1>'+section)
doc=doc.replace('<h2>Content review and repeated coverage</h2>','<h2>Earlier pass: content review and repeated coverage</h2>').replace('<b>Latest pass, 2 October 2026:</b>','<b>Earlier pass, 2 October 2026:</b>')
p.write_text(doc)
print(json.dumps(summary,indent=2))
