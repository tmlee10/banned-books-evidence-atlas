#!/usr/bin/env python3
"""Offline Newtown/Ludlow verification and six-case synthesis. Standard library only."""
from pathlib import Path
from datetime import datetime
from collections import Counter
import csv,json,hashlib,html,re,zipfile,xml.etree.ElementTree as ET
H=Path(__file__).resolve().parent;I=H/'inputs';O=H/'outputs';B=H.parent/'baseline_audit'
if not B.exists():B=H.parent/'gdelt_full_year/package'
def load(n):return json.loads((I/n).read_text())
def read(p):
 with p.open(encoding='utf-8-sig',newline='')as f:return list(csv.DictReader(f))
def write(n,rows):
 fields=list(dict.fromkeys(k for r in rows for k in r))
 with (O/n).open('w',encoding='utf-8',newline='')as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
cases=load('followup_decisions_v10.json');sources=load('followup_sources_v10.json');hill=load('hillsborough_date_followup_v10.json')
for s in sources:assert sha(I/s['included_path'])==s['included_sha256'],s['source_id']
assert sha(I/'pen_2022_2023.xlsx')=='b5222b5b87fc2ad66c58a22b726eed1ed9169ccfb5e66acbea2b23074981aafe'
assert sha(B/'inputs/gdelt_full_year_raw.csv')=='88a6e77fb209d3f8b095e6dd90fe9ea82d5138bbb61ad996191322533c5774f0'
with zipfile.ZipFile(I/'pen_2022_2023.xlsx')as z:
 ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'};root=ET.fromstring(z.read('xl/worksheets/sheet2.xml'))
 assert not [x for x in root.findall('.//m:hyperlink',ns)if '658'in x.attrib.get('ref','')]
 assert not any('comments'in n.lower()for n in z.namelist())
pen=read(B/'inputs/pen_events.csv');assert len(pen)==3362
write('followup_source_register_v10.csv',sources);write('followup_access_log_v10.csv',load('followup_access_log_v10.json'))
write('hillsborough_date_followup_v10.csv',[hill])
news={r['record_id']:r for r in load('selected_outcome_review_v6.json')};updated={c['record_id']:c for c in cases}
primary=read(O/'selected_primary_outcomes_current.csv');assert len(primary)==6
for r in primary:
 if r['record_id']in updated:
  c=updated[r['record_id']]
  r.update(primary_review_status=c['primary_review_status'],primary_confirmed_decision_date=c['decision_date'],primary_confirmed_stage=c['stage'],source_ids=c['source_ids'],source_locator='; '.join(s['locator']for s in sources if s['source_id']in c['source_ids']),primary_evidence_summary=c['outcome'],approval_status=c['approval_status'],evidence_limits=c['evidence_limits'],review_version_current='v10')
 r['titles_reviewed']=news[r['record_id']]['titles']
 r['primary_vote_v10']=updated[r['record_id']]['primary_vote']if r['record_id']in updated else'not_reassessed_this_pass'
 r['model_eligible']='no'
write('selected_case_outcomes_v10.csv',primary)
lookup=[]
for c in cases:
 sr=[r for r in pen if r['state']==c['state']];dr=[r for r in sr if r['district'].casefold()in{c['district'].casefold(),'newtown public schools','ludlow public schools'}]
 assert not dr
 for title in c['titles']or['']:
  lookup.append(dict(record_id=c['record_id'],nces_id=c['nces_id'],district=c['district'],state=c['state'],selected_title=title,index_rows_searched=len(pen),state_rows=len(sr),state_districts='; '.join(sorted({r['district']for r in sr})),district_rows=len(dr),national_same_title_rows=sum(r['title'].casefold()==title.casefold()for r in pen)if title else'',result='no_matching_district_row'if title else'policy_proposal_no_title_level_join',accepted_event_link='no',interpretation='Absence from this index does not establish zero bans or uninterrupted access.'))
write('followup_pen_lookup_v10.csv',lookup)
base=read(O/'hillsborough_record_review.csv');current=[]
for r in base:
 x=dict(r)
 if r['record_id']in updated:
  c=updated[r['record_id']];x.update(primary_review_status_current=c['primary_review_status'],primary_decision_date_current=c['decision_date'])
 x['review_update_v10']='primary_outcome_supported'if r['record_id']in updated else'hillsborough_conflict_still_unresolved'if r['record_id']==hill['record_id']else'not_reassessed_v10'
 x['accepted_pen_event_link_v10']='no';current.append(x)
write('current_record_review_v10.csv',current)
assert len(current)==1054 and all(r['model_eligible']=='no'for r in current)
# Harmonize the separate clocks from the selected-case reviews without imputing dates.
timeline=[]
for r in read(O/'selected_case_timeline.csv'):
 timeline.append(dict(record_id=r['record_id'],nces_id=r['nces_id'],date=r['date'],precision=r['date_precision'],record_type=r['record_type'],description=r['label'],source=r['source_reference'],limitation=r['evidence_limit']))
for r in read(O/'hillsborough_chronology.csv'):
 timeline.append(dict(record_id=r['record_id'],nces_id=r['nces_id'],date=r['date'],precision=r['date_precision'],record_type=r['record_type'],description=r['description'],source=r['source'],limitation=r['limitation']))
records={r['record_id']:r for r in current}
for c in cases:
 n=news[c['record_id']];r=records[c['record_id']]
 def add(date,precision,typ,label,source,limit):timeline.append(dict(record_id=c['record_id'],nces_id=c['nces_id'],date=date,precision=precision,record_type=typ,description=label,source=source,limitation=limit))
 add(c['decision_date'],'day','board_outcome',c['outcome'],c['source_ids'],c['evidence_limits'])
 add(n['displayed_publication_date'],'day_displayed','selected_news_publication','Selected story publication label',n['source_url'],'Not first coverage; retrospective body; same-day order not established.')
 add(datetime.strptime(r['gdelt_recorded_at'],'%Y%m%d%H%M%S').strftime('%Y-%m-%dT%H:%M:%SZ'),'second_UTC','gdelt_record','Selected index timestamp',c['record_id'],'Not publication or event time.')
 if c['nces_id']=='2507050':add('2023-06-27','day','minutes_approval','June 13 minutes approved in 5-0 consent vote','ludlow_june27_approval_v10','Not a vote on adopting the library policy.')
assert len(timeline)==24;write('selected_six_case_chronology_v10.csv',timeline)
outcomes=Counter('retention'if r['primary_confirmed_stage']in['retained_after_review','retained_after_appeal']else r['primary_confirmed_stage']for r in primary)
summary=dict(review_version=10,cases_reviewed_this_pass=2,primary_supported_selected_cases=len(primary),acquired_draft_minutes_cases=1,new_primary_PDF_sources=3,new_accepted_pen_event_links=0,unresolved_hillsborough_date_conflicts=1,selected_case_outcomes=dict(outcomes),chronology_records=len(timeline),candidate_records=len(current),model_eligible_records=0,independent_human_review='pending',additional_BigQuery_jobs=0,website_updated=False)
(O/'followup_summary_v10.json').write_text(json.dumps(summary,indent=2)+'\n')
# Outcome overview, not a statistical chart of incidence.
e=html.escape;svg=['<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="740" viewBox="0 0 1200 740" role="img" aria-labelledby="six-title six-desc">','<title id="six-title">Six selected district outcomes</title>','<desc id="six-desc">Three retention decisions, one rejected policy revision, one proposal without an adoption vote, and one middle-school removal. These are selected cases, not a representative sample or six bans.</desc>','<rect width="1200" height="740" fill="#f4f7fa"/>']
def txt(x,y,s,size=18,color='#173348',weight='normal'):svg.append(f'<text x="{x}" y="{y}" font-family="Arial,sans-serif" font-size="{size}" fill="{color}" font-weight="{weight}">{e(s)}</text>')
txt(36,46,'Six selected district outcomes',32,weight='bold');txt(36,80,'Primary records support the procedural outcome in each case.',20)
visual=[('Mead','12 Sep 2022','Policy revision rejected','4 nay; 1 abstention'),('Hillsborough','28 Mar 2023','Middle-school removal','PEN month: April; link provisional'),('Forsyth County','18 Apr 2023','One title retained','District appeal register'),('Newtown','1 Jun 2023','Two titles retained','Draft minutes; unanimous, tally unresolved'),('Ludlow','13 Jun 2023','No policy-adoption vote','No second; separate procedural vote'),('Old Rochester','21 Jun 2023','Two titles retained','Two separate 7–1 votes')]
for i,(district,date,outcome,note)in enumerate(visual):
 y=108+i*82;svg.append(f'<rect x="24" y="{y}" width="1152" height="73" rx="7" fill="white"/>');txt(40,y+31,district,22,weight='bold');txt(285,y+31,date,20);txt(530,y+30,outcome,21,color='#12695f',weight='bold');txt(530,y+57,note,16,color='#536b7b')
txt(36,631,'Selected procedural cases: not six bans and not a representative district sample.',20,weight='bold');txt(36,664,'No causal effect, restriction duration or national resistance rate is estimated.',18);txt(36,697,'Sources: district minutes, decision registers, webcast records and preserved PEN index.',16,color='#536b7b');svg.append('</svg>');figure='\n'.join(svg);(O/'selected_six_case_outcomes_v10.svg').write_text(figure)
section='''<!-- FOLLOWUP REVIEW START --><section><h2>Latest update: Newtown and Ludlow outcomes verified</h2><div class="callout"><b>2 October 2026 — version 10.</b> Both remaining selected cases now have acquired primary records supporting the outcome and day. Newtown's copy is a draft; Ludlow's record has later approval. The six-case review is complete at the procedural-outcome level, while independent review, access histories and the Hillsborough date discrepancy remain outstanding.</div>'''+figure.replace('width="1200" height="740"','style="width:100%;height:auto"',1)+'''
<h3>Newtown: retention, with a process for individual concerns</h3><p>The June 1, 2023 minutes record a motion for <i>Flamer</i> and <i>Blankets</i> to remain in the high-school library while the administration develops a process for individual parent or guardian concerns. The motion passes unanimously. The discussion clarifies that the books would remain available even before that process existed.</p><p>The downloaded copy is marked pending approval. Its attendance list is internally inconsistent: the secretary is marked absent but appears in the discussion and seconds the motion; another name appears twice. The review therefore records <i>unanimous</i>, without converting the roster into a 5–0 tally. A later official record indexes approval of June 1 minutes, but a final corrected June 1 copy was not acquired. Earlier access interruptions remain a separate question.</p>
<h3>Ludlow: distinguish the two motions</h3><p>The signed June 13 minutes record a procedural motion about legal concerns, with two yes and three no responses. The later motion to adopt the proposed IJL Library Resources policy received no second, so no adoption vote occurred. The June 27 minutes approve the earlier minutes in a 5–0 consent-calendar vote. These are three different actions; neither numeric tally is a vote to ban books.</p>
<h3>PEN lookup and the remaining date discrepancy</h3><p>The preserved 2022–2023 index contains no Connecticut rows. Its only Massachusetts district is Abington, not Ludlow. No Newtown title–district link or Ludlow title-specific policy link is accepted. Missing index coverage is not a zero-ban observation.</p><p>Hillsborough's March 28 board decision still differs from PEN's April 2023 field. The preserved workbook has no row-specific source hyperlink or comments explaining the entry. Reporting month, later implementation or an index error are possible explanations, not findings. Both dates and both scope labels remain unchanged; no timing estimate uses this provisional link.</p>
<h3>Steps completed</h3><ol><li>Follow the public district archive links into the relevant school-year and meeting folders.</li><li>Download the Newtown June 1 and Ludlow June 13/27 PDFs; record original hashes, acquisition times and the navigation path.</li><li>Read the minutes, use OCR for scanned Ludlow pages, and inspect the decision and approval pages visually.</li><li>Keep draft status, attendance discrepancies, procedural votes and later approval separate.</li><li>Check the preserved PEN index by state and district before searching titles. Retain missing matches and conflicts explicitly.</li><li>Regenerate the current 1,054-row ledger, six-case outcome table and 24-record chronology offline.</li></ol>
<h3>What this adds to RQ3</h3><p><b>What happened when a district reviewed a challenged book with input from librarians and local residents?</b></p><p>The selected cases show different outcomes following review or public discussion: retention, rejection of a proposed policy, a proposal that never reached an adoption vote, and removal. These records help define outcome categories. They cannot show how common any outcome is or whether public opposition caused it. The cases were selected for review and have different institutions, proposals and evidence types.</p>
<h3>Current files and next evidence</h3><p>Use <code>current_record_review_v10.csv</code> for the latest all-record ledger and <code>selected_case_outcomes_v10.csv</code> for the six cases. The chronology, PEN lookup, source register, access log and reusable SVG accompany them. Older versioned tables remain audit history. The PDF excerpts preserve decision context while omitting unnecessary public-comment details; their transformations and original hashes are recorded.</p><p>Next, obtain PEN's underlying source for the Hillsborough April field and a corrected/final Newtown minutes copy, then extend the review to a defined larger sample. Independent checking and known access dates are still needed before duration or timing models. No new paid query, model, forecast or website publication occurred.</p><ul>'''
for s in sources:section+=f'<li><a href="{e(s["source_url"],quote=True)}">{e(s["source_id"])}</a> — {e(s["locator"])}</li>'
section+='</ul></section><!-- FOLLOWUP REVIEW END -->'
p=O/'GDELT_District_Link_Review.html';doc=p.read_text();doc=re.sub(r'<!-- FOLLOWUP REVIEW START -->.*?<!-- FOLLOWUP REVIEW END -->','',doc,flags=re.S);doc=doc.replace('<h1>Historical district verification and title linkage</h1>','<h1>Historical district verification and title linkage</h1>'+section).replace('<h2>Latest update: Hillsborough vote verified; PEN date conflict found</h2>','<h2>Earlier pass: Hillsborough vote verified; PEN date conflict found</h2>');p.write_text(doc)
print(json.dumps(summary,indent=2))
