#!/usr/bin/env python3
"""Reconcile source dates directly to XLSX cells; correct prose and prepare human review."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timedelta
from decimal import Decimal,InvalidOperation
import csv,json,zipfile,xml.etree.ElementTree as ET,hashlib,html,re
H=Path(__file__).resolve().parent;I=H/'inputs';O=H/'outputs'
def read(n):return list(csv.DictReader((O/n).open(encoding='utf-8-sig',newline='')))
def write(n,rs):
 with (O/n).open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
def e(x):return html.escape(str(x))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
penpath=H.parent/'baseline_audit/inputs/pen_events.csv'
if not penpath.exists():penpath=H.parent/'gdelt_full_year/package/inputs/pen_events.csv'
pen=list(csv.DictReader(penpath.open()));assert len(pen)==3362
workbook=I/'pen_2022_2023.xlsx';assert digest(workbook)=='b5222b5b87fc2ad66c58a22b726eed1ed9169ccfb5e66acbea2b23074981aafe'
N={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'};R='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
with zipfile.ZipFile(workbook) as z:
 wb=ET.fromstring(z.read('xl/workbook.xml'));assert wb.find('m:workbookPr',N).get('date1904','0') in ('0','false')
 rels={r.get('Id'):r.get('Target') for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
 sheet=next(s for s in wb.find('m:sheets',N) if s.get('name')=='Sorted by Author & Title')
 path='xl/'+rels[sheet.get(R)];assert path=='xl/worksheets/sheet2.xml'
 strings=[''.join(t.itertext()) for t in ET.fromstring(z.read('xl/sharedStrings.xml'))]
 cells={}
 for r in ET.fromstring(z.read(path)).findall('.//m:row',N):
  cells[r.get('r')]={}
  for c in r:
   v=c.find('m:v',N);value='' if v is None else v.text
   cells[r.get('r')][re.sub(r'\d','',c.get('r'))]=strings[int(value)] if c.get('t')=='s' else value
 # Freeze the workbook's precision definition instead of interpreting serial day 1 as onset.
 method=ET.fromstring(z.read('xl/worksheets/sheet3.xml'));methodtexts=[]
 for c in method.findall('.//m:c',N):
  v=c.find('m:v',N)
  if c.get('t')=='s' and v is not None:methodtexts.append(strings[int(v.text)])
 assert any('approximate month and year' in x for x in methodtexts)
audit=[]
for r in pen:
 c=cells[r['source_row']]
 for col,k in [('A','title'),('B','author'),('G','state'),('H','district'),('J','status')]:assert c.get(col,'')==r[k],(r['source_row'],k)
 raw=c.get('I','');old=r['date_excel_serial_or_text'];month=''
 try:
  assert Decimal(raw)==Decimal(old)
  date=datetime(1899,12,30)+timedelta(days=float(raw));month=date.strftime('%Y-%m');precision='approximate_month'
 except InvalidOperation:
  assert raw==old;precision='coarse_text_or_missing'
 audit.append(dict(pen_source_sheet=r['sheet'],pen_source_row=r['source_row'],date_cell='I'+r['source_row'],title=r['title'],district=r['district'],source_value=raw,extracted_value=old,pen_month=month,precision=precision,source_match='yes'))
assert len(audit)==3362 and len({r['pen_source_row'] for r in audit})==3362
write('pen_date_cell_audit_v13.csv',audit);am={r['pen_source_row']:r for r in audit}
probes=read('sample_title_probes_v11.csv')
for r in probes:
 if r['pen_source_row']:assert r['pen_month_or_text']==(am[r['pen_source_row']]['pen_month'] or am[r['pen_source_row']]['source_value'])
 if r['pen_source_row']=='818':r['limitation']='PEN and the reviewed article both indicate March 2023. The earlier February statement was a report-writing error. Exact onset day and classroom scope remain unverified.'
 if r['pen_source_row']=='926':r['limitation']='PEN records March 2023; the reviewed article refers to an April committee meeting. These may describe different stages, but their relationship and the access-change date remain unresolved.'
write('sample_title_probes_v13.csv',probes)
cases=[('818','20230410231500-858','Indian River','February 2023','2023-03','month_agreement_not_exact_event_link','PEN and the reviewed article both indicate March. The prior claimed month conflict was a prose error. Exact onset and classroom scope remain unverified.'),('926','20230524104500-1087','Miami-Dade','February 2023','2023-04','stage_or_date_difference_unresolved','March index month versus reported April committee meeting. No new primary record explains the sequence.'),('3196','20230622013000-389','Davis','April 2023','2023-06-20','different_event_stages','May index month versus June reinstatement decision. An exact removal date, implementation date and duration are not established.'),('658','20230329040000-1261','Hillsborough','April 2023','2023-03-28','date_and_scope_difference_unresolved','April index month versus March board decision. No acquired source explains the difference; neither date is overwritten.')]
focus=[]
for rn,rid,short,prior,other,status,note in cases:
 a=am[rn];focus.append(dict(record_id=rid,pen_source_row=rn,date_cell=a['date_cell'],district=a['district'],title=a['title'],previous_report_month=prior,verified_pen_month=a['pen_month'],comparison_date_or_month=other,comparison_type='news_reported_removal_month' if rn=='818' else 'news_reported_committee_month' if rn=='926' else 'primary_board_decision_date',status=status,note=note,accepted_exact_onset='no',duration_days='',model_eligible='no'))
assert [r['verified_pen_month'] for r in focus]==['2023-03','2023-03','2023-05','2023-04']
write('date_corrections_v13.csv',focus)
sample=read('sample_review_v12.csv');current=read('current_record_review_v12.csv');write('sample_review_v13.csv',sample);write('current_record_review_v13.csv',current)
summary=json.loads((O/'sample_summary_v12.json').read_text());summary.update(review_version=13,review_date='2026-10-04',changed_article_decisions_this_pass=0,pen_workbook_rows_checked=3362,pen_workbook_date_precision=dict(Counter(r['precision'] for r in audit)),report_month_errors_corrected=3,independent_human_review='pending',human_review_responses_received=0)
(O/'sample_summary_v13.json').write_text(json.dumps(summary,indent=2)+'\n')
# The response template deliberately excludes prior judgments and candidate suggestions.
blind=[dict(sample_number=r['sample_number'],record_id=r['record_id'],title=r['title'],original_url=r['original_url'],reviewed_url='',access_status='',topic_verdict='',district_status='',district_name='',district_state='',nces_id='',publisher_date='',date_precision='',event_date='',event_stage='',evidence_note='') for r in sample]
blank=dict(protocol='banned-books-independent-review-v13',reviewer='',review_date='',independent_first_pass=False,records=blind)
(O/'Independent_Review_Template.json').write_text(json.dumps(blank,indent=2)+'\n')
# Current prose is generated from verified workbook months. Historical outputs are retained.
page=(O/'GDELT_Validation_Sample.html').read_text();(O/'GDELT_Validation_Sample_v12.html').write_text(page)
months={rn:datetime.strptime(am[rn]['pen_month'],'%Y-%m').strftime('%B %Y') for rn in ['818','926','3196']}
newpara=f'<p>For Indian River, both the reviewed article and PEN indicate {months["818"]}. The earlier report incorrectly described PEN’s month as February; there is no month-level conflict in these two fields. Exact onset and classroom scope remain unverified. The Florida annual report corroborates the title and district without a month. For <i>The Hill We Climb</i>, PEN records {months["926"]}, while the article refers to an April committee meeting. Their relationship remains unresolved.</p>'
oldpara=r'<p>For Indian River, the article reports a March removal, while PEN records February\..*?Those dates also remain separate.</p>'
page,count=re.subn(oldpara,newpara,page,flags=re.S);assert count==1
page=page.replace('with an April 2023 month',f'with a {months["3196"]} month')
notice='<section id="date-audit"><h2>October 4 correction: workbook dates and report wording</h2><p>Three month descriptions in earlier report versions were wrong. The extracted CSV dates were correct. A direct check of all 3,362 workbook rows now verifies each title, district, status and date against its source cell. The workbook defines numeric dates as approximate months; the first day in an Excel serial is not an exact restriction date.</p><div class="scroll"><table><thead><tr><th>Case</th><th>Verified PEN month</th><th>Comparison</th><th>Current interpretation</th></tr></thead><tbody>'
for r in focus:notice+='<tr>'+''.join('<td>'+e(r[k])+'</td>' for k in ['district','verified_pen_month','comparison_date_or_month','note'])+'</tr>'
notice+='</tbody></table></div><p>The sample classifications remain 13 supported school-topic records, four other records and 19 unresolved. No model-ready records or new restriction onsets are added. Independent review has been prepared but has not been completed.</p></section>'
page=page.replace('<h2>What changed in this follow-up</h2>',notice+'<h2>October 3 follow-up</h2>',1).replace('3 OCTOBER 2026 · FOLLOW-UP','4 OCTOBER 2026 · DATE AUDIT').replace('Review version 12, October 3, 2026.','Review version 13, October 4, 2026.')
page=page.replace('<code>sample_title_probes_v11.csv</code>','<code>sample_title_probes_v13.csv</code>').replace('<code>sample_review_v12.csv</code>','<code>sample_review_v13.csv</code>')
page=page.replace('recreate the fixed sample and apply the frozen follow-up. It does not independently reproduce the judgment of reading an article.','recreate the fixed sample and apply the frozen follow-up. The final script, <code>review/build_date_review.py</code>, checks workbook cells and corrects the current prose. These scripts do not independently reproduce the judgment of reading an article.')
page=page.replace('<h2>Reproduce and review</h2>','<h2>Independent review</h2><p>Use <code>Independent_Review.html</code> for a first pass without the earlier classifications, and export the completed JSON. No reviewer responses have been received. Comparison code checks completeness and lists disagreements; it does not establish who is correct or overwrite the research records.</p><h2>Reproduce and review</h2>')
assert 'while PEN records February' not in page and 'with an April 2023 month' not in page
(O/'GDELT_Validation_Sample.html').write_text(page)
report=O/'GDELT_District_Link_Review.html';t=report.read_text();t=re.sub(r'<!-- DATE AUDIT START -->.*?<!-- DATE AUDIT END -->','',t,flags=re.S)
t=t.replace('Latest update: original article recovered and Davis vote checked','Earlier pass: original article recovered and Davis vote checked')
t=t.replace('<!-- SAMPLE FOLLOWUP START -->','<!-- DATE AUDIT START -->'+notice+'<p><b>Historical sections below retain their original wording, including the three superseded month descriptions. Use the correction table above and version 13 tables for current interpretation.</b></p><!-- DATE AUDIT END --><!-- SAMPLE FOLLOWUP START -->',1);report.write_text(t)
# A portable form: no network submission and no saved values without an explicit export.
style='body{font:17px/1.55 Arial,sans-serif;max-width:980px;margin:30px auto;padding:25px;color:#193344;background:#f3f6f8}h1{font-size:32px}fieldset{background:white;border:1px solid #c7d4da;padding:22px;margin:20px 0}label{display:block;margin:12px 0 4px;font-weight:bold}input,select,textarea{box-sizing:border-box;width:100%;font:16px Arial;padding:9px;border:1px solid #7b939c;border-radius:3px}textarea{height:100px}button{background:#126f79;color:white;border:0;padding:12px 20px;font:17px Arial;cursor:pointer}a{color:#126f79;overflow-wrap:anywhere}.note{background:#fff1df;padding:16px}.row{display:grid;grid-template-columns:1fr 1fr;gap:20px}@media(max-width:650px){.row{grid-template-columns:1fr}}'
intro='''<h1>Independent review of 36 news records</h1><p>Record the article’s evidence before consulting previous classifications. The sample is fixed: retain inaccessible records and select “unresolved.” A relevant school-book story may concern a proposal, retention, restriction or reversal; topic relevance alone does not establish a ban.</p><p class="note">This form sends nothing to a server. Export progress before closing the page; entries are not saved automatically. Import the exported JSON to continue. Keep the completed review local until it has been checked.</p><ol><li>Open the selected article and record the actual URL read. Related coverage may be noted separately but cannot establish identical article contents.</li><li>Identify school versus public-library context. Classify only after reading usable content.</li><li>Confirm a district with state and official NCES directory evidence. A publisher’s city and a same-name district are insufficient.</li><li>Keep publication, challenge, restriction, vote and implementation dates separate. Leave event dates empty when unsupported.</li><li>Explain the evidence and limits. Compare against the earlier review only after the independent pass.</li></ol><label>Reviewer name or review ID<input id="reviewer"></label><label>Review date<input id="review_date" type="date"></label><label>Prior classifications avoided during the first pass?<select id="independent"><option value="false">Not confirmed</option><option value="true">Yes</option></select></label><p><button id="export">Export review JSON</button> <label>Resume from an exported JSON<input id="import" type="file" accept=".json"></label></p><p id="status" aria-live="polite"></p><div id="records"></div>'''
script=r'''
const template=__DATA__;const box=document.getElementById('records');
const choices={access_status:['','readable','partial','unavailable'],topic_verdict:['','supported_school_topic','outside_school_scope','noncontent_match','unresolved'],district_status:['','confirmed','no_single_district','unresolved'],date_precision:['','day','month','unknown']};
const labels={reviewed_url:'URL actually reviewed',access_status:'Article access',topic_verdict:'Topic classification',district_status:'District identification',district_name:'District name',district_state:'State abbreviation',nces_id:'NCES district ID (seven digits)',publisher_date:'Publication date, if supported (YYYY-MM-DD or YYYY-MM)',date_precision:'Event-date precision',event_date:'Event date, if supported (YYYY-MM-DD or YYYY-MM)',event_stage:'Event stage (proposal, review, restriction, retention, reversal, other or unknown)',evidence_note:'Evidence, NCES source and limitations'};
for(const r of template.records){const f=document.createElement('fieldset');f.dataset.id=r.record_id;const legend=document.createElement('legend');legend.textContent=r.sample_number+'. '+r.title;f.append(legend);const a=document.createElement('a');a.href=r.original_url;a.textContent='Open selected source';a.target='_blank';a.rel='noopener noreferrer';f.append(a);const id=document.createElement('p');id.textContent=r.record_id;f.append(id);
for(const [key,label] of Object.entries(labels)){const l=document.createElement('label');l.textContent=label;const el=document.createElement(choices[key]?'select':key==='evidence_note'?'textarea':'input');el.name=key;if(choices[key])for(const value of choices[key]){const o=document.createElement('option');o.value=value;o.textContent=value||'Select';el.append(o);}l.append(el);f.append(l);}box.append(f);}
function current(){return {...template,reviewer:document.getElementById('reviewer').value.trim(),review_date:document.getElementById('review_date').value,independent_first_pass:document.getElementById('independent').value==='true',records:template.records.map(r=>{const f=[...box.children].find(f=>f.dataset.id===r.record_id);const out={...r};for(const key of Object.keys(labels))out[key]=f.querySelector('[name="'+key+'"]').value.trim();return out;})};}
document.getElementById('export').onclick=()=>{const result=current();const u=URL.createObjectURL(new Blob([JSON.stringify(result,null,2)+'\n'],{type:'application/json'}));const a=document.createElement('a');a.href=u;a.download='Independent_Review_Responses.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);document.getElementById('status').textContent='Exported progress. Exporting does not mean the review is complete.';};
document.getElementById('import').onchange=async ev=>{try{const data=JSON.parse(await ev.target.files[0].text());if(data.protocol!==template.protocol||!Array.isArray(data.records)||data.records.length!==36)throw Error('Wrong review protocol or record count');const ids=data.records.map(r=>r.record_id);if(new Set(ids).size!==36||ids.some(id=>!template.records.some(r=>r.record_id===id)))throw Error('Record IDs differ');document.getElementById('reviewer').value=data.reviewer||'';document.getElementById('review_date').value=data.review_date||'';document.getElementById('independent').value=String(data.independent_first_pass===true);for(const r of data.records){const f=[...box.children].find(f=>f.dataset.id===r.record_id);for(const key of Object.keys(labels))f.querySelector('[name="'+key+'"]').value=r[key]||'';}document.getElementById('status').textContent='Progress loaded.';}catch(err){document.getElementById('status').textContent='Cannot import: '+err.message;}};
'''.replace('__DATA__',json.dumps(blank).replace('</',r'<\/'))
(O/'Independent_Review.html').write_text('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Independent news review</title><style>'+style+'</style></head><body>'+intro+'<script>'+script+'</script></body></html>')
print(json.dumps(summary,indent=2))
