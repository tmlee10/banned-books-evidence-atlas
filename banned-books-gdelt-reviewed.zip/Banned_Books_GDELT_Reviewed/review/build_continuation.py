#!/usr/bin/env python3
"""Offline rebuild of access coverage, human decisions and selected episode audit."""
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime,timedelta
import csv,json,hashlib,re,html
H=Path(__file__).resolve().parent;I=H/'inputs';O=H/'outputs';B=H.parent/'baseline_audit'
if not B.exists():B=H.parent/'gdelt_full_year/package'
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
def j(n):return json.loads((I/n).read_text())
def write(n,rows):
 with (O/n).open('w',newline='',encoding='utf-8')as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
checks={}
def check(n,v):
 checks[n]=bool(v)
 if not v:raise AssertionError(n)
q=read(O/'expanded_alias_candidates.csv');raw={r['record_id']:r for r in read(B/'outputs/review_queue.csv')};original=read(O/'candidate_review.csv');orig={r['record_id']:r for r in original};new={r['record_id']for r in q}-orig.keys()
previous=j('expanded_article_decisions.json');current=j('continuation_article_decisions.json');pmap={r['record_id']:r for r in previous};cmap={r['record_id']:r for r in current}
access=[json.loads(s)for s in(I/'public_access_attempts.jsonl').read_text().splitlines()];amap={r['record_id']:r for r in access}
check('unique_access_record_ids',len(access)==len(amap))
check('access_covers_all_previously_unattempted_925',amap.keys()==new-pmap.keys()and len(access)==925)
check('human_passes_disjoint',not(pmap.keys()&cmap.keys())and cmap.keys()<=new)
check('immutable_raw_row_count',len(raw)==15767)
for id,a in amap.items():check('access_url_'+id,a['url']==raw[id]['url'])
for s in j('continuation_source_register.json'):
 if s['local_file']:check('primary_document_hash_'+s['source_id'],hashlib.sha256((I/s['local_file']).read_bytes()).hexdigest()==s['sha256'])
# A body review is a different field from a machine HTTP result.
records=[];confirmed=[]
for id in sorted({r['record_id']for r in q}):
 r=raw[id];status='not_substantively_reviewed';nces='';pub='';db='';note='';cohort='expanded_unreviewed'
 if id in orig:
  x=orig[id];status='supported_district_topic'if x['review_decision']=='district_topic_confirmed'else'unresolved_article_evidence';nces=x['verified_historical_nces_id']if status=='supported_district_topic'else'';pub=x['article_date'];db=x['article_date_type'];note=x['review_notes'];cohort='original_literal_screen'
 elif id in pmap:
  x=pmap[id];nces=x['confirmed_nces_id'];status='supported_district_topic'if nces else'unresolved_article_evidence';pub=x['publication_date'];db='publisher_date_recorded_in_review';note=x['evidence_summary'];cohort='expanded_first_batch'
 elif id in cmap:
  x=cmap[id];status=x['verdict'];nces=x['confirmed_nces_id'];pub=x['publication_date'];db=x['publication_date_basis'];note=x['evidence_summary'];cohort='continuation_batch'
 a=amap.get(id,{})
 out={'record_id':id,'gdelt_recorded_at':r['recorded_at'],'title':r['title_decoded'],'url':r['url'],'review_cohort':cohort,'human_review_status':status,'confirmed_nces_id':nces,'publisher_date':pub,'publisher_date_basis':db,'machine_access_status':a.get('access_status','not_in_925_URL_access_batch'),'machine_checked_utc':a.get('checked_utc',''),'review_note':note,'model_eligible':'no'}
 records.append(out)
 if status=='supported_district_topic':confirmed.append(out)
write('combined_record_review.csv',records);write('combined_supported_article_links.csv',confirmed)
write('public_access_audit.csv',sorted(access,key=lambda r:r['record_id']))
# Record/entity adjudication overlays the original mechanical matches.
adj=read(O/'expanded_candidate_adjudication.csv');added=[]
for r in adj:
 if r['record_id']not in cmap:continue
 d=cmap[r['record_id']];r['review_date']=d['review_date'];r['review_basis']=d['evidence_summary']
 if d['verdict']=='rejected_not_book_content':r['review_status']='rejected_not_book_content'
 elif r['candidate_nces_id']==d['confirmed_nces_id']or(r['state']=='Arkansas'and r['candidate_district']=='Conway Public Schools')or(r['state']=='Texas'and r['candidate_district']=='Keller Independent School District'):
  r['review_status']='supported_district_topic';r['resolved_nces_id']=d['confirmed_nces_id']
 else:r['review_status']='rejected_geographic_or_name_match';r['resolved_nces_id']=''
for d in current:
 if d['confirmed_nces_id']and not any(r['record_id']==d['record_id']and r['resolved_nces_id']==d['confirmed_nces_id']for r in adj):added.append({'record_id':d['record_id'],'resolved_nces_id':d['confirmed_nces_id'],'reason':'Correct entity missed by mechanical aliases; article geography reviewed manually','evidence_url':d['url']})
write('continued_candidate_adjudication.csv',adj);write('manually_recovered_district_links.csv',added)
# Exact, case-folded full headline groups: prioritization only, not proof of syndication.
groups=defaultdict(list)
for r in records:groups[r['title'].lower().strip()].append(r)
familyrows=[];fmembers=[]
for title,members in sorted(groups.items()):
 gid='H'+hashlib.sha256(title.encode()).hexdigest()[:12]
 familyrows.append({'headline_group':gid,'normalized_headline':title,'record_count':len(members),'body_supported_records':sum(r['human_review_status']=='supported_district_topic'for r in members),'grouping_basis':'exact_casefolded_headline','independent_story_status':'unverified'})
 for r in members:fmembers.append({'headline_group':gid,'record_id':r['record_id'],'url':r['url'],'human_review_status':r['human_review_status']})
write('headline_review_groups.csv',familyrows);write('headline_group_members.csv',fmembers)
# Keep historical enrollment validation and study eligibility separate.
off={r['LEAID']:r for r in read(I/'nces_district_office_locations_2223.csv')};en={r['LEAID']:r for r in read(I/'nces_lea_enrollment_totals_2223.csv')if r['TOTAL_INDICATOR']=='Derived - Education Unit Total minus Adult Education Count'}
totals={r['LEAID']:r for r in read(I/'nces_lea_enrollment_totals_2223.csv')if r['TOTAL_INDICATOR']=='Education Unit Total'}
enrollment=read(O/'historical_enrollment_join.csv');existing={r['nces_id']for r in enrollment}
for id in sorted({d['confirmed_nces_id']for d in current if d['confirmed_nces_id']}-existing):
 a=off[id];e=en[id];check('new_enrollment_'+id,e['ST']==a['STATE']and e['STUDENT_COUNT'].isdigit()and int(e['STUDENT_COUNT'])>0 and e['DMS_FLAG']=='Derived')
 total=totals.get(id,{}).get('STUDENT_COUNT','');difference=int(total)-int(e['STUDENT_COUNT'])if total.isdigit()else''
 check('new_enrollment_total_'+id,total.isdigit()and difference>=0)
 enrollment.append({'nces_id':id,'historical_name':a['NAME'],'state':a['STATE'],'enrollment_name':e['LEA_NAME'],'school_year':e['SCHOOL_YEAR'],'enrollment_excluding_adult':e['STUDENT_COUNT'],'denominator_flag':e['DMS_FLAG'],'total_including_adult':total,'adult_count_difference':difference,'source_csv_record':e['source_csv_record'],'validation_cohort':'continuation_article_geography','study_eligibility':'not_yet_reviewed','model_eligible':'no'})
write('continued_enrollment_join.csv',enrollment)
# Selected episode rows do not append ban events to PEN or overwrite its dates.
pen=read(B/'inputs/pen_events.csv');penby={r['source_row']:r for r in pen};episodes=j('continuation_episode_decisions.json');episodeout=[]
for r in episodes:
 x=dict(r);pr=penby.get(r['pen_source_row']);pm=''
 if pr:
  for pkey,ekey in [('title','expected_pen_title'),('author','expected_pen_author'),('state','expected_pen_state'),('district','expected_pen_district'),('date_excel_serial_or_text','expected_pen_date'),('status','expected_pen_status')]:check(r['episode_link_id']+'_'+pkey,pr[pkey]==r[ekey])
  try:pm=(datetime(1899,12,30)+timedelta(days=float(pr['date_excel_serial_or_text']))).strftime('%Y-%m')
  except ValueError:pass
 art=next(t for t in records if t['record_id']==r['article_record_id']);pub=art['publisher_date'];ev=r['event_date'];delta=''
 if len(pub)==10 and len(ev)==10:delta=(datetime.fromisoformat(pub)-datetime.fromisoformat(ev)).days
 x.update({'pen_month_if_numeric_month_only':pm,'news_publisher_date':pub,'publication_minus_stated_stage_days':delta,'timing_field_limit':'Reported or inferred stage date; not first inaccessibility, causal effect or independent event','pen_and_stage_month_agree':('yes'if pm==ev[:7]else'no')if pm and ev else'not_comparable'})
 episodeout.append(x)
write('selected_episode_timing_audit.csv',episodeout)
check('all_episode_dates_preserve_no_first_onset',all(not r['first_inaccessibility_date']and r['model_eligible']=='no'for r in episodes))
check('raw_PEN_count_unchanged',len(pen)==3362)
check('all_candidate_records_accounted',len(records)==1054 and len({r['record_id']for r in records})==1054)
counts=Counter(r['human_review_status']for r in records);ac=Counter(r['access_status']for r in access)
summary={'candidate_records':len(records),'candidate_pairs_before_manual_recovery':len(q),'human_review_status_counts':dict(counts),'supported_articles':len(confirmed),'districts_with_supported_articles':len({r['confirmed_nces_id']for r in confirmed}),'continuation_batch_records':len(current),'machine_access_attempts':len(access),'machine_access_status_counts':dict(ac),'headline_groups':len(groups),'groups_with_multiple_records':sum(len(x)>1 for x in groups.values()),'largest_headline_group_records':max(map(len,groups.values())),'enrollment_joined_districts':len(enrollment),'selected_episode_rows':len(episodes),'selected_PEN_rows':len({r['pen_source_row']for r in episodes if r['pen_source_row']}),'manually_recovered_missing_entity_links':len(added),'human_review_complete':False,'national_timing_model_ready':False,'website_updated':False,'additional_BigQuery_jobs':0,'validation_checks':checks}
(O/'continuation_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
# Self-contained report with latest results at the top and earlier cohorts labeled.
report=O/'GDELT_District_Link_Review.html';doc=report.read_text();doc=re.sub(r'<!-- CONTINUATION START -->.*?<!-- CONTINUATION END -->','',doc,flags=re.S)
esc=html.escape
section=f'''<!-- CONTINUATION START --><section><h2>Complete URL access audit and selected episode review</h2><div class="callout"><b>Latest update:</b> all 925 previously unattempted URLs received an access check. Across all review passes, {len(confirmed)} article records support district-specific book-restriction coverage in {summary['districts_with_supported_articles']} districts. The records include challenges, policy changes, retention decisions and follow-up reporting; they are not a count of bans.</div>
<p>The annual source remains 15,767 GDELT records. The alias screen retains 1,054 candidate records. The latest manual batch reviewed 13 articles: 12 supported district-topic links and one concerned backpacks rather than book content. One correct district, Madison County in Mississippi, was missing from the mechanical matches because the NCES name uses abbreviated words. The manual correction is recorded separately; source data and all incorrect candidate pairs remain traceable.</p>
<h3>Access and substantive review are different checks</h3><table><tr><th>Public-access outcome</th><th>Records</th></tr>'''
for k,v in sorted(ac.items(),key=lambda t:-t[1]):section+=f'<tr><td>{esc(k.replace("_"," "))}</td><td>{v:,}</td></tr>'
section+='''</table><p>HTML retrieval means that a page was returned with enough text for possible review. It can still contain a subscription notice, unrelated content or navigation. The collector did not log in, solve access challenges or treat blocked pages as irrelevant. Robots failures and unavailable rules are conservatively grouped with disallowed requests. Full article text is not distributed in the package; URLs, response hashes and access decisions are included.</p><table><tr><th>Substantive record status, all passes</th><th>Records</th></tr>'''
for k,v in sorted(counts.items()):section+=f'<tr><td>{esc(k.replace("_"," "))}</td><td>{v:,}</td></tr>'
section+=f'''</table><p>The {summary['headline_groups']} exact-headline groups are a review aid. They do not establish independent reporting units. The largest group contains {summary['largest_headline_group_records']} records. Similar titles may hide changes in a story, and the same story may carry different titles.</p>
<h3>What the episode checks establish</h3><table><tr><th>Case</th><th>Evidence and remaining limit</th></tr>
<tr><td>Conway, Arkansas</td><td>Original October 11, 2022 minutes, page 3, record a unanimous vote rejecting retention of Beyond Magenta and Felix Ever After. October 10 reporting precedes that vote. The minutes establish the decision date, not when each copy became unavailable or whether classroom access changed.</td></tr>
<tr><td>Nixa, Missouri</td><td>A June 19 preview and June 20 outcome article describe seven titles: four removals, two parental-permission outcomes and one retention. PEN records Blankets in April. The later vote cannot replace that earlier date; other scope and author-spelling differences remain flagged.</td></tr>
<tr><td>Newtown, Connecticut</td><td>June 2 reporting describes a June 1 vote to retain Flamer and Blankets. This is a documented retention case, not proof of zero bans elsewhere in the district. The primary packet returned an error.</td></tr>
<tr><td>Miami-Dade, Florida</td><td>PEN lists The Hill We Climb in March; the reviewed news account describes an April panel decision. The meaning and timing of the access change require the original complaint and review records.</td></tr>
<tr><td>Keller and Spring Branch, Texas</td><td>Keller's August directive cannot be equated with PEN's Fall 2022 label or physical implementation. Spring Branch's January decision and March procedural change are different stages, with access varying by grade.</td></tr>
</table><p>The 20-row selected episode table links 16 distinct PEN rows and preserves four unmatched title cases. It is a purposive case audit. Dates of publication, challenge, recommendation, board action and first inaccessibility remain distinct. Every first-inaccessibility field is still blank and every model-eligibility flag remains no.</p>
<p><b>RQ3 retained:</b> What happened when a district reviewed a challenged book with input from librarians and local residents? Conway and Newtown illustrate different outcomes after review; they do not identify a causal effect of participation.</p>
<h3>Reproduction and next work</h3><p>The enrollment file now covers {len(enrollment)} reviewed district identities. The full agency inventory still needs eligibility checks. Run <code>python run_all.py</code> to rebuild the package outputs offline. The optional <code>check_public_access.py</code> collector is not run by that command. Original PDF minutes, source hashes, decision ledgers and all code are included; no credentials are required.</p>
<p>Next: complete substantive review and independent coding, reconcile primary title-level restriction records, and finalize district eligibility and coverage before estimating a national timing model. No additional BigQuery job, paid service, deployment or website update was performed.</p><h3>Sources for the new case review</h3><ul>'''
for r in current:section+=f'<li><a href="{esc(r["url"],quote=True)}">{esc(raw[r["record_id"]]["title_decoded"])}</a> — {esc(r["publication_date"])}; reviewed 2 October 2026.</li>'
for r in j('continuation_source_register.json'):section+=f'<li><a href="{esc(r["url"],quote=True)}">{esc(r["source_id"])}</a> — {esc(r["source_type"].replace("_"," "))}.</li>'
section+='</ul></section><!-- CONTINUATION END -->'
doc=doc.replace('<h1>Historical district verification and title linkage</h1>','<h1>Historical district verification and title linkage</h1>'+section)
doc=doc.replace('Expanded screening and enrollment — latest pass','Earlier pass: expanded screening and enrollment')
report.write_text(doc)
print(json.dumps({k:v for k,v in summary.items()if k!='validation_checks'},indent=2));print('Validation checks:',len(checks),'passed')
