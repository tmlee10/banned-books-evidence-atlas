#!/usr/bin/env python3
"""Reproduce a month-stratified validation sample and aggregate frozen judgments.
No network, paid queries, model inference or automatic article adjudication.
"""
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime,timedelta
import csv,json,hashlib,html,re
H=Path(__file__).resolve().parent;I=H/'inputs';O=H/'outputs'
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
def j(n):return json.loads((I/n).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,rows):
 with (O/n).open('w',encoding='utf-8',newline='')as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def e(x):return html.escape(str(x))
P=j('sample_protocol_v11.json');base=read(O/'current_record_review_v10.csv');assert len(base)==P['frame_count']==1054
assert sha(O/'current_record_review_v10.csv')==P['frame_sha256']
groups=defaultdict(list)
for r in base:groups[r['gdelt_recorded_at'][:6]].append(r)
selected=[]
for m,rs in sorted(groups.items()):
 for r in sorted(rs,key=lambda r:hashlib.sha256((P['seed']+'|'+r['record_id']).encode()).hexdigest())[:3]:
  selected.append(dict(r,sample_month=m,stratum_N=len(rs),sample_n=3,selection_hash=hashlib.sha256((P['seed']+'|'+r['record_id']).encode()).hexdigest()))
assert len(selected)==36 and len({r['record_id']for r in selected})==36
D={r['record_id']:r for r in j('sample_decisions_v11.json')};assert set(D)=={r['record_id']for r in selected}
A={r['record_id']:r for r in j('sample_access_v11.json')};assert set(A)==set(D)
off={r['LEAID']:r for r in read(I/'nces_district_office_locations_2223.csv')};schools=read(I/'nces_public_school_locations_2223.csv')
pairs=read(O/'expanded_alias_candidates.csv');byrecord=defaultdict(list)
for r in pairs:byrecord[r['record_id']].append(r)
penpath=H.parent/'baseline_audit/inputs/pen_events.csv'
if not penpath.exists():penpath=H.parent/'gdelt_full_year/package/inputs/pen_events.csv'
pen=read(penpath);pmap={r['source_row']:r for r in pen}
assert len(pen)==3362
primary=j('sample_primary_check_v11.json');assert sha(I/primary['included_path'])==primary['sha256']
# Explicit aliases already inspected in the source district names; never fuzzy matches.
pen_aliases={'Belton Independent School District':'4809860','Madison County Public Schools':'5102370','Spotsylvania County Public Schools':'5103660'}
review=[];pairout=[];identity=[];sources=[]
for r in selected:
 d=D[r['record_id']];n=d['reviewed_nces_id'];states=set()
 if n:
  assert off[n]['NAME']==d['reviewed_district'] and off[n]['STATE']==d['reviewed_state']
  ss=[s for s in schools if s['LEAID']==n];assert ss and all(s['STATE']==d['reviewed_state']for s in ss)
  identity.append(dict(record_id=r['record_id'],nces_id=n,district=off[n]['NAME'],state=off[n]['STATE'],directory_year=off[n]['SCHOOLYEAR'],school_rows_same_id=len(ss),basis='reviewed article geography + official 2022–2023 NCES office and school files',independent_human_review='pending'))
 ps=[]
 for x in byrecord[r['record_id']]:
  cid=x['candidate_nces_id'] or pen_aliases.get(x['pen_district'],'')
  if d['verdict']=='unresolved':v='unresolved'
  elif n and cid==n:v='supported_candidate'
  else:v='rejected_candidate'
  ps.append(v);pairout.append(dict(record_id=r['record_id'],entity_key=x['entity_key'],candidate_district=x['candidate_district'],candidate_state=x['state'],candidate_nces_id=x['candidate_nces_id'],resolved_alias_nces_id=cid,reviewed_nces_id=n,verdict=v,evidence_note=d['evidence_summary']))
 c='at_least_one_supported_candidate'if 'supported_candidate'in ps else'unresolved'if 'unresolved'in ps else'no_supported_candidate'
 review.append(dict(sample_number=len(review)+1,record_id=r['record_id'],gdelt_timestamp=r['gdelt_recorded_at'],sample_month=r['sample_month'],stratum_N=r['stratum_N'],sample_n=3,inclusion_fraction=f"3/{r['stratum_N']}",design_weight=r['stratum_N']/3,selection_hash=r['selection_hash'],title=r['title'],original_url=r['url'],**{k:v for k,v in d.items()if k not in('record_id','sample_number')},candidate_result=c,access_status=A[r['record_id']].get('access_status',''),prior_content_verdict=r['content_review_status']))
 sources.append(dict(record_id=r['record_id'],original_url=r['url'],reviewed_url=d['source_url'],evidence_basis=d['evidence_basis'],checked_utc=A[r['record_id']].get('checked_utc',''),response_sha256=A[r['record_id']].get('sha256',''),text_cache_sha256=d['cache_sha256'],distribution='paraphrase and provenance only; full publisher articles not redistributed',web_fallback='original URL redirected to wesanews.org; web extraction reviewed 2026-10-02'if d['sample_number']==23 else'not_used_for_decision'))
counts=Counter(r['verdict']for r in review);candidate_counts=Counter(r['candidate_result']for r in review)
assert counts=={'supported_school_topic':12,'outside_school_scope':2,'noncontent_match':2,'unresolved':20}
assert candidate_counts=={'at_least_one_supported_candidate':8,'no_supported_candidate':8,'unresolved':20}
month=[]
for m,rs in sorted(groups.items()):
 sub=[r for r in review if r['sample_month']==m];c=Counter(r['verdict']for r in sub)
 month.append(dict(month=m,frame_records=len(rs),sample_records=len(sub),school_topic=c['supported_school_topic'],outside_school_or_noncontent=c['outside_school_scope']+c['noncontent_match'],unresolved=c['unresolved']))
probes=[]
for q in j('sample_title_probes_v11.json'):
 d=D[q['record_id']];r=pmap.get(q['expected_pen_row']);m=''
 if r:
  assert r['district']==q['district_alias'];assert d['reviewed_nces_id']
  try:m=(datetime(1899,12,30)+timedelta(days=float(r['date_excel_serial_or_text']))).strftime('%Y-%m')
  except ValueError:m=r['date_excel_serial_or_text']
 probes.append(dict(**q,reviewed_nces_id=d['reviewed_nces_id'],pen_title=r['title']if r else'',pen_author=r['author']if r else'',pen_district=r['district']if r else'',pen_month_or_text=m,pen_status=r['status']if r else'',pen_source_sheet=r['sheet']if r else'',pen_source_row=r['source_row']if r else'',publisher_date=d['publisher_date'],primary_event_date='',independent_human_review='pending'))
assert len(probes)==32 and sum(bool(r['pen_source_row'])for r in probes)==12
current=[];rmap={r['record_id']:r for r in review}
for r in base:
 d=rmap.get(r['record_id']);a=dict(r)
 a.update(sample_review_v11=d['verdict']if d else'not_selected',sample_nces_id_v11=d['reviewed_nces_id']if d else'',sample_candidate_result_v11=d['candidate_result']if d else'not_selected',sample_review_note_v11=d['evidence_summary']if d else'',accepted_event_link_v11='no')
 assert a['model_eligible']=='no';current.append(a)
summary=dict(review_version=11,frame_records=1054,sample_records=36,months=12,records_per_month=3,article_verdicts=dict(counts),candidate_results=dict(candidate_counts),candidate_pairs=len(pairout),candidate_pair_verdicts=dict(Counter(x['verdict']for x in pairout)),reviewed_districts=len(identity),reviewed_states=len({r['state']for r in identity}),title_probes=32,title_district_correspondences=12,new_accepted_dated_event_links=0,model_eligible_records=0,additional_BigQuery_jobs=0,independent_human_review='pending',website_published=False,website_block='Render uses tmlee10/banned-books-evidence-atlas; connected GitHub returned 404 for that repository on 2026-10-02. No alternate repository or service modified.')
for n,rs in [('sample_review_v11.csv',review),('sample_candidate_pairs_v11.csv',pairout),('sample_month_summary_v11.csv',month),('sample_title_probes_v11.csv',probes),('sample_source_register_v11.csv',sources),('sample_identity_checks_v11.csv',identity),('current_record_review_v11.csv',current)]:write(n,rs)
(O/'sample_summary_v11.json').write_text(json.dumps(summary,indent=2)+'\n')
# One concise, self-contained web page; no hidden dependencies.
css='''body{font:17px/1.6 Arial,sans-serif;background:#eff4f6;color:#193344;margin:0}main{max-width:1040px;margin:30px auto;background:white;padding:40px;border-top:8px solid #167b85}h1{font-size:38px;line-height:1.2}h2{font-size:26px;margin-top:38px}h3{font-size:21px}.eyebrow{color:#536c7b;font-size:14px;letter-spacing:1px}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}.cards div{background:#edf4f4;padding:20px}.cards b{display:block;font-size:40px}.note{border-left:4px solid #b76630;padding:14px 20px;background:#fff5ec}table{border-collapse:collapse;width:100%;font-size:14px;margin:20px 0}th,td{text-align:left;vertical-align:top;padding:11px;border-bottom:1px solid #cbd7dc}th{background:#edf3f6}a{color:#0c6876;overflow-wrap:anywhere}.scroll{overflow-x:auto}code{overflow-wrap:anywhere}small{color:#536c7b}@media(max-width:700px){main{padding:20px;margin:0}.cards{grid-template-columns:1fr}h1{font-size:30px}table{min-width:660px}}@media print{body{background:white}main{border:0;margin:0;padding:0}tr{break-inside:avoid}.cards{grid-template-columns:repeat(3,1fr)}}'''
body='''<p class="eyebrow">BANNED BOOKS · GDELT VALIDATION · 2 OCTOBER 2026</p><h1>Checking the news-to-district matches</h1><p>A fixed sample of 36 records was reviewed from the 1,054-record candidate set. Three records were selected from each month, July 2022 through June 2023.</p><div class="cards"><div><b>12</b>School-book coverage supported</div><div><b>4</b>Public-library or unrelated activity</div><div><b>20</b>Article evidence unresolved</div></div><p class="note">These are news-record classifications, not counts of bans. Eight records support at least one original district candidate; eight support none; twenty remain unresolved. Relevant coverage can still be assigned to the wrong district.</p>
<h2>How the sample was selected</h2><ol><li>Freeze the current 1,054-record review ledger and record its SHA-256 checksum.</li><li>Group records by the month of their GDELT timestamp. This timestamp is not assumed to be the publication or restriction date.</li><li>Order each group by SHA-256 of a fixed seed and record ID, then select the first three records. Retain previous reviews, duplicate-looking stories and unavailable pages. Do not substitute easier records.</li><li>Read accessible article bodies, check geography against the official 2022–2023 NCES files, and classify each proposed district link separately.</li><li>Compare selected named titles with the preserved PEN index. Record differences in date, stage and scope without resolving them by assumption.</li></ol>
<p>The fixed seed is <code>banned-books-month-validation-v11-20261002</code>. Monthly frame counts range from 29 to 247, so the equal-per-month sample is not proportional to news volume. The record-level CSV contains inclusion fractions and design weights, but this report gives sample counts only. No national accuracy estimate, recall estimate or confidence interval is presented. Independent human review remains pending.</p>
<h2>Errors that a district-name search can make</h2><div class="scroll"><table><thead><tr><th>Source</th><th>Candidate problem</th><th>Reviewed interpretation</th></tr></thead><tbody>
<tr><td>Knox County school-library story</td><td>Kentucky and Tennessee district candidates</td><td>RSU 40/MSAD 40, Maine; NCES 2311550. A pending appeal while the book remained available.</td></tr>
<tr><td>NBC San Diego / Anne Frank adaptation</td><td>San Diego ISD, Texas</td><td>Indian River County, Florida; NCES 1200930. Publisher branding does not locate the school.</td></tr>
<tr><td>Madison County restricted circulation</td><td>15 candidate aliases, none for the reported Mississippi district</td><td>Madison County, Mississippi; NCES 2802790. Same-name districts are not interchangeable.</td></tr>
<tr><td>Pleasant Hill and Kent library stories</td><td>Place-name and keyword matches</td><td>Late-fine removal and a play-space challenge, not school-book restrictions.</td></tr></tbody></table></div>
<h2>What the PEN comparison established</h2><p>Thirty-two selected title probes produced twelve title–district correspondences. They are not twelve newly verified restriction events. Dearborn and Central Bucks reporting concerns stages that differ from the PEN entries. Portage lacks a verified onset date. Madison County, Mississippi, and Calvert County are absent from this preserved index; that absence cannot be recorded as zero bans.</p><p>For Indian River, the article reports a March removal, while PEN records February. The Florida Department of Education’s annual report lists the same graphic adaptation and author under Indian River’s four removals, but supplies no month. The title and district have corroboration; the date conflict remains unresolved. The article about <i>The Hill We Climb</i> refers to an April committee meeting, while its PEN entry records February. Those dates also remain separate.</p><p><a href="https://www.fldoe.org/core/fileparse.php/5574/urlt/2223ObjectionList.pdf">Florida 2022–2023 objection report, page 9</a>. The full official PDF, its checksum, and the row-level PEN comparisons are included in the research package.</p>
<h2>Monthly review coverage</h2><div class="scroll"><table><thead><tr><th>GDELT month</th><th>Frame records</th><th>Selected</th><th>School topic</th><th>Outside scope / unrelated</th><th>Unresolved</th></tr></thead><tbody>'''
for r in month:body+='<tr>'+''.join('<td>'+e(r[k])+'</td>'for k in ['month','frame_records','sample_records','school_topic','outside_school_or_noncontent','unresolved'])+'</tr>'
body+='''</tbody></table></div><h2>All 36 decisions</h2><p>Each source link identifies the reviewed record. A failed or partial page remains unresolved even when its headline appears relevant. Encoded bodies were not decoded. Current-page text is not proof of its exact historical contents.</p><div class="scroll"><table><thead><tr><th>Record</th><th>Evidence classification</th><th>District / candidate result</th><th>Reason and limit</th></tr></thead><tbody>'''
labels={'supported_school_topic':'School topic supported','outside_school_scope':'Public-library scope','noncontent_match':'Unrelated activity','unresolved':'Unresolved'}
for r in review:
 district=(r['reviewed_district']+' ('+r['reviewed_state']+')')if r['reviewed_nces_id']else'Not assigned'
 body+=f'<tr><td>{r["sample_number"]}. <a href="{e(r["source_url"])}">{e(r["title"])}</a><br><small>{e(r["record_id"])}</small></td><td>{labels[r["verdict"]]}</td><td>{e(district)}<br><small>{e(r["candidate_result"].replace("_"," "))}</small></td><td>{e(r["evidence_summary"])}</td></tr>'
body+='''</tbody></table></div><h2>What this supports</h2><p>The existing GDELT export contains useful school-book reporting alongside ambiguous names, public-library stories and unrelated keyword matches. Each district association needs article evidence. News timestamps alone cannot date a restriction. This sample adds validation evidence; it does not establish whether publicity caused bans or which state will act next.</p><p><b>RQ3:</b> What happened when a district reviewed a challenged book with input from librarians and local residents?</p><p>Reporting in the sample describes different stages: proposals, ongoing reviews, conditional access, retained books and removals. These categories should remain distinct when answering RQ3. More complete primary access histories and independent review are needed before comparing restriction duration or outcomes.</p><h2>Reproduce and review</h2><p>Unzip the full package and run <code>python run_all.py</code>. The final script, <code>review/build_sample_review.py</code>, recreates the sample and aggregates frozen review judgments. It does not independently reproduce the judgment of reading an article. Use <code>sample_review_v11.csv</code>, <code>sample_candidate_pairs_v11.csv</code> and <code>sample_title_probes_v11.csv</code> to inspect the decisions.</p><p><b>Next evidence:</b> resolve original-page access for the 20 unresolved records, have a second reviewer check this fixed sample, and reconcile date/stage conflicts against district records. A separate sample from records outside the candidate set is needed to measure missed coverage.</p><p><small>No additional BigQuery query or paid service was used. The website has not been updated: its Render service uses the tmlee10 repository, which the connected GitHub account could not access. This self-contained page is ready to publish after access is restored.</small></p>'''
standalone='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GDELT validation sample | Banned Books Evidence Atlas</title><style>'+css+'</style></head><body><main>'+body+'</main></body></html>'
(O/'GDELT_Validation_Sample.html').write_text(standalone)
report=O/'GDELT_District_Link_Review.html';t=report.read_text();t=re.sub(r'<!-- SAMPLE REVIEW START -->.*?<!-- SAMPLE REVIEW END -->','',t,flags=re.S)
fragment='<!-- SAMPLE REVIEW START --><section><h2>Latest update: fixed 36-record validation sample</h2><div class="callout"><b>Version 11.</b> Twelve records support school-book coverage, four concern other library activity or unrelated keywords, and twenty remain unresolved. Eight support at least one original district candidate. No new dated PEN event link is accepted.</div>'+body[body.index('<h2>How the sample'):body.index('<h2>All 36 decisions')]+ '<p>The complete 36-row review, source links and decisions are in <code>GDELT_Validation_Sample.html</code>, included with this report in the ZIP.</p></section><!-- SAMPLE REVIEW END -->'
t=t.replace('Latest update: Newtown and Ludlow outcomes verified','Earlier pass: Newtown and Ludlow outcomes verified');t=t.replace('<!-- FOLLOWUP REVIEW START -->',fragment+'<!-- FOLLOWUP REVIEW START -->',1);report.write_text(t)
print(json.dumps(summary,indent=2))
