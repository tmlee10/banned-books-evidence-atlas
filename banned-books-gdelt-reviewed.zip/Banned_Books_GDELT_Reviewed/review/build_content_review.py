#!/usr/bin/env python3
"""Offline content decisions, repeated-story evidence and latest review report.

Reads frozen assistant judgments and comparison receipts. It does not call an
AI, retrieve articles, run a query, or automatically validate those judgments.
"""
from pathlib import Path
from collections import Counter,defaultdict
import csv,json,hashlib,html,re
H=Path(__file__).resolve().parent;I=H/'inputs';O=H/'outputs'
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
def j(n):return json.loads((I/n).read_text())
def write(n,rs):
 with (O/n).open('w',newline='',encoding='utf-8')as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
profiles={p['profile_id']:p for p in j('content_review_profiles.json')}
receipts=j('content_comparison_receipts.json');variants={r['record_id']:r for r in j('content_variant_decisions.json')}
inventory={r['record_id']:r for r in j('cached_page_inventory.json')}
access={r['record_id']:r for r in map(json.loads,(I/'public_access_attempts.jsonl').read_text().splitlines())}
base=read(O/'combined_record_review.csv');byid={r['record_id']:r for r in base}
off={r['LEAID']:r for r in read(I/'nces_district_office_locations_2223.csv')}
checks={}
def check(n,v):
 checks[n]=bool(v)
 if not v:raise AssertionError(n)
check('receipt_count_and_uniqueness',len(receipts)==173 and len({r['record_id']for r in receipts})==173)
check('all_29_representatives_in_receipts',all(p['representative_record_id']in{r['record_id']for r in receipts}for p in profiles.values()))
check('cached_inventory_542_records',len(inventory)==542)
for p in profiles.values():
 if p['confirmed_nces_id']:check('identity_'+p['profile_id'],p['confirmed_nces_id']in off and off[p['confirmed_nces_id']]['STATE']==p['confirmed_state'])
decisions=[];dmap={};fam=defaultdict(list)
for r in receipts:
 id=r['record_id'];p=profiles[r['profile_id']];v=variants.get(id);ref=byid[id]
 check('receipt_identity_'+id,r['url']==ref['url']and r['cache_sha256']==inventory[id]['cache_sha256']and r['http_response_sha256']==access[id]['sha256'])
 if r['review_basis']=='exact_body_equivalence':check('body_equality_'+id,r['normalized_body_sha256']==r['representative_body_sha256']and r['normalized_body_characters']>300)
 approved=r['apply_profile_decision']or(v and v['variant_decision']=='reviewed_story_variant')
 status=p['verdict']if approved else'unresolved_article_evidence'
 basis=r['review_basis']if r['apply_profile_decision']else v['variant_decision']if v else'headline_only_unresolved'
 note=p['evidence_summary']if approved else'Public lead only; unreadable body. Headline similarity does not justify propagation.'
 if v:note+=' '+v['review_note']
 d=dict(record_id=id,url=r['url'],profile_id=r['profile_id'],story_family_id=('CNN_GORMAN_20230524'if r['profile_id']in('C03','C12')else r['profile_id'])if approved else'',content_review_status=status,primary_subject_nces_id=p['confirmed_nces_id']if approved else'',primary_subject_name=off[p['confirmed_nces_id']]['NAME']if approved and p['confirmed_nces_id']else'',primary_subject_state=p['confirmed_state']if approved else'',review_basis=basis,genre=p['genre'],reported_stage=p['reported_stage'],representative_record_id=p['representative_record_id'],page_date=p['representative_page_date']if id==p['representative_record_id']else'',page_date_basis='current_page_displayed_date; may be an update'if id==p['representative_record_id']and p['representative_page_date']else'not_transcribed_for_this_copy',evidence_note=note,review_actor='AI_assistant; independent_human_review_pending',historical_body_availability='unverified',model_eligible='no')
 decisions.append(d);dmap[id]=d
 if approved:fam[d['story_family_id']].append(d)
write('content_batch_decisions.csv',decisions);write('content_comparison_receipts.csv',receipts);write('cached_page_quality.csv',list(inventory.values()))
latest=[]
for r in base:
 d=dmap.get(r['record_id']);a=dict(r);a['content_review_status']=a.pop('human_review_status');a['review_basis']='earlier_review_pass';a['story_family_id']='';a['genre']='not_coded_in_this_pass';a['reported_stage']='not_coded_in_this_pass';a['independent_human_review']='pending';a['historical_body_availability']='unverified'
 if d:
  a['content_review_status']=d['content_review_status'];a['confirmed_nces_id']=d['primary_subject_nces_id'];a['review_cohort']='content_and_repetition_pass';a['review_note']=d['evidence_note'];a['review_basis']=d['review_basis'];a['story_family_id']=d['story_family_id'];a['genre']=d['genre'];a['reported_stage']=d['reported_stage']
  if d['page_date']:a['publisher_date']=d['page_date'];a['publisher_date_basis']=d['page_date_basis']
 a['cached_page_available']='yes'if a['record_id']in inventory else'no';a['page_quality_flag']=inventory.get(a['record_id'],{}).get('quality_flag','no_cached_text')
 latest.append(a)
write('latest_record_review.csv',latest)
supported=[r for r in latest if r['content_review_status']=='supported_district_topic'];pending=[r for r in latest if r['content_review_status']in('not_substantively_reviewed','unresolved_article_evidence')]
write('latest_supported_article_links.csv',supported);write('remaining_content_review_queue.csv',pending)
familyrows=[]
for id,rs in sorted(fam.items()):
 familyrows.append(dict(story_family_id=id,records=len(rs),review_profiles=';'.join(sorted({r['profile_id']for r in rs})),primary_district_ids=';'.join(sorted({r['primary_subject_nces_id']for r in rs if r['primary_subject_nces_id']})),representatives=';'.join(sorted({r['representative_record_id']for r in rs})),grouping_basis='exact_bodies_or_reviewed_story_variants',independence_claim='none; further cross-family relationships possible',counting_rule='retain every record; one family is a sensitivity unit only'))
write('reviewed_story_families.csv',familyrows)
# Match only the principal subject. Other candidate entities remain secondary
# or unresolved, rather than being declared false when the article mentions them.
adj=read(O/'continued_candidate_adjudication.csv');recovered=[]
for r in adj:
 d=dmap.get(r['record_id'])
 if not d:continue
 id=d['primary_subject_nces_id'];r['review_basis']=d['evidence_note'];r['review_date']='2026-10-02'
 if id and (r['candidate_nces_id']==id or r['resolved_nces_id']==id):r['review_status']='supported_primary_subject';r['resolved_nces_id']=id
 elif id:r['review_status']='not_primary_subject; secondary_reference_unreviewed';r['resolved_nces_id']=''
 else:r['review_status']=d['content_review_status'];r['resolved_nces_id']=''
for d in decisions:
 id=d['primary_subject_nces_id']
 if id and not any(r['record_id']==d['record_id']and r['resolved_nces_id']==id for r in adj):recovered.append({'record_id':d['record_id'],'nces_id':id,'district':off[id]['NAME'],'state':off[id]['STATE'],'reason':'Primary subject established by reviewed body; absent from mechanically generated ID matches','evidence_url':d['url']})
write('latest_candidate_adjudication.csv',adj)
if recovered:write('content_recovered_primary_subjects.csv',recovered)
enrollment=read(O/'continued_enrollment_join.csv');existing={r['nces_id']for r in enrollment};rawen=read(I/'nces_lea_enrollment_totals_2223.csv')
en={r['LEAID']:r for r in rawen if r['TOTAL_INDICATOR']=='Derived - Education Unit Total minus Adult Education Count'};total={r['LEAID']:r for r in rawen if r['TOTAL_INDICATOR']=='Education Unit Total'}
for id in sorted({d['primary_subject_nces_id']for d in decisions if d['primary_subject_nces_id']}-existing):
 a=off[id];e=en[id];t=total[id]['STUDENT_COUNT'];check('enrollment_'+id,e['ST']==a['STATE']and e['DMS_FLAG']=='Derived'and e['STUDENT_COUNT'].isdigit()and int(e['STUDENT_COUNT'])>0 and t.isdigit()and int(t)>=int(e['STUDENT_COUNT']))
 enrollment.append({'nces_id':id,'historical_name':a['NAME'],'state':a['STATE'],'enrollment_name':e['LEA_NAME'],'school_year':e['SCHOOL_YEAR'],'enrollment_excluding_adult':e['STUDENT_COUNT'],'denominator_flag':e['DMS_FLAG'],'total_including_adult':t,'adult_count_difference':int(t)-int(e['STUDENT_COUNT']),'source_csv_record':e['source_csv_record'],'validation_cohort':'content_review_primary_subject','study_eligibility':'not_yet_reviewed','model_eligible':'no'})
write('latest_enrollment_join.csv',enrollment)
counts=Counter(r['content_review_status']for r in latest);batchcounts=Counter(r['content_review_status']for r in decisions)
summary=dict(candidate_records=len(latest),batch_records=len(decisions),representatives_reviewed=len(profiles),exact_body_copy_records=sum(r['review_basis']=='exact_body_equivalence'for r in decisions),reviewed_variant_records=sum(r['review_basis']=='reviewed_story_variant'for r in decisions),partial_body_unresolved_records=sum(r['review_basis']=='unresolved_partial_body'for r in decisions),batch_decision_counts=dict(batchcounts),combined_decision_counts=dict(counts),supported_article_records=len(supported),districts_with_supported_articles=len({r['confirmed_nces_id']for r in supported}),reviewed_story_families=len(fam),enrollment_joined_districts=len(enrollment),records_awaiting_substantive_review_with_cached_text=sum(r['content_review_status']=='not_substantively_reviewed'and r['cached_page_available']=='yes'for r in latest),records_awaiting_substantive_review_without_cached_text=sum(r['content_review_status']=='not_substantively_reviewed'and r['cached_page_available']=='no'for r in latest),cached_pages_with_encoded_body_flag=sum(r['encoded_paragraph_markers']>=3 for r in inventory.values()),new_primary_subject_links_missing_from_aliases=len(recovered),all_model_flags_no=all(r['model_eligible']=='no'for r in latest),independent_human_review_complete=False,national_timing_model_ready=False,additional_BigQuery_jobs=0,website_updated=False)
check('counts_reconcile',sum(counts.values())==1054)
check('no_model_eligibility_inferred',summary['all_model_flags_no'])
summary['supported_story_families_in_batch']=sum(rs[0]['content_review_status']=='supported_district_topic'for rs in fam.values())
summary['validation_checks']=checks;(O/'content_review_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
esc=html.escape
section=f'''<!-- CONTENT REVIEW START --><section><h2>Content review and repeated coverage</h2>
<div class="callout"><b>Latest pass, 2 October 2026:</b> {len(decisions)} cached records were assessed through {len(profiles)} representative-story reviews, exact body comparisons and review of changed versions. The combined dataset now has {len(supported)} supported district-topic records across {summary['districts_with_supported_articles']} districts. These include reporting, opinion, proposed policies and retention decisions; they do not count bans.</div>
<p>Review actor: AI assistant. Independent human coding remains pending. The older input field named <code>human_review_status</code> is retained for reproducibility; its name must not be read as evidence that an independent person reviewed those records. The latest table uses <code>content_review_status</code>.</p>
<h3>What was checked</h3><p>One representative was read for each of 29 story profiles. There are {summary['exact_body_copy_records']} additional records with exactly matching extracted bodies after whitespace normalization. A further {summary['reviewed_variant_records']} changed versions were compared, and one unreadable version remained unresolved. Hashes, extraction boundaries and the decision basis are preserved. A matching headline alone never transfers a content decision. Full third-party article text is excluded from this package.</p>
<table><tr><th>Combined content status</th><th>Records</th></tr>'''
for k,v in sorted(counts.items()):section+=f'<tr><td>{esc(k.replace("_"," "))}</td><td>{v:,}</td></tr>'
section+=f'''</table><h3>Repeated reports and geographic errors</h3>
<p>The NPR Forsyth County story has 82 retrieved copies: the representative, 80 exact-body copies, and one copy with two sponsorship insertions. These are distribution records for a single story. The two CNN Gorman versions share a broader source family. The {len(fam)} reviewed families include {summary['supported_story_families_in_batch']} with supported district-topic coverage and cover only this selected batch; they are not a count of independent stories in the annual dataset.</p>
<p>The Knox County headline describes Maine RSU 40/MSAD 40 and Medomak Valley High School. It must not be assigned to a Tennessee or Kentucky district with a similar county name. Other stories mention places where people were interviewed or where publishers operate. Those places are not automatically restriction locations. Additional districts mentioned in an article remain separate review leads.</p>
<h3>Why publication timing still needs care</h3>
<ul><li>The Conroe page was captured as a preview on April 17, 2023 but now reports a decision in an April 19 update.</li><li>The Elmbrook reprint displays November 28, 2022, after its November 8 GDELT record.</li><li>The St. Lucie page now reports a board outcome although its GDELT headline described the removal request.</li><li>The Keller page includes an update after the original August 16 publication.</li></ul>
<p>Current article bodies cannot be assumed to have existed at the first GDELT timestamp. No forecast or lead-lag model uses these records. Publication fields, update notes and restriction stages are retained separately. The previous 20-row selected episode audit remains an exploratory source comparison, not a panel of known restriction onset dates.</p>
<h3>Remaining work</h3><p>{summary['records_awaiting_substantive_review_with_cached_text']} unreviewed records have cached text, while {summary['records_awaiting_substantive_review_without_cached_text']} have no cached text. The latter already have access outcomes in the URL audit. An encoding-pattern check flags {summary['cached_pages_with_encoded_body_flag']} cached pages for further access review; it does not decode restricted bodies or establish relevance. District enrollment is now joined for {len(enrollment)} reviewed identities, while agency eligibility remains pending.</p>
<p>The next content review should cover the remaining accessible stories and seek public primary sources for unresolved cases. The selected batch does not support a precision estimate, a national news-attention measure, or an estimate of the effect of public opposition. No new BigQuery job, paid service or website update was performed.</p>
<p><b>RQ3:</b> What happened when a district reviewed a challenged book with input from librarians and local residents?</p>
<h3>Read and reproduce</h3><p>Start with <code>latest_record_review.csv</code>, <code>reviewed_story_families.csv</code> and <code>remaining_content_review_queue.csv</code>. Run <code>python run_all.py</code> in the unzipped package to rebuild outputs offline. The frozen judgments are inputs: reproduction does not turn them into independently validated evidence. Optional cached-page extraction requires separately obtained page text.</p>
<h3>Reviewed representatives</h3><table><tr><th>Story</th><th>Classification and limit</th></tr>'''
for p in profiles.values():
 r=byid[p['representative_record_id']];section+=f'<tr><td><a href="{esc(r["url"],quote=True)}">{esc(p["headline"])}</a><br>{esc(p["genre"].replace("_"," "))}</td><td>{esc(p["evidence_summary"])}</td></tr>'
section+='</table></section><!-- CONTENT REVIEW END -->'
f=O/'GDELT_District_Link_Review.html';doc=f.read_text();doc=re.sub(r'<!-- CONTENT REVIEW START -->.*?<!-- CONTENT REVIEW END -->','',doc,flags=re.S)
doc=doc.replace('<h1>Historical district verification and title linkage</h1>','<h1>Historical district verification and title linkage</h1>'+section)
doc=doc.replace('<h2>Complete URL access audit and selected episode review</h2>','<h2>Earlier pass: URL access audit and selected episodes</h2>').replace('<b>Latest update:</b> all 925','<b>Earlier update:</b> all 925');f.write_text(doc)
print(json.dumps({k:v for k,v in summary.items()if k!='validation_checks'},indent=2))
