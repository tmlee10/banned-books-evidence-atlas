#!/usr/bin/env python3
"""Optional cached-page extraction, requiring the public-page text cache.

Stores hashes and decisions, not article bodies. Whitespace normalization only;
no fuzzy similarity propagates judgments. The portable rebuild uses the frozen
receipt generated here, because third-party full text is not distributed.
"""
from pathlib import Path
import csv,json,hashlib,re
from collections import Counter
H=Path(__file__).resolve().parent;I=H/'inputs';C=H/'retrieval_cache'
profiles=json.loads((I/'content_review_profiles.json').read_text())
rows=list(csv.DictReader((H/'outputs/combined_record_review.csv').open()))
amap={r['record_id']:r for r in map(json.loads,(I/'public_access_attempts.jsonl').read_text().splitlines())}
def sha(s):return hashlib.sha256(s.encode()).hexdigest()
def normalize(s):return ' '.join(s.split())
def extract(s,p):
 a=s.find(p['start_marker']);b=s.find(p['end_marker'],a+len(p['start_marker']))if a>=0 else -1
 return normalize(s[a:b])if a>=0 and b>a else ''
references={}
for p in profiles:
 id=p['representative_record_id'];s=(C/(id+'.txt')).read_text();body=extract(s,p)
 references[p['profile_id']]=body
 print(p['profile_id'],id,len(body),'OK'if len(body)>300 else'NO_EXTRACT')
receipts=[]
for r in rows:
 id=r['record_id'];f=C/(id+'.txt')
 if not f.exists():continue
 s=f.read_text();proposals=[p for p in profiles if p['headline'].lower().strip()==r['title'].lower().strip()]
 for p in proposals:
  body=extract(s,p);ref=references[p['profile_id']]
  same=bool(body and ref and body==ref and len(body)>300)
  rep=id==p['representative_record_id']
  receipts.append(dict(record_id=id,url=r['url'],profile_id=p['profile_id'],representative_record_id=p['representative_record_id'],cache_sha256=sha(s),http_response_sha256=amap.get(id,{}).get('sha256',''),normalized_body_sha256=sha(body)if body else'',normalized_body_characters=len(body),representative_body_sha256=sha(ref)if ref else'',comparison='exact_whitespace_normalized_body'if same else'body_differs_or_boundary_missing',review_basis='direct_representative_review'if rep else'exact_body_equivalence'if same else'headline_only_unresolved',apply_profile_decision=bool(rep or same),previous_status=r['human_review_status']))
(I/'content_comparison_receipts.json').write_text(json.dumps(receipts,indent=2,ensure_ascii=False)+'\n')
inventory=[]
for r in rows:
 f=C/(r['record_id']+'.txt')
 if f.exists():
  s=f.read_text();count=len(re.findall(r'(?m)^kAm',s))
  inventory.append({'record_id':r['record_id'],'cache_sha256':sha(s),'text_characters':len(s),'encoded_paragraph_markers':count,'quality_flag':'encoded_body_requires_access_review'if count>=3 else'not_assessed_by_encoding_check','quality_flag_is_content_verdict':False})
(I/'cached_page_inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
print(Counter(r['review_basis']for r in receipts))
for p in profiles:
 a=[r for r in receipts if r['profile_id']==p['profile_id']];print(p['profile_id'],sum(r['apply_profile_decision']for r in a),'/',len(a))
