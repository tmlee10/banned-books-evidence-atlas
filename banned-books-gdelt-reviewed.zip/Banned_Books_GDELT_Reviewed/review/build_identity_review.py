#!/usr/bin/env python3
"""Offline identity, selected reported outcomes and repeated-item review.
Frozen assistant decisions are evidence inputs, not independent human validation.
"""
from pathlib import Path
from collections import defaultdict,Counter
import csv,json,html,re
H=Path(__file__).resolve().parent;I=H/'inputs';O=H/'outputs'
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,rs):
 with (O/n).open('w',encoding='utf-8',newline='')as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
def j(n):return json.loads((I/n).read_text())
cross=j('district_identity_review_v6.json');episodes=j('selected_outcome_review_v6.json');repeat=j('repeat_relationship_review_v6.json')
base=read(O/'cache_triage_record_review.csv');by={r['record_id']:r for r in base};off={r['LEAID']:r for r in read(I/'nces_district_office_locations_2223.csv')}
links=[];per=defaultdict(list)
for d in cross:
 id=d['nces_id']
 if id:assert id in off and off[id]['NAME']==d['official_name'] and off[id]['STATE']==d['state']
 for rid in d['applies_to_records']:
  r=by[rid];assert r['content_review_status']=='passage_supports_district_topic' and r['district_name_lead']==d['lead_name']
  per[rid].append(d)
  links.append(dict(record_id=rid,url=r['url'],district_name_lead=d['lead_name'],nces_id=id,state=d['state'],official_name=d['official_name'],identity_status=d['identity_status'],identity_basis=d['identity_basis'],identity_representative_record=d['representative_record_id'],full_article_validation='pending',event_date_validation='see_selected_outcomes_else_pending',model_eligible='no'))
assert len(per)==160
write('identity_article_district_links.csv',links)
flat=[]
for d in cross:
 x=dict(d);x['applies_to_records']=';'.join(x['applies_to_records']);flat.append(x)
write('identity_crosswalk.csv',flat);write('selected_reported_outcomes.csv',episodes);write('repeat_relationships.csv',repeat)
ep={d['record_id']:d for d in episodes};rp=defaultdict(list)
for d in repeat:rp[d['record_id']].append(d)
latest=[];work=[]
for b in base:
 a=dict(b);ds=per.get(b['record_id'],[]);ids=sorted({d['nces_id']for d in ds if d['nces_id']})
 a['identity_review_v6']='resolved_from_reviewed_lead'if ids else'unresolved_identity'if ds else'not_in_v6_identity_pass'
 a['identity_nces_ids_v6']=';'.join(ids);a['identity_entity_count_v6']=len(ids)
 a['reported_decision_date_v6']='';a['reported_date_precision_v6']='';a['reported_stage_v6']='not_reviewed_in_v6';a['repeat_relationships_v6']=';'.join(d['family_id']for d in rp.get(b['record_id'],[]))
 if b['record_id']in ep:
  d=ep[b['record_id']];assert d['nces_id']in ids
  a['reported_decision_date_v6']=d['reported_decision_date'];a['reported_date_precision_v6']=d['date_precision'];a['reported_stage_v6']=d['reported_stage']
 latest.append(a)
 if ds:
  work.append(dict(record_id=b['record_id'],district_name_lead=b['district_name_lead'],nces_ids=';'.join(ids),identity_status=a['identity_review_v6'],next_action='Obtain geographic evidence before assigning NCES ID.'if not ids else'Obtain primary decision record; independently verify outcome, access dates and repetition.'if b['record_id']in ep else'Complete full-context article review, verify event stage and dates, and review story provenance.',url=b['url']))
write('identity_record_review.csv',latest);write('identity_validation_worklist.csv',work)
resolved=[r for r in links if r['nces_id']];newids={r['nces_id']for r in resolved};oldids={r['confirmed_nces_id']for r in base if r['content_review_status']=='supported_district_topic'}
summary=dict(candidate_records=len(base),district_topic_leads_checked=len(per),lead_labels=len({d['lead_name']for d in cross}),records_with_resolved_identity=len({r['record_id']for r in resolved}),records_with_unresolved_identity=len(per)-len({r['record_id']for r in resolved}),resolved_article_entity_links=len(resolved),distinct_resolved_entities=len(newids),entities_not_in_earlier_35_district_set=len(newids-oldids),multi_entity_records=sum(len({d['nces_id']for d in ds if d['nces_id']})>1 for ds in per.values()),selected_reported_outcomes=len(episodes),primary_documents_checked_for_new_outcomes=0,reported_outcome_stage_counts=dict(Counter(d['reported_stage']for d in episodes)),repeated_publisher_items=4,exact_syndicated_body_families=1,shared_roundup_components_not_duplicates=1,records_in_repeat_relationship_review=len(repeat),records_collapsed=0,new_first_inaccessibility_dates=0,uncached_records_awaiting_substantive_review=382,independent_human_review_complete=False,model_eligible_records=sum(r['model_eligible']=='yes'for r in latest),additional_BigQuery_jobs=0,website_updated=False)
assert summary['records_with_resolved_identity']+summary['records_with_unresolved_identity']==160 and summary['model_eligible_records']==0
(O/'identity_review_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
e=html.escape
section=f'''<!-- IDENTITY REVIEW START --><section><h2>Latest update: district identities and selected outcomes</h2>
<div class="callout"><b>2 October 2026.</b> All 160 new district-topic leads were checked against the 2022–2023 NCES directory. Identities were resolved for {summary['records_with_resolved_identity']} records; {summary['records_with_unresolved_identity']} remain unresolved. These are entity matches, not {summary['records_with_resolved_identity']} verified bans.</div>
<p>The {summary['resolved_article_entity_links']} resolved article-to-entity links cover {summary['distinct_resolved_entities']} distinct school systems. {summary['multi_entity_records']} articles discuss more than one district, so the link total exceeds the article count. Earlier content classifications remain intact: identifying the district does not independently validate the article, date, or outcome.</p>
<h3>Names that needed care</h3><p>Hempfield Area and Hempfield are separate Pennsylvania districts. Maine RSU 24 is distinct from RSU 40/MSAD 40. Orange Unified in California is distinct from Orange County schools in Florida. The Spring Lake High School and Old Rochester Regional High School names were checked against the NCES school directory. School systems, administrative offices and charter agencies were kept separate.</p>
<p>Four records retain unresolved identities: Madison County Schools, Marion County, Brookfield and the caption-only Hempfield record. Similar names, reporter biographies and unsupported state assumptions were not accepted as identity evidence.</p>
<h3>What happened after review: six selected reports</h3><p>These cases were chosen to examine different procedural outcomes relevant to RQ3. They are not a representative sample and cannot establish whether public opposition caused a decision. Current cached news text is the source; primary district documents have not yet been checked for these six outcomes.</p>
<table><tr><th>District</th><th>Reported date and precision</th><th>Outcome and evidence limit</th></tr>'''
for d in episodes:section+=f'<tr><td><a href="{e(d["source_url"],quote=True)}">{e(d["district"])}, {e(d["state"])}</a></td><td>{e(d["reported_decision_date"])}<br><small>{e(d["date_precision"].replace("_"," "))}</small></td><td>{e(d["outcome_summary"])}<br><small>{e(d["participation_reported"])}</small></td></tr>'
section+='''</table><p><b>Correction:</b> Ludlow declined to vote on the proposal. An earlier headline described rejection, but the article explicitly corrects it. Retaining a challenged book is also different from reversing an implemented ban. Hillsborough's reported board order does not establish the day books physically became unavailable.</p>
<p>Dates are separated by precision. Mead has only a month-level contextual date. Newtown and Hillsborough dates are inferred from weekday language anchored to the displayed publication date; they are not exact primary-record dates. First inaccessibility and duration are blank for every new case. No GDELT timestamp is substituted for a restriction date.</p>
<h3>Repeated reporting</h3><p>Four pairs share the same publisher's article identifier despite different headline slugs: Central Bucks/WFMZ, Denton, Old Rochester and the Lafayette public-library commentary. Three St. Lucie iHeart records share the byline, date and exactly matching extracted article body. A Dearborn roundup shares a segment with a standalone article; the whole roundup is not treated as a duplicate. Every original record is retained.</p>
<h3>Next evidence step</h3><p>The resolved identities can guide full-context article review and retrieval of district minutes or decisions. The six selected outcomes need primary-source corroboration. The 382 uncached records remain substantively unreviewed. These results do not support a national timing model, a causal effect of opposition, or an Ohio forecast.</p>
<p><b>RQ3:</b> What happened when a district reviewed a challenged book with input from librarians and local residents?</p>
<p>Use <code>identity_record_review.csv</code> for the current combined table; <code>identity_article_district_links.csv</code> for one-to-many identity links; <code>selected_reported_outcomes.csv</code> for dates and outcome limits; and <code>repeat_relationships.csv</code> for story relationships. <code>identity_validation_worklist.csv</code> lists the remaining work for all 160 leads. Earlier report sections and output files are retained as an audit history.</p>
<p>The package reproduces these tables from frozen assistant decisions. Independent human review remains pending. No additional BigQuery job, paid extraction or public website update occurred in this pass.</p></section><!-- IDENTITY REVIEW END -->'''
p=O/'GDELT_District_Link_Review.html';doc=p.read_text();doc=re.sub(r'<!-- IDENTITY REVIEW START -->.*?<!-- IDENTITY REVIEW END -->','',doc,flags=re.S)
doc=doc.replace('<h1>Historical district verification and title linkage</h1>','<h1>Historical district verification and title linkage</h1>'+section).replace('<h2>Latest update: all remaining cached records assessed</h2>','<h2>Earlier pass: all remaining cached records assessed</h2>');p.write_text(doc)
print(json.dumps(summary,indent=2))
