import pathlib,zipfile,csv,io,json,collections,hashlib
H=pathlib.Path(__file__).resolve().parent;p=H/'inputs/ccd_lea_052_2223_l_1a_083023.zip'
z=zipfile.ZipFile(p);nm=z.namelist()[0]
counts=collections.Counter();ex={};selected=[];digest=hashlib.sha256()
# Identify published total categories and preserve only Education Unit Totals.
with z.open(nm)as f:
 reader=csv.DictReader(io.TextIOWrapper(f,encoding='utf-8-sig',newline=''))
 for i,r in enumerate(reader,2):
  t=r['TOTAL_INDICATOR'];counts[t]+=1
  if t not in ex:ex[t]=r
  if t in ['Education Unit Total','Derived - Education Unit Total minus Adult Education Count']:selected.append({'source_csv_record':i,**r})
print('categories',counts);print('examples',json.dumps(ex,indent=2));print('selected',len(selected))
(H/'inputs/enrollment_categories.json').write_text(json.dumps({'source_member':nm,'categories':counts,'examples':ex,'selection':'Education Unit Total and derived total excluding adult education'},indent=2)+'\n')
if selected:
 with (H/'inputs/nces_lea_enrollment_totals_2223.csv').open('w',newline='')as f:
  w=csv.DictWriter(f,fieldnames=list(selected[0]));w.writeheader();w.writerows(selected)
