#!/usr/bin/env python3
"""Deterministic alias candidate generation, not event/district confirmation."""
from pathlib import Path
import csv,json,re,unicodedata,html
from collections import defaultdict,Counter
from urllib.parse import urlsplit,unquote
H=Path(__file__).resolve().parent;B=H.parent/'baseline_audit'
if not B.exists():B=H.parent/'gdelt_full_year/package'
O=H/'outputs';O.mkdir(exist_ok=True)
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
def write(n,r):
 with (O/n).open('w',newline='',encoding='utf-8')as f:
  w=csv.DictWriter(f,fieldnames=list(r[0]));w.writeheader();w.writerows(r)
def norm(s):
 s=unicodedata.normalize('NFKD',html.unescape(unquote(s))).encode('ascii','ignore').decode().lower().replace('&',' and ')
 return re.sub('[^a-z0-9]+',' ',s).strip()
def core(s):
 s=re.sub(r'^the |^school district of |^school district no \d+ in ','',s)
 s=re.sub(r'\bisd\b','independent school district',s)
 s=re.sub(r'\bsd\b','school district',s)
 s=re.sub(r' (?:public |city |area |community |central |unified |union |independent |county )*(?:schools|school district|district|school corporation|school administrative district)(?: (?:no )?\d+[a-z]?| r [ivx]+| [ivx]+)?$','',s).strip()
 return s
pen=read(B/'inputs/pen_events.csv');off=read(H/'inputs/nces_district_office_locations_2223.csv')
# Explicit state-name mapping from the NCES membership extract.
ens=read(H/'inputs/nces_lea_enrollment_totals_2223.csv')
state_names={r['ST']:r['STATENAME'].title()for r in ens}
old=read(O/'candidate_review.csv');oldpairs={(r['record_id'],r['candidate_state'],r['candidate_district'])for r in old}
historical=json.loads((H/'inputs/historical_identity_decisions.json').read_text())
known={(r['candidate_state'],r['candidate_district']):r['nces_id']for r in historical}
entities={}
for r in off:
 state=state_names.get(r['STATE'],r['STATE'])
 entities['NCES:'+r['LEAID']]={'entity_key':'NCES:'+r['LEAID'],'state':state,'state_code':r['STATE'],'district':r['NAME'],'nces_id':r['LEAID'],'basis':'official_2022_2023_office_name','pen_district':''}
for s,d in sorted({(r['state'],r['district'])for r in pen}):
 k='NCES:'+known[(s,d)]if(s,d)in known else 'PEN:'+s+':'+d
 if k not in entities:entities[k]={'entity_key':k,'state':s,'state_code':next((st for st,n in state_names.items()if n==s),''),'district':d,'nces_id':'','basis':'PEN_name_historical_ID_unresolved','pen_district':d}
 else:entities[k]['pen_district']=d
# Aliases are mechanical search leads. They do not silently validate name matches.
alias_map=defaultdict(set);alias_rows=[]
stop={'school','schools','district','public','community','education','academy','charter','independent','union','central','state','city','county','high','elementary','school district','public schools','county schools','independent school district','unified school district'}
stop.update(norm(v) for v in state_names.values())
for k,e in entities.items():
 for original in filter(None,[e['district'],e['pen_district']]):
  full=norm(original);short=core(full)
  aliases={(full,'full_source_name'),(short,'mechanical_short_name')}
  if 'independent school district' in full:aliases.add((full.replace('independent school district','isd'),'isd_abbreviation'))
  if 'county public schools' in full:aliases.add((full.replace('county public schools','county schools'),'public_omitted'))
  for a,rule in sorted(aliases):
   if a in stop or len(a)<4:continue
   alias_map[a].add(k);alias_rows.append({'entity_key':k,'state':e['state'],'source_name':original,'alias':a,'rule':rule,'identity_status':'candidate_only'})
trie={}
for a in alias_map:
 node=trie
 for w in a.split():node=node.setdefault(w,{})
 node.setdefault('_aliases',[]).append(a)
raw=read(B/'outputs/review_queue.csv');out=[]
for r in raw:
 txt=norm(r['title_decoded']+' '+urlsplit(r['url']).path);words=txt.split();hits=defaultdict(set)
 school=bool(re.search(r'\b(school|schools|district|isd|students|classroom|classrooms)\b',txt))
 for i in range(len(words)):
  node=trie;j=i
  while j<len(words)and words[j]in node:
   node=node[words[j]];j+=1
   for a in node.get('_aliases',[]):
    if len(a.split())==1:
     # Prevent a loose one-word geographical match; demand a nearby school phrase.
     right=' '.join(words[j:j+5]);left=' '.join(words[max(0,i-3):i])
     if not(re.match(r'(?:(?:city|county|public|area|community|independent|unified) )*(?:schools?|district|isd|sd)\b',right)or re.search(r'(?:school district of|schools in|district in)$',left)):continue
    for k in alias_map[a]:hits[k].add(a)
 for k,aa in sorted(hits.items()):
  e=entities[k];state_in=bool(re.search(r'\b'+re.escape(norm(e['state']))+r'\b',txt))
  ambiguous=any(len(alias_map[a])>1 for a in aa)
  longest=max(aa,key=len);has_school_alias=bool(re.search(r'\b(school|schools|district|isd|sd)\b',longest))
  priority=(4 if state_in else 0)+(2 if school else 0)+(1 if has_school_alias else 0)+(0 if ambiguous else 1)
  oldmatch=(r['record_id'],e['state'],e['pen_district']or e['district'])in oldpairs
  out.append({'record_id':r['record_id'],'recorded_at':r['recorded_at'],'entity_key':k,'state':e['state'],'candidate_district':e['district'],'pen_district':e['pen_district'],'candidate_nces_id':e['nces_id'],'alias_matches':' | '.join(sorted(aa)),'alias_ambiguous_across_entities':str(ambiguous).lower(),'explicit_state_name_in_text':str(state_in).lower(),'school_context_in_text':str(school).lower(),'priority_score':priority,'in_original_literal_pairs':str(oldmatch).lower(),'review_status':'pending_not_confirmed','title':r['title_decoded'],'url':r['url']})
write('alias_dictionary.csv',alias_rows);write('expanded_alias_candidates.csv',out)
write('candidate_entity_register.csv',list(entities.values()))
original_records={r['record_id']for r in old};new={r['record_id']for r in out}-original_records
summary={'input_records':len(raw),'source_office_entities':len(off),'candidate_entities':len(entities),'distinct_aliases':len(alias_map),'candidate_pairs':len(out),'candidate_records':len({r['record_id']for r in out}),'candidate_entity_keys':len({r['entity_key']for r in out}),'new_candidate_records_not_in_original_screen':len(new),'original_records_recovered':len(original_records&{r['record_id']for r in out}),'new_records_with_explicit_state_and_school_context':len({r['record_id']for r in out if r['record_id']in new and r['explicit_state_name_in_text']=='true'and r['school_context_in_text']=='true'}),'interpretation':'Unreviewed name-match leads, not verified districts or bans. No precision/recall estimate. Official entity registry includes agency types not yet screened for study eligibility.'}
(O/'expanded_alias_summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
