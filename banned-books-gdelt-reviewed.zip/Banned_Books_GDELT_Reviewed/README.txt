VERSION 13 — WORKBOOK DATE AUDIT AND INDEPENDENT REVIEW (4 October 2026)
=====================================================================
Current report: review/outputs/GDELT_Validation_Sample.html

CORRECTION: earlier report wording was wrong for three PEN months. The source
workbook and extracted CSV show March 2023 for Indian River and Miami-Dade,
and May 2023 for Davis. The old prose said February, February and April.
All 3,362 preserved rows were checked against the correct workbook sheet and
cell. Source title, author, district, state, status and date agree with the CSV.
Numeric dates represent approximate months, not exact days: 2,778 rows have an
approximate month; 584 retain coarser text or missing date information.

Indian River: the PEN month agrees with the reviewed article's March month.
No exact onset or classroom scope is established. Miami-Dade remains March in
PEN versus an April committee meeting in reporting; Hillsborough remains April
in PEN versus a March 28 board decision. Davis May and June describe different
stages. No new onset, duration, causal estimate or forecast is accepted.

The fixed sample still contains 13 supported school-topic records, 4 other and
19 unresolved records. No additional BigQuery query was run.

Run python run_all.py to rebuild the analysis. The final build_date_review.py
checks raw XLSX cells using the workbook's named-sheet relationship and date
system, corrects current prose and creates the review materials.
Current comparisons: review/outputs/sample_title_probes_v13.csv
Date corrections: review/outputs/date_corrections_v13.csv
Full cell audit: review/outputs/pen_date_cell_audit_v13.csv

SECOND REVIEWER
Open review/outputs/Independent_Review.html. The form contains all 36 selected
sources without the previous decisions. It sends nothing to a server. Export
JSON before closing and import that JSON to resume. No responses are supplied
or claimed complete. A human reviewer must read the sources and record evidence.
After all records are completed, run:
python review/compare_independent_review.py path/to/Independent_Review_Responses.json
The comparison refuses incomplete responses, reports disagreements and never
automatically changes research decisions or certifies reviewer independence.

Historical files and sections below retain superseded wording for traceability.
Use the v13 outputs and correction table for current date interpretations.

VERSION 12 — ORIGINAL-ARTICLE AND BOARD-MINUTES FOLLOW-UP (3 October 2026)
========================================================================
Start with review/outputs/GDELT_Validation_Sample.html.
The original 36-record selection is unchanged. Of the 20 previously unresolved
records, one CNN body was recovered and supports Davis District, Utah (4900210).
The updated counts are 13 school-topic, 4 outside-scope/unrelated, 19 unresolved.
Nine records support at least one original district candidate; eight support none.
There are 10 supported, 34 rejected and 50 unresolved candidate/alias pairs.

Davis district minutes confirm a June 20, 2023 board decision to reinstate the
Bible. This is a decision date, not proof of actual reshelving. PEN's April month,
CNN's June publication and the board decision are retained separately. No onset
or duration is accepted, and no record becomes eligible for modeling.

Run python run_all.py. Fifteen ordered scripts rebuild the baseline and review
outputs without network access. build_sample_followup.py applies the frozen v12
judgment after rebuilding v11. Article-reading judgments require independent
human review; the code does not independently adjudicate source truth.

Current sample: review/outputs/sample_review_v12.csv
Current candidate pairs: review/outputs/sample_candidate_pairs_v12.csv
Current full ledger: review/outputs/current_record_review_v12.csv
Access follow-up: review/outputs/sample_followup_access_v12.csv
Davis outcome: review/outputs/sample_outcome_followup_v12.csv
Primary PDF: review/inputs/primary_sources/davis_20230620_minutes.pdf
Earlier v11 files remain the frozen prior pass. Read the newest version for
current counts. Publication-status text below describes historical snapshots;
v11 was published October 3 using the authorized GitHub browser session.
No additional BigQuery jobs or paid services were used.

HISTORICAL SNAPSHOTS FOLLOW
==========================
VERSION 11 — FIXED VALIDATION SAMPLE (2 October 2026)
====================================================
Start with review/outputs/GDELT_Validation_Sample.html for the concise current report.
GDELT_District_Link_Review.html retains all prior audit passes and the latest summary.

36 records were selected before new content review: three per GDELT month using a
fixed SHA-256 ordering, from all 1,054 candidates. There were no replacements for
failed pages. Sample judgments: 12 school-topic records, four outside school scope
or unrelated keyword matches, 20 unresolved. Eight records support at least one
original district candidate; eight support none; 20 remain unresolved.

The 94 candidate pairs include duplicate district aliases, so they are not 94
unique districts. Eleven article subject identities were checked against the
2022–2023 NCES office and school files, spanning eight states. Thirty-two title
probes yielded 12 correspondences but no newly accepted dated restriction link.

Run python run_all.py. The added script review/build_sample_review.py recreates
the selection and aggregates the frozen judgments. No network or extra BigQuery
query is required. Reading an article is a review judgment, not reproduced by code.
Independent human review remains pending. Review decisions, hashes, access logs,
NCES checks and PEN source-row references are included. Publisher articles are
not redistributed. No national match-accuracy rate or causal effect is estimated.

Current all-record ledger: review/outputs/current_record_review_v11.csv.
Current sample decisions: review/outputs/sample_review_v11.csv.
Candidate pair decisions: review/outputs/sample_candidate_pairs_v11.csv.
PEN comparisons: review/outputs/sample_title_probes_v11.csv.
Frozen sample specification: review/inputs/sample_protocol_v11.json.

Website publication is blocked by GitHub access. Render's banned-books service
points to tmlee10/banned-books-evidence-atlas; the connected GitHub account returned
404 for that repository. The older danangnu repository was not modified.
The self-contained GDELT_Validation_Sample.html can be published after access is
restored. Render currently extracts banned-books-project.zip at build time, so a
future deployment must update that archive or deliberately change the build;
placing a file in dist alone may be overwritten by extraction.

The Hillsborough date conflict and Newtown draft-minutes qualifications remain.
Older versioned ledgers below are audit history, not cumulative new observations.

CURRENT UPDATE — 2 OCTOBER 2026 — SIX-CASE OUTCOME REVIEW (VERSION 10)

Start with review/outputs/GDELT_District_Link_Review.html.
Latest complete ledger: review/outputs/current_record_review_v10.csv (1,054 rows).
Selected outcome table: review/outputs/selected_case_outcomes_v10.csv (6 rows).

NEW EVIDENCE
Newtown: acquired June 1, 2023 draft minutes support retention of Flamer and
Blankets in the high-school library and development of a process for individual
parent/guardian concerns. The motion passes unanimously. Because the roster is
internally inconsistent, no numeric tally is inferred. Draft status remains;
a final corrected copy was not acquired. Earlier access history is unknown.

Ludlow: acquired signed June 13 minutes show no second for adopting the proposed
library policy, so no adoption vote. A separate procedural motion concerning
legal concerns had 2 yes and 3 no responses. June 27 minutes approve June 13
minutes through a 5-0 consent-calendar vote. These three actions stay separate.

All six selected procedural outcomes now have acquired primary-source support.
This includes one draft-minutes case. It is NOT six bans, a representative sample,
a causal comparison or a validated timing model. Independent human review remains
pending. Three cases concern retention, one rejection of a policy revision,
one proposal without an adoption vote, and one middle-school removal.

HILLSBOROUGH STILL PROVISIONAL
The March 28 decision and PEN April 2023 date remain different. Workbook row 658
has no case-source hyperlink or explanatory comments. No acquired evidence
explains the difference. Do not overwrite the PEN date, create a second event,
or infer a duration. No new PEN event link was accepted in this pass.

PEN COVERAGE
The preserved 2022-2023 index has no Connecticut rows. Its only Massachusetts
entry belongs to Abington. Neither absence establishes zero bans or uninterrupted
access in Newtown or Ludlow. A general policy proposal has no title-specific join.

REPRODUCE
Run python run_all.py from this extracted folder. The final script is
review/build_followup_review.py. It checks original baseline and included source
hashes, maintains the Hillsborough conflict, and rebuilds the current ledger,
source/lookup tables, 24-record chronology and six-case overview SVG offline.
Only Python's standard library is required for this replay. Original acquisition,
OCR and source interpretation are not independently repeated by this command.

NEW FILES
review/inputs/followup_decisions_v10.json
review/inputs/followup_sources_v10.json
review/inputs/followup_access_log_v10.json
review/inputs/hillsborough_date_followup_v10.json
review/inputs/primary_sources/Newtown_2023_06_01_review_excerpt.pdf
review/inputs/primary_sources/Ludlow_2023_06_13_decision_page.pdf
review/inputs/primary_sources/Ludlow_2023_06_27_approval_excerpt.pdf

review/outputs/followup_source_register_v10.csv
review/outputs/followup_access_log_v10.csv
review/outputs/hillsborough_date_followup_v10.csv
review/outputs/followup_pen_lookup_v10.csv
review/outputs/selected_case_outcomes_v10.csv
review/outputs/current_record_review_v10.csv
review/outputs/selected_six_case_chronology_v10.csv
review/outputs/selected_six_case_outcomes_v10.svg
review/outputs/followup_summary_v10.json

Source excerpts identify omitted public-comment material. Newtown home addresses
are removed; Ludlow's approval excerpt excludes an unrelated public-comment
letter. Original source URLs, hashes, page numbers and transformations remain
in the register. The PDFs are review excerpts, not substitutes for full originals.

NEXT EVIDENCE
Request clarification of PEN's Hillsborough date and a final/corrected Newtown
minutes copy. No messages have been sent. Expand a defined case sample and
independently review outcomes before estimating timing or duration.

No additional BigQuery query, causal model, Ohio forecast or website update.
All model-eligibility flags remain no. Earlier sections are dated audit history.

EARLIER UPDATE — 2 OCTOBER 2026 — HILLSBOROUGH REVIEW (VERSION 9)

Open review/outputs/GDELT_District_Link_Review.html. The current all-record table
is review/outputs/hillsborough_record_review.csv (1,054 unchanged candidate rows).
The current six-case outcome table is selected_primary_outcomes_current.csv.

Hillsborough's March 28, 2023 board decision is now supported by the meeting
archive and caption transcript: 4-3 removal of This Book Is Gay from all district
middle schools. The Florida DOE 2022–2023 annual report also lists the title,
author and district, with one removal. It lists three objections, not three bans.
Four of six selected outcomes now have primary decision/date support. Newtown
has partial support; Ludlow's decision remains unverified. These six examples
are selected procedural cases, not a representative or model-ready sample.

IMPORTANT DATE CONFLICT: the preserved PEN entry is APRIL 2023, not March.
The original I658 date cell contains 45017.0 and uses format mmmm yyyy. Its serial
must not be interpreted as an exact restriction day. Title, author and district
match, but the April month differs from the March 28 vote. The event link remains
provisional. No new PEN event link or ban instance was accepted in this pass.
The discrepancy could concern reporting or implementation; neither is established.

The transcript HTML title refers to December 2022 and its body heading gives
4 p.m.; the opening speech and linked archive page agree on March 28, 2023.
Only day precision is used. Approved minutes and independent video review are
still outstanding. PEN's Libraries and Classrooms category is retained alongside
the transcript's middle-school scope. No high-school removal is inferred.

New outputs in review/outputs/:
- hillsborough_pen_link.csv: one provisional match, date and scope conflicts.
- hillsborough_source_register.csv: three sources and included-evidence hashes.
- hillsborough_chronology.csv: six records with separate date precision.
- hillsborough_evidence_chronology.svg: reusable visual in the report.
- selected_primary_outcomes_current.csv: current status of the six selected cases.
- hillsborough_record_review.csv: latest 1,054-row review table.
- hillsborough_review_summary.json: exact counts and limitations.

New frozen inputs: hillsborough_decision_v9.json and hillsborough_sources_v9.json.
The primary_sources folder includes the full official state PDF and two short
webcast review notes with source URLs and hashes; full transcript/news bodies
and individual-speaker profiling are not distributed.

Run python run_all.py from the extracted folder. The final step is now
review/build_hillsborough_review.py. It verifies source hashes, district and
author matching, original workbook formatting, and the date discrepancy offline.
It intentionally fails if those source facts change. Reproducing frozen review
judgments is not independent substantive validation.

Unknown first inaccessibility, duration and reversal remain blank. Independent
human review is pending. All model flags stay no. No extra BigQuery job, causal
model, Ohio forecast, or website publication was performed.

Next evidence targets: explain the Hillsborough April index month using the
underlying PEN source or implementation record; acquire Newtown and Ludlow
outcome records; then expand validated cases before comparing timing.
Earlier sections below are dated audit history, not current status.

EARLIER UPDATE — 2 OCTOBER 2026 — SELECTED CASE CHRONOLOGIES (VERSION 8)

Start with review/outputs/GDELT_District_Link_Review.html. The latest combined
table is review/outputs/case_timeline_record_review.csv (1,054 candidate rows).

Three primary-confirmed decisions were searched against all 3,362 preserved
PEN 2022–2023 rows. No matching title-and-district row was found for the three
selected titles. Mead's rejected policy proposal has no title-specific join.
This is a completed lookup with no accepted new event links, not a failed run.

- Old Rochester: Felix Ever After and Push retained, June 21, 2023.
- Forsyth County: Endlessly Ever After retained, April 18, 2023.
- Mead: library-policy revision rejected, September 12, 2022.

Five national Felix Ever After entries and 20 Push entries concern other
state/district combinations. Four Forsyth entries concern different titles.
All 29 partial matches are retained in an exclusion table. Absence from this
index is NOT zero bans, proof of unrestricted access, or full reporting coverage.
No case reached an accepted title/author/district/episode join.

New outputs under review/outputs/:
- selected_case_pen_scope.csv: source coverage, state roster and district lookup.
- selected_decision_pen_links.csv: three title searches and one policy case.
- selected_pen_candidate_exclusions.csv: 29 rejected partial matches.
- selected_case_timeline.csv: 11 dated evidence records for three cases.
- selected_case_chronologies.svg: reusable visual, embedded in the HTML report.
- case_timeline_record_review.csv: current all-record table with v8 scope status.
- case_timeline_summary.json: exact counts and limits.

New frozen input: review/inputs/selected_case_scope_v8.json.
Run python run_all.py from the extracted folder. The final step is now
review/build_case_timelines.py. It uses only the Python standard library.
The earlier workbook check validates all derivative PEN rows against the XLSX.
The SVG is regenerated deterministically, with no font download or paid service.

Decision dates, displayed publication dates and GDELT timestamps are different
fields. No same-day ordering, first coverage, historical article availability,
first inaccessibility or restriction duration is inferred. Old Rochester's
September 2023 minutes approval is later corroboration outside the study window.
Three unconfirmed outcomes from v7 remain unresolved. Independent review is
pending. No additional BigQuery query, model, Ohio forecast or website update.

Earlier sections below are dated audit history; use the v8 files listed above.

EARLIER UPDATE — 2 OCTOBER 2026 — PRIMARY DECISION REVIEW (VERSION 7)

Open review/outputs/GDELT_District_Link_Review.html. The latest all-record table
is review/outputs/primary_record_review.csv (1,054 unchanged candidate rows).

All six selected news outcomes received primary-source retrieval/review:
- Confirmed decision/date: Old Rochester, Mead, Forsyth County (three).
- Partial primary support, outcome unconfirmed: Newtown, Hillsborough (two).
- Relevant primary decision not acquired: Ludlow (one).

These are selected procedural cases, NOT six bans or a national sample.
Old Rochester retained two titles by separate 7-1 votes on June 21, 2023.
Mead rejected the library-policy revision on September 12, 2022 with four
nay votes and one abstention. Forsyth's district register records retention
of Endlessly Ever After on April 18, 2023; participation details remain unchecked.

The package includes three selected-page official PDF files, two short webpage
review notes, a source register with hashes/page locators, six frozen review
decisions, and the retrieval log. Original complete PDF hashes are supplied;
PDF excerpts have their own hashes. Webpage notes are reviewer paraphrases,
not source HTML. Unsuccessful downloads and indexed-only evidence are labeled.

Run python run_all.py from this folder to reproduce outputs offline. The last
step is review/build_primary_review.py. It verifies included evidence hashes.
Reproducing the outputs does not independently validate the frozen judgments.

Files added:
- inputs/primary_outcome_review_v7.json
- inputs/primary_source_register_v7.json
- inputs/primary_access_log_v7.json
- outputs/primary_outcome_review.csv
- outputs/primary_source_register.csv
- outputs/primary_record_review.csv
- outputs/primary_validation_worklist.csv
- outputs/primary_review_summary.json
(All paths above are under review/.)

Earlier content and identity statuses remain intact. Primary date fields are
separate from earlier news-reported dates; related story copies are not promoted.
No first-inaccessibility dates, durations, causal findings, new BigQuery jobs,
paid extraction, website update or Ohio forecast were added. The 382 uncached
records and four unresolved identities remain outstanding. All model eligibility
flags remain no; independent human review is pending.

The earlier sections below are preserved as dated audit history. Their
then-current counts and evidence gaps are superseded where v7 specifies changes.

EARLIER UPDATE — 2 OCTOBER 2026 — IDENTITY AND OUTCOME REVIEW (VERSION 6)

Start with review/outputs/GDELT_District_Link_Review.html and
review/outputs/identity_record_review.csv. Earlier files remain audit history.

All 160 new district-topic leads received an NCES identity check. 156 records
were linked to 90 distinct 2022–2023 NCES district entities. Four multi-entity
articles account for 162 resolved article-entity links. This does NOT mean
156 verified bans, 90 affected districts, or completed full-article validation.
Identities were resolved by manual name/context matching, including named
school checks where needed; no fuzzy match was silently accepted.

Four identities remain unresolved: Madison County Schools, Marion County,
Brookfield and the caption-only Hempfield record. NCES IDs remain blank.

Six selected readable reports now have explicit procedural outcomes and date
precision. They concern Old Rochester, Mead, Forsyth County, Newtown, Ludlow
and Hillsborough. These are purposively selected news accounts, not a national
sample. Primary documents and first inaccessibility dates remain unverified.
Ludlow declined to vote; the article corrects an earlier rejection headline.
Retaining a book after a challenge is not proof of reversing an implemented ban.
Mead has a contextual month, not an exact meeting date. Newtown/Hillsborough
reported days are weekday/publication-date inferences and are flagged as such.

Four repeated publisher-item pairs, one three-copy iHeart story with identical
extracted bodies, and one shared Dearborn roundup segment were documented.
A roundup containing repeated content is not wholly duplicated. Original rows
remain intact. Relationships do not establish independent event counts.

New inputs:
- district_identity_review_v6.json: manual crosswalk decisions and unresolved cases.
- selected_outcome_review_v6.json: six news-reported outcomes with date limitations.
- repeat_relationship_review_v6.json: publisher identifiers, byline evidence and hashes.
New outputs:
- identity_record_review.csv: all 1,054 records, with added identity/outcome fields.
- identity_article_district_links.csv: one row per article/entity or unresolved lead.
- identity_crosswalk.csv: 90 lead labels, including multi-district mappings.
- selected_reported_outcomes.csv: stage, participation, source, precision and limits.
- repeat_relationships.csv: 13 records with reviewed repetition relationships.
- identity_validation_worklist.csv: remaining validation tasks for the 160 leads.
- identity_review_summary.json: exact counts and readiness flags.

Identity fields are deliberately separate from prior content status and from
confirmed_nces_id in earlier passes. A new identity match does not promote a
passage review to a verified full-article result. No new enrollment rates,
ban totals, restriction duration, causal result or Ohio forecast is produced.
No additional BigQuery job or website update occurred. 382 uncached records
still lack substantive review. Independent human review remains pending.

Run python run_all.py after unzipping to reproduce offline. The final step is
review/build_identity_review.py. Judgments are frozen inputs; reproduction is
not independent verification. Third-party article text is not redistributed.

EARLIER UPDATE HISTORY
======================

EARLIER UPDATE — 2 OCTOBER 2026 — CACHE TRIAGE (VERSION 5)

Start with review/outputs/GDELT_District_Link_Review.html and
review/outputs/cache_triage_record_review.csv.

All 359 previously unreviewed cached records have a disposition: 278 received
selected-passage review by the AI assistant; 81 received access assessment only
because their bodies were encoded. This is completed cache triage, not completed
full-article or independent human review.

New dispositions: 160 district-topic passage leads; 23 context-only passages;
41 provisionally outside school scope; 22 provisionally non-content matches;
113 unresolved (81 access assessments plus 32 insufficient passages).
Two of the 32 also visibly contained encoded material missed by the earlier
quality heuristic. No restricted text was decoded.

The earlier 206 supported district-topic records across 35 confirmed district
identities are unchanged. Do not add the 160 leads to the verified-district
count. Every new lead still needs full context, exact district identification,
story-family checks and defensible dates. None establishes a new ban by itself.
382 other records have no usable cache and remain substantively unreviewed.
All 1,054 candidate records are preserved. None is eligible for a timing model.

Files added in this update:
- inputs/passage_triage_decisions.json: frozen assistant judgments with URLs,
  cache hashes, selected-passage hashes/lengths, evidence notes and limitations.
- outputs/cache_triage_record_review.csv: current dispositions of all 1,054.
- outputs/cache_triage_decisions.csv: the 359 new dispositions.
- outputs/validation_worklist.csv: explicit remaining action for each record
  requiring evidence review, identity/date verification or independent review.
- outputs/identical_passage_review_leads.csv: six equal-excerpt groups. These
  are possible repeats, not confirmed story families; no rows are collapsed.
- outputs/cache_triage_summary.json: exact counts and completion flags.
- build_passage_triage.py: final offline reproduction stage.

Interpretation of new CSV statuses:
passage_supports_district_topic = local school topic supported by selected text;
  identity, full context, event timing and outcomes have NOT been validated.
passage_context_only = general or historical discussion; no local action proven.
passage_outside_school_scope = selected text concerns another setting; provisional.
passage_noncontent_match = selected text concerns an unrelated kind of challenge;
  provisional, not proof that the full article contains no relevant material.
unresolved_article_evidence = readable, relevant and sufficient evidence missing.

The district_name_lead field contains names for follow-up, including ambiguous
and multi-district references. It is not an NCES crosswalk. No new confirmed
NCES IDs, dates, enrollment denominators or event counts were generated here.

Method: selected passages were taken from the first unique long lines after
common boilerplate filtering. Some are captions or partial introductions.
Assistant judgments are recorded separately from automatic access flags.
Source text is not redistributed. Hashes identify the cached text used (UTF-8,
with Python universal-newline normalization) and the selected passage. The
complete third-party text and scratch packets are excluded from this package.
Re-running the code reproduces outputs from frozen judgments; it does not
independently verify those judgments or redownload historic page versions.

Reproduction: unzip, then run python run_all.py with Python 3 and the existing
baseline dependencies noted below. No additional network call, BigQuery query,
paid extraction or deployment is part of this pipeline. Earlier outputs named
latest_* belong to the preceding content-review pass; use cache_triage_* for
this update. Earlier report sections and the notes below remain audit history.

NEXT EVIDENCE STEP
Verify the 160 new district-topic leads against full accessible articles and
public district documents, assigning exact NCES IDs and source-supported dates.
Resolve repeated-story provenance before calculating news-attention measures.
Seek alternate public sources for unresolved and inaccessible records. A source
failure is missing data, never a zero-ban observation. Independent human review
remains pending throughout. No national lead-lag or causal result is reported.

EARLIER PASSES / REPRODUCTION DETAILS
-----------------------------------
BANNED BOOKS: GDELT EXPANDED SCREEN, HISTORICAL ENROLLMENT AND LINK REVIEW
Updated October 2, 2026

START HERE
Open review/outputs/GDELT_District_Link_Review.html in a web browser.
This package extends the first review. It preserves the original annual GDELT
export, PEN workbook and derived event CSV, source decisions, and raw NCES files.
It is a validation package, not a completed causal or forecasting analysis.

LATEST PASS: ARTICLE CONTENT AND REPEATED COVERAGE
- Assessed 173 cached records: 29 representative stories, 122 exact-body copies,
  21 reviewed variants, and one unreadable partial-body case.
- Batch results: 156 supported district-topic records, 12 non-book-content
  records, two outside the public-school scope, and three unresolved cases.
  Two records had prior decisions. The net combined totals are 206 supported,
  741 not substantively reviewed, 93 unresolved, 12 non-book-content and two
  outside-school-scope records, totaling the original 1,054 candidate records.
- Supported coverage now identifies 35 distinct NCES districts. The batch has
  28 reviewed story families, of which 22 concern supported district topics.
  These families include related variants; they are not independent events.
- The 82 cached copies of one NPR Forsyth County story consist of a representative,
  80 exact-body matches, and one variant with sponsorship inserts. Raw URL counts
  must not be interpreted as independent reporting or additional restrictions.
- Body review resolves 86 primary-subject links absent from mechanical ID matches:
  82 Forsyth copies, two Maine RSU 40 stories and two Martin County stories.
- Current Conroe, Elmbrook, St. Lucie and Keller pages show evidence of updates
  or date mismatches. Their current contents cannot be backdated to GDELT capture.
- Enrollment joins cover 51 reviewed identities. Agency eligibility is pending.
- Of 741 unreviewed records, 359 have cached text and 382 do not. The URL audit
  preserves access outcomes. An encoding-pattern check flags 82 cached pages
  for access review; it is not a relevance decision and does not decode content.
- Review actor: AI assistant. Independent human coding remains pending. The old
  field human_review_status is a legacy label, not proof of human validation.
  latest_record_review.csv uses content_review_status instead.
- No additional BigQuery query, paid service, model or deployment ran.

EARLIER PASS: PUBLIC ACCESS AND SELECTED EPISODES
- All 925 previously unattempted URLs received a public-access check. Of these,
  542 returned HTML with enough text for possible review. This is not evidence
  that all 542 pages contain usable articles or support a district match.
- A further 13 articles were substantively reviewed: 12 support district-specific
  book-restriction coverage, and one concerns backpacks rather than book content.
- Across all passes, 51 supported article records represent 24 distinct verified
  NCES districts. The other 1,003 candidates are 912 not substantively reviewed,
  90 unresolved article-evidence cases, and one rejected non-book-content case.
  Supported records include challenges, policy changes, retention and follow-up
  reporting. They are not a count of ban events or independent news stories.
- The selected 20-row episode audit links 16 distinct PEN rows and preserves
  four unmatched cases. Conway's original October 11, 2022 board minutes are
  included. Decision dates do not establish first physical inaccessibility.
- All first-inaccessibility dates remain blank and model_eligible remains no.
  Reported stage dates, inferred dates and publication dates remain distinct.
- Enrollment joins now cover 41 reviewed identities. Positive enrollment does
  not establish eligibility for a national comparison panel.
- Exact full headlines form 749 groups, including 95 repeated groups. These are
  a review aid, not confirmed independent reporting units or deduplicated events.
- Madison County, Mississippi was missing from the mechanical aliases. The
  manually recovered link is recorded separately; wrong-state matches remain
  in the adjudication table as rejected, with the evidence basis preserved.
- No additional BigQuery job, paid service, website update or model was run.

EARLIER EXPANDED PASS (RETAINED)
- Broader aliases screened all 15,767 annual GDELT records.
- 2,065 candidate/entity pairs across 1,054 records; 940 records are new leads.
- Purposive review of 15 new records: six supported, nine access-unresolved.
  At that stage 925 new records were not yet attempted; the latest pass above
  supersedes that access status. No accuracy estimate is made.
- Six supported articles produce eight supported alias pairs (Keller and Conway
  each appear under both PEN and NCES names); these are only six articles.
  Fourteen incorrect name/geography pairs were rejected; 13 pairs remain
  access-unresolved. Do not count alias pairs as independent articles.
- Exact NCES enrollment joins for the original 33 districts plus four new
  article-geography districts. Adult education is excluded from denominators.
- A 19,714-agency inventory has enrollment joined where available, but agency
  type and study eligibility are still unreviewed. It is not the final population.
- No new title/PEN linkage or causal/timing model was estimated. The earlier
  22-row Alpine comparison remains unchanged. No extra BigQuery query ran.

PRIOR PASSES (RETAINED)
- The annual export audit: 15,767 keyword-matching GDELT records, not 15,767 bans.
- Access review of 114 literal district-name candidates: 33 supported district-
  topic links in 13 districts; 81 unresolved. The latter are not false positives.
- 33 candidate district names, seven-digit IDs and states verified against the
  official NCES EDGE 2022-2023 district-office file. Their IDs and states also
  appear in the official school-location file. Office points are not boundaries.
- Selected-title review: 109 article/title pairs in 26 articles; all 33 supported
  articles have a scope decision. There are 50 distinct PEN rows with matching
  title, author and district evidence. They are not 50 new or independent bans.
- A strict restriction-stage/month comparison includes 22 PEN rows from ONE
  Alpine article. All have the same PEN and publication month, November 2022.
  Earlier August reporting already describes temporary restriction. This does
  not establish that coverage preceded first restriction or identify a daily lag.
- Author conflict, edition uncertainty, absent dates and review/removal stage
  differences are preserved as explicit exceptions. No source values corrected.

RUN OFFLINE WITH PYTHON 3 (NO EXTRA PACKAGES)
From the unzipped Banned_Books_GDELT_Reviewed directory:
  python baseline_audit/audit_year.py
  python review/build_review.py
  python review/build_linkage.py
  python review/expand_candidates.py
  python review/build_expansion.py
  python review/build_continuation.py
  python review/build_content_review.py
Alternatively run: python run_all.py
Run in that order. The first script audits the original source export; the next
rebuilds the first-pass review; build_linkage applies historical and title checks.
The next two scripts generate broader candidates and enrollment checks.
build_continuation applies the URL audit and selected episode review;
build_content_review applies the latest content and repeated-story decisions. Reruns do not duplicate report sections. The judgments
in review/inputs/ are preserved evidence decisions, not automatic discoveries.
No network access, BigQuery job, billing account or credentials are needed.

LATEST CONTENT OUTPUTS (review/outputs/)
latest_record_review.csv          Current status for all 1,054 candidate records.
latest_supported_article_links.csv Supported district topics, including opinion.
remaining_content_review_queue.csv Unreviewed and unresolved cases with access flags.
content_batch_decisions.csv       173 decisions with review basis, genre and scope.
content_comparison_receipts.csv   Source/cache hashes and exact-body comparisons.
reviewed_story_families.csv       28 selected families, not independent event units.
cached_page_quality.csv          542 cache records; encoding flags are not verdicts.
latest_candidate_adjudication.csv Primary subjects and unresolved secondary leads.
content_recovered_primary_subjects.csv IDs recovered by body geography.
latest_enrollment_join.csv        51 reviewed identity/enrollment joins.
content_review_summary.json      Current counts, reconciliation and source checks.

EARLIER CONTINUATION OUTPUTS (review/outputs/)
combined_record_review.csv        All 1,054 records with separate human/access status.
combined_supported_article_links.csv 51 supported records, not ban counts.
public_access_audit.csv           All 925 public-access outcomes and response hashes.
continued_candidate_adjudication.csv Original 2,065 pairs with latest decisions.
manually_recovered_district_links.csv Correct Mississippi district absent from aliases.
headline_review_groups.csv        749 unverified full-headline groups.
headline_group_members.csv        All 1,054 record/group assignments.
continued_enrollment_join.csv     41 reviewed district identities and enrollment.
selected_episode_timing_audit.csv 20 selected title/stage audits, 16 distinct PEN rows.
continuation_summary.json         Latest counts, limits and source consistency checks.

EARLIER EXPANDED OUTPUTS (review/outputs/)
expanded_alias_candidates.csv     All mechanical candidate pairs, before review.
alias_dictionary.csv              Source names, generated aliases and rule.
candidate_entity_register.csv     19,834 keys; unresolved PEN aliases can repeat
                                  an official district, so not a district count.
expanded_candidate_adjudication.csv All pairs with explicit review status.
expanded_article_review.csv       15 attempts with URL, dates, stage and evidence.
expanded_pending_queue.csv        Unattempted or access-unresolved new leads.
historical_enrollment_join.csv    37 reviewed ID joins and enrollment flags.
district_frame_inventory.csv      Full office inventory; eligibility pending.
expansion_summary.json            Counts, limitations and 85 additional checks.

OPTIONAL RAW ENROLLMENT RE-EXTRACTION
Download the official ZIP from the URL in review/inputs/enrollment_source.json.
Place it at review/inputs/ccd_lea_052_2223_l_1a_083023.zip and run:
  python review/extract_enrollment.py
This is an optional 1.43 GB download, not needed for the offline package run.
The extractor retains the two total categories only, preserves all original
columns and status flags, and adds source_csv_record (header is record 1).
The original ZIP and member hashes are in enrollment_source.json.
The extraction deliberately excludes detailed race/sex/grade rows.
No BigQuery job, credentials or billing changes are part of this process.

KEY EARLIER OUTPUTS (review/outputs/)
GDELT_District_Link_Review.html     Updated readable review report.
review_summary.json               Overall candidate and historical-ID checks.
linkage_summary.json              Title decisions, counts and 12 linkage checks.
historical_nces_validation.csv     Exact ID, historical name/state and source row.
article_pen_link_review.csv        109 pairs, decisions, dates, status and sources.
linkage_exceptions.csv             Pairs excluded from strict stage comparison.
restriction_stage_concordance.csv  22 PEN rows; one article, one district, one month.
article_title_review_scope.csv     Coverage decision for all 33 supported articles.
candidate_review.csv              All 114 candidates, including unresolved pages.
confirmed_district_topic_links.csv Supported article geography/topic, not bans.
unresolved_article_links.csv      81 unresolved records, not deleted.
nces_identity_crosswalk.csv        Earlier identity leads plus historical results.
confirmed_reporting_families.csv   Four documented republication/derivative groups.
reviewed_coverage_by_month.csv     Positive-only coverage table; not a full panel.
first_pass_review.html/json        Historical snapshot before linkage (JSON name:
                                 first_pass_summary.json). Pending fields there
                                 describe that earlier stage, not current status.

LATEST CONTENT INPUTS
review/inputs/content_review_profiles.json: 29 reviewed representative decisions,
short extraction boundaries, genre, primary district and evidence limitations.
review/inputs/content_comparison_receipts.json: frozen comparisons of 173 cache
records with source response hashes, cache hashes and normalized body hashes.
review/inputs/content_variant_decisions.json: explicit judgments on 22 variants,
including the unreadable case; headline similarity alone never validates a copy.
review/inputs/cached_page_inventory.json: text hashes and quality flags for 542
retrieved pages. Full third-party text is not included.
review/freeze_content_evidence.py: OPTIONAL reconstruction of the comparison
receipts if the independently obtained retrieval_cache text files are available.
It normalizes whitespace only and applies exact matches; it does not decide
whether a representative is accurate, nor automatically accept changed bodies.
The offline run uses the frozen receipts. Rerunning the public collector later
may encounter revised pages and will not recreate the historical snapshots.
The read-and-code judgments require independent human review before inference.

EARLIER INPUTS AND OPTIONAL COLLECTOR
review/inputs/public_access_attempts.jsonl: frozen access ledger for 925 URLs.
review/inputs/continuation_article_decisions.json: 13 substantive review decisions.
review/inputs/continuation_episode_decisions.json: 20 title/episode decisions.
review/inputs/continuation_source_register.json: supplemental sources, failed
primary-document access attempts and the Conway PDF hash.
review/inputs/primary_sources/Conway_2022_10_11_minutes.pdf: original board minutes;
page 3 records the two title decisions. The decision is not a physical-removal date.
review/check_public_access.py is an OPTIONAL network collector, not part of
run_all.py. The included ledger lets it resume completed work without repeated
requests. It checks public robots rules and preserves blocked/error outcomes;
no credentials, challenge bypass or subscription access are used. Transient full
article text is omitted from the package. Human judgments are preserved inputs;
offline reproduction rebuilds the outputs but does not automate those judgments.

KEY EARLIER INPUTS
baseline_audit/inputs/gdelt_full_year_raw.csv: unchanged uploaded annual export.
baseline_audit/executed_query.sql: SQL used for the annual extraction.
baseline_audit/inputs/pen_events.csv: 3,362 rows from one PEN sorted view.
review/inputs/pen_2022_2023.xlsx: preserved original PEN workbook. The linkage
script checks every CSV title, author, state, district, date and status against
its original sheet cells and verifies that numeric date cells show month/year.
review/inputs/title_link_decisions.json: reviewed title pairs and exception rules.
review/inputs/article_title_review_scope.json: scope for all supported articles.
review/inputs/article_decisions.json: first-pass article evidence decisions.
review/inputs/url_review_attempts.json: access attempts for all 114 candidates.
review/inputs/nces_crosswalk.json: original identity leads (historical status in
this INPUT remains pending to preserve its original meaning; OUTPUT is updated).
review/inputs/historical_identity_decisions.json: reviewed historical name aliases.
review/inputs/historical_sources.json: download URLs, dates, licenses and SHA-256.
review/inputs/nces_district_office_locations_2223.csv: 19,714 official raw rows.
review/inputs/nces_public_school_locations_2223.csv: 102,268 official raw rows.
review/inputs/corroborating_evidence.json: separately consulted historical sources.
SHA256SUMS.txt: hashes of all packaged files except this checksum list itself.

LINKAGE CODEBOOK
candidate_index: stable zero-based index in the original candidate CSV.
link_review_id: stable row label for this reviewed ledger, L001...L109.
pen_row_id: source sheet plus original worksheet row number; NOT a global event ID.
article_title/author: normalized reviewed work labels, not verbatim quotations;
blank author means no independently transcribed author for that article.
expected_pen_title/author: immutable PEN values checked against preserved workbook.
title_author_district_supported: work and geography correspondence only.
title_district_supported_author_not_independently_verified: identity lead with
an author-check flag, even when another article corroborates the work.
title_family_supported_edition_unresolved: Bible family, not exact edition.
rejected_author_conflict: proposed pair explicitly rejected (Sarasota/Choke).
no_matching_pen_title_in_district: absent from this source version and district;
not a claim that the book was never restricted. Includes retained-book controls.
article_role: challenge, review, removal, retention, follow-up or litigation.
episode_assessment: whether the restriction stage/date can be reconciled.
pen_date_as_received: original Excel serial or text; never silently replaced.
pen_month: numeric date formatted as YYYY-MM, preserving MONTH-ONLY precision.
pen_date_precision: month-only, school-year-only, or season/other text.
arithmetic_month_offset_not_event_lag: publication month minus PEN month, only
where an eligible publication date and numeric PEN month exist. This is a raw
field comparison, not a causal lag, reporting delay, or first-restriction lag.
arithmetic_order_not_first_onset: earlier/later/same month under that arithmetic.
descriptive_stage_comparison_eligible: narrow month/stage audit only; NOT a model.
model_eligible: no for every row. There is no model-ready district-month panel.
verified_historical_nces_id: historical name/ID/state confirmed, including IDs for
unresolved article candidates; historical ID does not validate an article match.
reporting_family: documented source family, not a guarantee of independent news.

LIMITS AND NEXT WORK
The original literal-name screen is retained for comparison. The expanded screen
uses full names and mechanical aliases from NCES office and PEN records; it still
misses nonliteral references and does not search article bodies automatically.
The expanded review batch is purposive, not random or representative. It is not a
complete news-attention measure. Missing district-months are not zeros. Current
page dates may reflect revisions; immutable historical snapshots are not supplied.
Months in PEN remain months; spreadsheet serials are not precise onset dates.
Enrollment source flags remain intact: Derived, Missing, Not reported, Suppressed.
A positive derived enrollment total does not establish agency eligibility.
The inventory includes agencies beyond ordinary operating school districts;
agency type, operational status, boundaries and comparison coverage need review.
Historical ID checks and enrollment joins are separately documented; the earlier
historical_nces_validation.csv describes its identity-only pass, while the new
historical_enrollment_join.csv records its enrollment pass and
continued_enrollment_join.csv records the latest enrollment validation.
Review remaining aliases and inaccessible pages; obtain primary restriction
records; reconcile title, stage and dates; define the eligible population and
coverage rules; independently review judgments before fitting a model.
The research website and main final report were not updated by this audit.

CONTENT REVIEW CODEBOOK
content_review_status: current record-level decision; supported means published
district-topic content exists, not that the reported allegation is proven.
review_basis: direct_representative_review, exact_body_equivalence,
reviewed_story_variant, unresolved_partial_body or earlier_review_pass.
story_family_id: selected source family, with related CNN versions grouped;
blank means no family assignment in this pass, not independent reporting.
primary_subject_nces_id: reviewed main district; other article references are
not automatically treated as wrong or included as additional restriction sites.
page_date: transcribed current displayed date for representatives only; it can
be an update, is not propagated to copies, and is never a restriction onset.
historical_body_availability: unverified for all records. No immutable archive
was supplied to show which body version existed at the first GDELT timestamp.
independent_human_review: pending. model_eligible: no for every record.
