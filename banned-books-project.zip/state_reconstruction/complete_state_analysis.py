"""Reconstruct descriptive state comparisons from retained primary source files.
No new forecast, causal model or respondent-level inference is fitted.
"""
from pathlib import Path
import io,json,csv,re,hashlib
import pandas as pd
from scipy.stats import pearsonr,spearmanr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
S=ROOT/'sources';O=ROOT/'outputs';O.mkdir(exist_ok=True)
b=pd.read_csv(S/'state_counts_2022_2023.csv');states=set(b.state)
p=pd.read_csv(S/'population_2022.csv',encoding='utf-8-sig');p=p[p.NAME.isin(states)][['NAME','STATE','POPESTIMATE2022']].rename(columns={'NAME':'state','STATE':'state_fips','POPESTIMATE2022':'population_2022'})
g=pd.read_html(io.StringIO((S/'gallup_2017.html').read_text()))[0].iloc[:,:6]
g.columns=['state','dem_2017_pct','rep_2017_pct','dem_advantage_2017_pp','gallup_n','gallup_classification']
g=g[g.state.isin(states)].copy()
for c in ['dem_2017_pct','rep_2017_pct','dem_advantage_2017_pp','gallup_n']:g[c]=pd.to_numeric(g[c])
g['party_larger_share_2017']=g.apply(lambda r:'Democrat' if r.dem_2017_pct>r.rep_2017_pct else 'Republican' if r.rep_2017_pct>r.dem_2017_pct else 'Tied',axis=1)
# The PDF text is produced by pdftotext -layout; only the four state tables are read.
text=(S/'pew_2014.txt').read_text();section=text[text.index('Religious Affiliation by State in the Northeast'):text.index('Religious Affiliation by Metro Area')]
cols=['evangelical_2014_pct','mainline_2014_pct','historically_black_protestant_2014_pct','catholic_2014_pct','mormon_2014_pct','orthodox_2014_pct','jehovahs_witness_2014_pct','other_christian_2014_pct','jewish_2014_pct','muslim_2014_pct','buddhist_2014_pct','hindu_2014_pct','other_world_2014_pct','other_faiths_2014_pct','unaffiliated_2014_pct','unknown_2014_pct','total_pct','religion_n']
rows=[]
for line in section.splitlines():
 m=re.match(r'^\s+([A-Za-z ]+?)\s+2014\s+(.+)$',line)
 if not m:continue
 state=m.group(1).strip();state={'Delware':'Delaware'}.get(state,state)
 if state not in states:continue
 vals=m.group(2).split();assert len(vals)==18,(state,vals)
 d={'state':state}
 for col,v in zip(cols,vals):d[col]=None if v=='*' else int(v.replace(',',''))
 d['source_tokens']=' '.join(vals)
 # Preserve ties in rounded percentages, unlike idxmax's first-column selection.
 categories={k:v for k,v in d.items() if k in cols[:16] and v is not None}
 maximum=max(categories.values());d['largest_categories_2014']='; '.join(k.replace('_2014_pct','') for k,v in categories.items() if v==maximum)
 rows.append(d)
r=pd.DataFrame(rows)
for name,df in [('population',p),('gallup',g),('religion',r)]:
 assert len(df)==50 and df.state.nunique()==50 and set(df.state)==states,name
 df.to_csv(O/(name+'_reconstructed.csv'),index=False)
x=b.merge(p,on='state',validate='one_to_one').merge(g,on='state',validate='one_to_one').merge(r,on='state',validate='one_to_one')
x['bans_per_million_residents']=x.event_rows/x.population_2022*1e6
x['rep_minus_dem_2017_pp']=x.rep_2017_pct-x.dem_2017_pct
assert len(x)==50 and x.event_rows.sum()==3362 and (x.population_2022>0).all()
x.to_csv(O/'state_analysis_2022_2023.csv',index=False)
metrics=[]
for scope,df in [('All 50 states',x),('33 states with index entries',x[x.event_rows>0]),('Exclude Florida and Texas',x[~x.state.isin(['Florida','Texas'])])]:
 for predictor in ['rep_minus_dem_2017_pp','evangelical_2014_pct']:
  for outcome in ['event_rows','bans_per_million_residents']:
   metrics.append({'scope':scope,'n':len(df),'predictor':predictor,'outcome':outcome,'pearson_r':pearsonr(df[predictor],df[outcome]).statistic,'spearman_rho':spearmanr(df[predictor],df[outcome]).statistic})
pd.DataFrame(metrics).to_csv(O/'descriptive_correlations.csv',index=False)
x.sort_values('bans_per_million_residents',ascending=False).head(10)[['state','event_rows','population_2022','bans_per_million_residents']].to_csv(O/'top_ten_rates.csv',index=False)
# Historical five-state arithmetic, using the first report counts, not a verified 2021-22 ranking.
hist=pd.read_csv(S/'historical_affiliations.csv').merge(p,on='state',validate='one_to_one').merge(g,on='state',validate='one_to_one').merge(r,on='state',validate='one_to_one')
hist['historical_instances_per_million']=hist.historical_ban_count/hist.population_2022*1e6
hist.to_csv(O/'historical_five_state_reconciliation.csv',index=False)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11})
fig,axs=plt.subplots(1,2,figsize=(11.5,5.2))
for ax,col,title in [(axs[0],'event_rows','Recorded entries'),(axs[1],'bans_per_million_residents','Entries per million residents')]:
 q=x.nlargest(8,col).sort_values(col);ax.barh(q.state,q[col],color='#315971');ax.set_title(title,loc='left',fontsize=14);ax.spines[['top','right']].set_visible(False);ax.grid(axis='x',alpha=.2);ax.set_axisbelow(True)
fig.suptitle('2022–2023 state rankings depend on the denominator',fontsize=16,x=.02,ha='left')
fig.text(.02,.01,'PEN retained index; Census July 2022 total residents. Descriptive rates, not student exposure or individual risk.',fontsize=9)
fig.tight_layout(rect=(0,.05,1,.94));fig.savefig(O/'counts_and_rates.png',dpi=180);plt.close(fig)
urls={'population_2022.csv':'https://www2.census.gov/programs-surveys/popest/datasets/2020-2022/state/totals/NST-EST2022-POPCHG2020_2022.csv','gallup_2017.html':'https://news.gallup.com/poll/226643/2017-party-affiliation-state.aspx','pew_2014.txt':'https://www.pewresearch.org/wp-content/uploads/sites/7/2015/05/RLS-08-26-full-report.pdf'}
register=[{'filename':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'source_url':urls.get(f.name,'Retained project input or extracted PDF text'),'acquisition_date':'2026-10-01 (Asia/Makassar)'} for f in sorted(S.iterdir()) if f.is_file()]
(O/'source_register.json').write_text(json.dumps(register,indent=2))
(O/'validation.json').write_text(json.dumps({'state_rows':len(x),'event_sum':int(x.event_rows.sum()),'unique_state_keys':int(x.state.nunique()),'all_three_source_joins':'50 of 50 states, no unmatched states','florida_religion_tie':r[r.state=='Florida'].largest_categories_2014.iloc[0],'religion_asterisk_rule':'Retained as missing numeric with original token; not converted to zero','typo_correction':'Pew printed Delware explicitly mapped to Delaware','model_status':'Descriptive correlations only; no causal model or forecast'},indent=2))
print(pd.DataFrame(metrics).to_string(index=False));print(x.nlargest(5,'bans_per_million_residents')[['state','event_rows','bans_per_million_residents']].to_string(index=False))
