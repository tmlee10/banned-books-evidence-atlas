# Banned Books Evidence Atlas

Reproducible descriptive analysis and static findings website. School years 2021–2022 through 2024–2025; built September 25, 2026 from the revised project package of September 3, 2026. This is a fixed study window, not a claim to include all available records through September 2026.

## Run

Python 3.10 or newer. No third-party packages required for the completed descriptive analysis.

```
python3 analysis/analyze.py
python3 -m unittest discover -s tests -v
python3 analysis/package.py
```

Serve the `dist` directory with any static web host. It contains no trackers, remote script dependencies, external fonts or API keys. The site source is versioned in its Sites repository. `dist/data/findings.json` contains full-precision computed metrics, while display values are rounded. Checksums for the inputs are in `dist/data/source_register.json`.

## What has been completed

- Recalculation of annual changes, the four-year sum, geographic shares and public-response share.
- Reconciliation of geographic categories with the 6,870 current total.
- Generated annual chart and state map from the retained geographic boundaries. Continental projection: Albers equal-area, standard parallels 29.5/45.5, central meridian -96. Alaska and Hawaii use separate display insets; their scale is not comparable to the main map.
- Browser-ready findings and downloadable data, source package and original QGIS/report/presentation archive.
- An executable event validation and panel-preparation pipeline for future official row-level inputs.

## What is not a completed result

No district-month model, spatial clustering statistic, enrollment-adjusted national comparison, causal estimate, forecasting result or social-media analysis has been fitted. The recovered package has summary totals, not an official row-level 2024–2025 export or a full NCES/coverage frame. A public index page was accessible on September 25, 2026; a reproducible export was not obtained in this build. A direct download request returned HTTP 403. No access controls were bypassed.

The earlier regression and 0.46 correlation are not carried forward as new findings. County/district covariates, verified organizational activity, policy histories and GDELT counts have not been fabricated. Fit the proposed models only after acquiring and validating those inputs. The `model_ready` flag is a data-readiness gate, not an endorsement of a causal design or model specification.

## Sources and interpretation

- PEN America: https://pen.org/report/the-normalization-of-book-banning/
- Index definitions: https://pen.org/book-bans/pen-america-index-of-school-book-bans-2024-2025/
- Input CSVs and boundaries were recovered unchanged from the user's approved `Banned_Books_V2_Complete_Package_2026-09-03.zip`. SHA-256 checksums preserve the specific input versions. Original acquisition date and detailed boundary provenance were not recorded in those CSVs. No new license is asserted for source data.
- Annual counts measure newly recorded restrictions, not all books still unavailable.
- Florida, Texas and Tennessee have individual summary values. The 573 remainder is not distributed across other states. DoDEA's 590 is a school-system total, not a state total. Neutral map fill means an individual state count is not in this extract.
- State-mandated lists are kept separate: a statewide prohibition does not establish that every district previously held every title.
- The 70/87 public-response share is a descriptive ratio; it does not measure successful reversals.
- The source's 2,520 policy-pressure title-level cases have their own denominator. The site does not treat them as 36.7% of an interchangeable district-level universe.
- PEN and ALA measures are not pooled. Reporting coverage limits all counts.

## Future event inputs

```
python3 analysis/prepare_events.py --events events.csv --coverage coverage.csv --output results
```

`events.csv`: event_id, scope (`district` or `state`), nces_id (7-digit string), nces_match_status (`verified` only after manual or documented exact verification), school_year (`2024-2025`), month (`2024-09`, blank if unresolved), date_precision (`day`, `month`, `year`, or `unknown`), title_id, source_url. One row means one restriction episode for a title in a district. Additional source columns can be retained. State-level entries are written separately for review; they are not asserted to have passed district validation.

`coverage.csv`: nces_id, month, enrollment (positive integer), coverage (`covered` or `unknown`), coverage_source. Include the full intended district/month frame, not just places reporting events. `covered` requires evidence for the reporting procedure and period. It never implies comprehensive detection of every real-world ban.

Missing or inconsistent dates are not guessed. Unresolved events are reported; affected months or whole school years are blocked from becoming misleading zeros. Exact IDs and probable title/district/month duplicates trigger review before collapsing. Unknown coverage stays null. Unresolved NCES events make the overall readiness gate fail, even if a particular panel cell otherwise passes. Negative/invalid enrollment prevents rates. Forecasting, if later implemented, must use source publication timestamps no later than its prediction cutoff.

## Research question retained

RQ3. What happened when a district reviewed a challenged book with input from librarians and local residents?

The approved NCES, date, duplicate, reconciliation, coverage and forecast-timing checks remain part of the analysis plan. A full model specification and geographic crosswalk validation must be reviewed before inferential work. The synthetic fixtures in `tests/` exercise edge cases; none are research observations.

## Original project files

The website's original-project download preserves the revised report, proposal, analysis plan, PowerPoint, geographic exports and QGIS project. The website map is regenerated from the same boundary file; it is not claimed to be a new QGIS application export. The QGIS desktop application was not run during this build. The original documents are retained as prior deliverables, not silently relabeled as a new row-level analysis.

