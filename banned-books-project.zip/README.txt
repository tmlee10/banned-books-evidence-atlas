BANNED BOOKS WEBSITE UPDATE — 1 OCTOBER 2026

Prepared for tmlee10/banned-books-evidence-atlas.
This package contains only banned-books files. It has NOT been published.
The active GitHub connector could access the older danangnu repository but returned
404 for the tmlee10 repository. The earlier onrender.com URL also returned 404.
Confirm the target repository and current Render service before deploying.

MERGE
Copy the contents into the repository root, preserving any newer files not included
here. Review diffs against the current tmlee10 branch before committing. Do not
replace the older danangnu repository or include its separate redlining project.
The Render static site should publish dist; the included build check validates
local links, source totals and every downloadable archive.

LOCAL PREVIEW
python -m http.server 8765 --directory dist
Open http://localhost:8765/
Run python scripts/check_website.py before publishing.

CHANGES
- New 2022–2023 population-rate map, separate from the 2024–2025 summary map.
- Searchable, sortable 50-state table using 2022 Census, Gallup 2017 and Pew 2014.
- Count/rate chart, descriptive correlation table and sensitivity CSV download.
- Counting-rule note: retained-entry total 3362; nonblank-title count 3361.
- Current revised report and full analysis ZIP; old slides/QGIS explicitly dated.
- Existing Ohio historical-output review retained; no new forecast claimed.

REPRODUCE THE RESEARCH
python run_review.py
cd state_reconstruction
python -m pip install -r requirements.txt
python complete_state_analysis.py
The site contains prebuilt outputs; Render does not fit research models.
The report and bundle were completed before this website update. Their statement
that the report revision did not deploy a website is historical and remains true.

DATA STILL NEEDED
Original chapter-model training records, individual survey records/codebook,
district identifiers and enrollment, restriction/outcome dates, and detailed
2024–2025 events. Those results have not been manufactured or marked complete.
