# Banned Books Evidence Atlas — Render deployment

This folder contains the complete prebuilt website, source data, Python analysis,
tests and both downloads linked from the website. The original-project download
includes the report, PowerPoint and QGIS files. No database, API key, package
installation or running Python server is needed to host these pages.

## 1. Put the contents in GitHub

Create a dedicated repository such as `banned-books-evidence-atlas`. A private
repository can be connected to Render after you grant Render access.

Upload the CONTENTS of this folder to the repository root. The root should contain:

- `render.yaml`
- `README.md` and `RESEARCH_README.md`
- `scripts/`
- `dist/` (including both ZIP files in `dist/downloads/`)
- `analysis/`, `data/`, and `tests/`

Do not upload only this outer ZIP file. Do not place everything inside a second
wrapper folder. Do not copy `.git` or ChatGPT hosting settings from another checkout.

## 2. Deploy on Render

Recommended dashboard route:

1. Open https://dashboard.render.com/.
2. Choose **New > Static Site**.
3. Connect the new GitHub repository.
4. Use the settings below and create the static site.

| Setting | Value |
| --- | --- |
| Name | `banned-books-evidence-atlas` (or an available name) |
| Branch | Your repository's default branch, normally `main` |
| Root Directory | Leave blank |
| Build Command | `bash scripts/check-static.sh` |
| Publish Directory | `dist` |
| Environment variables | None required |

The build command checks the prebuilt files and both downloadable archives. It
does not rerun the research analysis. Render serves the HTML/CSS/SVG files directly.
No start command is needed.

Alternative: **New > Blueprint**, connect the repository, and review `render.yaml`.
It defines one static site and no paid compute services or databases. Choose ONE
deployment route, not both. Render workspace usage limits still apply.

The resulting Render website is public. Its public downloads include the original
research files. GitHub source visibility is a separate setting from website access.
This export does not change the existing private ChatGPT-hosted website.

## 3. Check the deployed website

- Open the assigned `onrender.com` URL in a signed-out browser window.
- Confirm the state map and annual chart are visible.
- Expand both data tables.
- Download both ZIP links and the source register.
- Check the page on a phone-sized screen.
- Share the actual URL shown in Render after deployment succeeds.

No Render deployment has been performed by preparing this package. The name is
suggested, and availability of the corresponding subdomain is not guaranteed.

## 4. Optional custom domain

After the site is deployed, use **Settings > Custom Domains**, add a domain you
control, and apply the DNS records Render displays. Domain purchase is separate.
Do not guess DNS values; use those issued for the deployed service.

## Rebuild the research outputs locally

Python 3.10+ with its standard library is sufficient:

```
python3 analysis/analyze.py
python3 -m unittest discover -s tests -v
python3 analysis/package.py
```

Commit regenerated files under `dist/` before redeploying. The numerical text in
`dist/index.html` is a fixed study snapshot; if data inputs change, reconcile and
update that text as well. Do not imply that a new dataset automatically updates
the prose. This package preserves the current study window ending June 2025.

See `RESEARCH_README.md` for methods, limitations and the future row-level schema.
District-level model fitting is still pending the required official inputs.

## Official hosting references

- https://render.com/docs/static-sites
- https://render.com/docs/blueprint-spec
- https://render.com/docs/custom-domains



## September 29, 2026 website update
Added an earlier-study evidence inventory and the Ohio historical forecast. The historical CSV is a transcription of all 50 printed predictions in Banned Books.docx, not a model rerun. It preserves negative predictions for audit. The original model inputs and survey responses are unavailable. State-level affiliation measures must not be interpreted as individual respondent profiles. The earlier report uses 2,535 rows; the published annual series uses 2,532 instances; reconciliation is unresolved. Direct report, presentation and QGIS downloads are unchanged September 3 versions. The full V2 archive remains unchanged.


## Historical forecast visuals
Added all-state map and chart, Ohio comparison and an accessible state selector/table. Reproduce with `python analysis/forecast_visuals.py` (matplotlib required), then `python analysis/package.py`. The public 2022–2023 PEN workbook is retained in data/pen_2022_2023.xlsx. Aggregation checks both sheets independently, reconciles 3,362 events across 33 states and verifies the five published leading-state counts. Ohio has zero entries in this index, not verified zero bans. Eighteen historical predictions are negative and are marked invalid rather than clamped. No new model has been fitted. Official 2024–2025 row-level data and original survey inputs remain pending.
