import copy
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'analysis'))
from analyze import summarize, read_csv, ROOT
from prepare_events import prepare

class SummaryTests(unittest.TestCase):
    def test_reconciliation_and_rates(self):
        d=summarize(read_csv(ROOT/'data/annual_series.csv'),read_csv(ROOT/'data/published_counts.csv'))
        self.assertEqual(d['total_four_years'],22810)
        self.assertEqual(d['top_three_total'],5707)
        self.assertAlmostEqual(d['top_three_share'],83.07132459970888)
        self.assertEqual(round(d['latest_change'],1),-31.6)
    def test_reject_mismatched_geography(self):
        groups=read_csv(ROOT/'data/published_counts.csv');groups[0]['instances']='2305'
        with self.assertRaises(ValueError):summarize(read_csv(ROOT/'data/annual_series.csv'),groups)

class PanelTests(unittest.TestCase):
    def setUp(self):
        self.event={'event_id':'synthetic-1','scope':'district','nces_id':'0000001','nces_match_status':'verified','school_year':'2024-2025','month':'2024-09','date_precision':'month','title_id':'TEST-TITLE','source_url':'https://example.invalid/fixture'}
        self.frame=[{'nces_id':'0000001','month':m,'enrollment':'1000','coverage':c,'coverage_source':'synthetic fixture'} for m,c in [('2024-09','covered'),('2024-10','covered'),('2024-11','unknown')]]
    def test_covered_zero_and_unknown_are_different(self):
        r=prepare([self.event],self.frame)
        self.assertEqual([x['ban_instances'] for x in r['panel']],[1,0,None])
        self.assertEqual(r['panel'][0]['instances_per_10000'],10)
    def test_possible_duplicate_blocks_month(self):
        second={**self.event,'event_id':'synthetic-2'}
        r=prepare([self.event,second],self.frame)
        self.assertIsNone(r['panel'][0]['ban_instances']);self.assertFalse(r['model_ready'])
    def test_unknown_month_blocks_year(self):
        e={**self.event,'month':'','date_precision':'year'}
        r=prepare([e],self.frame)
        self.assertTrue(all(x['ban_instances'] is None for x in r['panel']))
    def test_state_mandate_is_separate(self):
        r=prepare([{**self.event,'scope':'state'}],self.frame)
        self.assertEqual(len(r['state_mandated']),1)
        self.assertEqual(r['panel'][0]['ban_instances'],0)
    def test_invalid_identity_prevents_readiness(self):
        r=prepare([{**self.event,'nces_match_status':'unresolved'}],self.frame[:1])
        self.assertFalse(r['model_ready'])
    def test_frame_omission_fails(self):
        with self.assertRaises(ValueError):prepare([self.event],self.frame[1:])
    def test_school_year_mismatch_blocks_count(self):
        r=prepare([{**self.event,'school_year':'2023-2024'}],self.frame)
        self.assertIsNone(r['panel'][0]['ban_instances'])

if __name__=='__main__':unittest.main()
