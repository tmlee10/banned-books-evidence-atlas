import sys
import unittest
from unittest.mock import patch
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'analysis'))
from reconcile import ROOT, reconcile_workbook

class ReconciliationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.events, cls.counts, cls.nonblank, cls.sheets = reconcile_workbook(ROOT/'data/pen_2022_2023.xlsx')

    def test_preserves_blank_title_record(self):
        self.assertEqual(len(self.events), 3362)
        self.assertEqual(sum(self.nonblank.values()), 3361)
        self.assertEqual(self.counts['Texas'], 625)
        self.assertEqual(self.nonblank['Texas'], 624)

    def test_sheet_views_are_not_combined(self):
        self.assertEqual([len(v) for v in self.sheets.values()], [3362, 3362])
        self.assertEqual(sum(self.counts.values()), 3362)

    def test_header_differences_preserve_first_event(self):
        first = self.sheets['Sorted by State & District'][0]
        self.assertEqual(first['source_row'], 1)
        self.assertEqual(first['title'], '#Hockey')
        self.assertEqual(first['state'], 'Texas')

    def test_blank_locations_are_auditable(self):
        blanks = [(r['sheet'], r['source_row']) for rows in self.sheets.values() for r in rows if not r['title'].strip()]
        self.assertEqual(set(blanks), {('Sorted by State & District', 3363), ('Sorted by Author & Title', 602)})

    def test_ohio_is_no_index_entries_not_proof_of_absence(self):
        self.assertEqual(self.counts['Ohio'], 0)
        self.assertEqual(len(self.counts), 33)

    def test_same_counts_different_records_fail(self):
        altered = {s: [dict(r) for r in rows] for s, rows in self.sheets.items()}
        altered['Sorted by Author & Title'][0]['title'] = 'TEST ALTERATION'
        with patch('reconcile.read_workbook', return_value=altered):
            with self.assertRaises(ValueError):
                reconcile_workbook(Path('unused'))

    def test_duplicate_record_is_retained_not_collapsed(self):
        altered = {s: [dict(r) for r in rows] for s, rows in self.sheets.items()}
        sample = dict(self.events[0])
        for rows in altered.values():
            rows.append(dict(sample))
        with patch('reconcile.read_workbook', return_value=altered):
            events, counts, nonblank, sheets = reconcile_workbook(Path('unused'))
        self.assertEqual(len(events), 3363)

if __name__ == '__main__':
    unittest.main()
