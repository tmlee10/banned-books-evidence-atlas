#!/usr/bin/env bash
set -euo pipefail
# The reproducibility download is stored alongside the project archive to keep
# each GitHub web upload below its per-file limit.
if [ -f banned-books-revised-data-code.zip ]; then
  cp banned-books-revised-data-code.zip dist/downloads/banned-books-revised-data-code.zip
fi
cp banned-books-gdelt-reviewed.zip dist/downloads/banned-books-gdelt-reviewed.zip
python3 scripts/check_website.py
python3 scripts/check_gdelt.py
