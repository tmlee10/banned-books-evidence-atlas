#!/usr/bin/env bash
set -euo pipefail
for file in \
  dist/index.html \
  dist/styles.css \
  dist/favicon.svg \
  dist/map.svg \
  dist/trend.svg \
  dist/data/findings.json \
  dist/data/annual_series.csv \
  dist/data/published_counts.csv \
  dist/data/source_register.json \
  dist/downloads/banned-books-code-and-data.zip \
  dist/downloads/banned-books-original-project.zip
do
  if [ ! -s "$file" ]; then
    printf 'Missing or empty required file: %s\n' "$file" >&2
    exit 1
  fi
done
printf 'All required website assets and downloads are present.\n'

