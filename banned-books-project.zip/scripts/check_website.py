from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import csv,json,zipfile,hashlib
R=Path(__file__).resolve().parents[1];D=R/'dist'
class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.ids=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'id' in a:self.ids.append(a['id'])
  for k in ['href','src']:
   if k in a:self.links.append(a[k])
p=Links();txt=(D/'index.html').read_text();p.feed(txt)
assert len(p.ids)==len(set(p.ids)), 'Duplicate page IDs'
for u in p.links:
 q=urlsplit(u)
 if q.scheme or q.netloc:continue
 if q.path:assert (D/unquote(q.path)).is_file(),u
 if q.fragment and not q.path:assert q.fragment in p.ids,u
assert 'Barbara' not in txt
r=list(csv.DictReader((D/'data/state_analysis_2022_2023.csv').open()));assert len(r)==50 and len({x['state'] for x in r})==50
assert sum(int(x['event_rows']) for x in r)==3362
assert next(x for x in r if x['state']=='Texas')['event_rows']=='625'
assert max(r,key=lambda x:float(x['bans_per_million_residents']))['state']=='Utah'
assert max(r,key=lambda x:int(x['event_rows']))['state']=='Florida'
assert 'evangelical; unaffiliated'==next(x for x in r if x['state']=='Florida')['largest_categories_2014']
for x in json.loads((D/'data/download_manifest.json').read_text()):
 f=D/'downloads'/x['filename'];assert hashlib.sha256(f.read_bytes()).hexdigest()==x['sha256'],f.name
 if f.suffix in ['.zip','.docx','.pptx']:
  with zipfile.ZipFile(f) as z:assert z.testzip() is None,f.name
print(f'PASS: {len(p.links)} page links/assets, 50-state data, key totals and every downloadable file.')
