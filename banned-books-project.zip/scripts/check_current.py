from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit, unquote
import csv
R = Path(__file__).resolve().parents[1]; D = R / 'dist'
class Links(HTMLParser):
    def __init__(self): super().__init__(); self.links = []; self.ids = []
    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if 'id' in a: self.ids.append(a['id'])
        for k in ['href', 'src']:
            if k in a: self.links.append(a[k])
txt = (D / 'current-2025-2026.html').read_text(); p = Links(); p.feed(txt)
assert len(p.ids) == len(set(p.ids)), 'Duplicate page IDs'
for u in p.links:
    q = urlsplit(u)
    if q.scheme or q.netloc: continue
    if q.path: assert (D / unquote(q.path)).is_file(), u
    if q.fragment and not q.path: assert q.fragment in p.ids, u
assert 'Barbara' not in txt
assert 'current-2025-2026.html' in (D / 'index.html').read_text()
r = list(csv.DictReader((D / 'data/state_analysis_2025_2026.csv').open()))
assert len(r) == 50 and len({x['state'] for x in r}) == 50
assert sum(int(x['instances']) for x in r) == 11982
assert sum(1 for x in r if int(x['instances']) > 0) == 23
c = {x['state']: int(x['instances']) for x in r}
assert c['Texas'] == 8193 and c['Florida'] == 3212
assert max(r, key=lambda x: float(x['instances_per_million']))['state'] == 'Texas'
assert txt.count('data-state=') == 50
print(f'PASS: 2025-26 page, {len(p.links)} links/assets, 50-state data and key totals.')
