from pathlib import Path
from collections import Counter
from html.parser import HTMLParser
from urllib.parse import urlsplit, unquote
import csv,json
D=Path(__file__).resolve().parents[1]/'dist'
rows=list(csv.DictReader((D/'data/gdelt/sample_review_v11.csv').open()))
assert len(rows)==len({r['record_id'] for r in rows})==36
assert all(n==3 for n in Counter(r['sample_month'] for r in rows).values())
assert len(Counter(r['sample_month'] for r in rows))==12
assert Counter(r['verdict'] for r in rows)=={'supported_school_topic':12,'outside_school_scope':2,'noncontent_match':2,'unresolved':20}
assert sum(r['candidate_result']=='at_least_one_supported_candidate' for r in rows)==8
assert all(r['model_eligible']=='no' and r['accepted_event_link']=='no' for r in rows)
class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[]
 def handle_starttag(self,tag,attrs):
  for k,v in attrs:
   if k in ('href','src'):self.links.append(v)
p=Links();t=(D/'gdelt-validation.html').read_text();p.feed(t)
for u in p.links:
 q=urlsplit(u)
 if not q.scheme and not q.netloc and q.path:assert (D/unquote(q.path)).is_file(),u
rq='What happened when a district reviewed a challenged book with input from librarians and local residents?'
assert rq in t and rq in (D/'index.html').read_text()
assert 'website has not been updated' not in t.lower()
print('PASS: 36 sample records, 12 months, frozen verdicts, event limits, exact RQ3 and validation-page links.')
