from pathlib import Path
from collections import Counter
from html.parser import HTMLParser
from urllib.parse import urlsplit, unquote
import csv,json
D=Path(__file__).resolve().parents[1]/'dist'
rows=list(csv.DictReader((D/'data/gdelt/sample_review_v13.csv').open()))
assert len(rows)==len({r['record_id'] for r in rows})==36
assert all(n==3 for n in Counter(r['sample_month'] for r in rows).values())
assert len(Counter(r['sample_month'] for r in rows))==12
assert Counter(r['verdict'] for r in rows)=={'supported_school_topic':13,'outside_school_scope':2,'noncontent_match':2,'unresolved':19}
assert sum(r['candidate_result']=='at_least_one_supported_candidate' for r in rows)==9
assert all(r['model_eligible']=='no' and r['accepted_event_link']=='no' for r in rows)
class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[]
 def handle_starttag(self,tag,attrs):
  for k,v in attrs:
   if k in ('href','src'):self.links.append(v)
p=Links();t=(D/'gdelt-validation.html').read_text();p.feed(t)
for u in p.links:
 q=urlsplit(u)
 if not q.scheme and not q.netloc and q.path:assert (D/unquote(q.path)).is_file(),u
rq='What happened when a district reviewed a challenged book with input from librarians and local residents?'
assert rq in t and rq in (D/'index.html').read_text()
assert 'website has not been updated' not in t.lower()
print('PASS: 36 sample records, 12 months, frozen verdicts, event limits, exact RQ3 and validation-page links.')

outcomes=list(csv.DictReader((D/'data/gdelt/sample_outcome_followup_v12.csv').open()))
assert len(outcomes)==1 and outcomes[0]['decision_date']=='2023-06-20'
assert outcomes[0]['restriction_onset']==outcomes[0]['actual_reshelving_date']==outcomes[0]['duration_days']==''
assert '7–0 vote' in t and 'Nineteen selected records remain unresolved' in t
print('PASS: Davis board decision date kept separate from onset, implementation and duration.')

audit=list(csv.DictReader((D/'data/gdelt/pen_date_cell_audit_v13.csv').open()))
assert len(audit)==3362
corrections=list(csv.DictReader((D/'data/gdelt/date_corrections_v13.csv').open()))
assert [r['verified_pen_month'] for r in corrections]==['2023-03','2023-03','2023-05','2023-04']
assert all(r['accepted_exact_onset']=='no' and r['duration_days']=='' for r in corrections)
summary=json.loads((D/'data/gdelt/sample_summary_v13.json').read_text())
assert summary['human_review_responses_received']==0 and summary['report_month_errors_corrected']==3
assert (D/'gdelt-independent-review.html').is_file()
assert 'February 2023' not in t and 'PEN lists the Bible in April' not in t
print('PASS: full workbook audit, three month corrections, no fabricated onset, independent review pending.')
