"""Rebuild published-summary calculations and web figures. Python 3.10+, stdlib only."""
import csv
import hashlib
import html
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = 'https://pen.org/report/the-normalization-of-book-banning/'
COLORS = {'Florida': '#c85535', 'Texas': '#22786d', 'Tennessee': '#ba862d'}

def read_csv(path):
    with open(path, encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def summarize(annual, groups):
    years = [r['school_year'] for r in annual]
    if len(set(years)) != len(years) or years != sorted(years):
        raise ValueError('Annual records must have distinct, ordered school years.')
    counts = [int(r['instances']) for r in annual]
    if any(n < 0 for n in counts):
        raise ValueError('Negative counts are invalid.')
    latest = counts[-1]
    if latest <= 0:
        raise ValueError('Latest total must be positive for share calculations.')
    if len({r['geography_code'] for r in groups}) != len(groups):
        raise ValueError('Duplicate geography code.')
    if any(int(r['instances']) < 0 for r in groups):
        raise ValueError('Negative geographic count.')
    if sum(int(r['instances']) for r in groups) != latest:
        raise ValueError('Geographic categories do not reconcile to annual total.')
    for i, r in enumerate(annual):
        r['instances'] = counts[i]
        r['yoy_change_pct'] = None if i == 0 else 100 * (counts[i] / counts[i-1] - 1)
    for r in groups:
        r['instances'] = int(r['instances'])
        r['share_all_pct'] = 100 * r['instances'] / latest
    focus = sum(r['instances'] for r in groups if r['geography_code'] in ['FL','TX','TN'])
    return {'annual': annual, 'geography': groups, 'total_four_years': sum(counts),
            'latest_total': latest, 'latest_change': annual[-1]['yoy_change_pct'],
            'change_from_2021': 100 * (latest / counts[0] - 1),
            'top_three_total': focus, 'top_three_share': 100 * focus / latest,
            'public_response_districts': 70, 'affected_districts': 87,
            'public_response_pct': 100 * 70 / 87,
            'status': 'Published-summary analysis; no district model fitted',
            'school_year_end': '2025-06', 'source': SOURCE}

def svg_start(width, height, title, description):
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" role="img" aria-labelledby="title desc"><title id="title">{html.escape(title)}</title><desc id="desc">{html.escape(description)}</desc><style>text{{font-family:Arial,sans-serif;fill:#17383a}}</style>'

def trend_svg(data):
    s = svg_start(760,350,'Recorded school book-ban instances, 2021–2025',
                  '; '.join(f"{r['school_year']}: {r['instances']:,}" for r in data))
    for val in [0,2500,5000,7500,10000]:
        y = 286-val/11000*240
        s += f'<path d="M64 {y:.1f}H736" stroke="#dce4e1"/><text x="52" y="{y+5:.1f}" text-anchor="end" font-size="13">{val:,}</text>'
    for i,r in enumerate(data):
        x = 92+i*166; h = r['instances']/11000*240; y = 286-h
        color = '#c85535' if i==3 else '#22786d'
        s += f'<rect x="{x}" y="{y:.1f}" width="98" height="{h:.1f}" rx="4" fill="{color}"/><text x="{x+49}" y="{y-12:.1f}" text-anchor="middle" font-size="20" font-weight="bold">{r["instances"]:,}</text><text x="{x+49}" y="316" text-anchor="middle" font-size="15">{r["school_year"]}</text>'
    return s+'</svg>'

def albers(lon,lat):
    p1,p2,p0=map(math.radians,[29.5,45.5,23]); lon0=math.radians(-96)
    n=(math.sin(p1)+math.sin(p2))/2
    c=math.cos(p1)**2+2*n*math.sin(p1)
    rho=math.sqrt(c-2*n*math.sin(math.radians(lat)))/n
    r0=math.sqrt(c-2*n*math.sin(p0))/n
    t=n*(math.radians(lon)-lon0)
    return rho*math.sin(t), -(r0-rho*math.cos(t))

def map_svg(geo, groups):
    values={r['geography']:r['instances'] for r in groups if r['geography_type']=='state'}
    features=[f for f in geo['features'] if f['properties']['NAME'] not in ['Puerto Rico','Guam','American Samoa','Commonwealth of the Northern Mariana Islands','United States Virgin Islands']]
    def polygons(f):
        g=f['geometry'];return g['coordinates'] if g['type']=='MultiPolygon' else [g['coordinates']]
    regions=[([f for f in features if f['properties']['NAME'] not in ['Alaska','Hawaii']],(18,12,810,454),albers),
             ([f for f in features if f['properties']['NAME']=='Alaska'],(24,422,155,113),lambda x,y:(x if x<0 else x-360,-y)),
             ([f for f in features if f['properties']['NAME']=='Hawaii'],(201,468,115,58),lambda x,y:(x,-y))]
    s=svg_start(850,565,'State map: Florida, Texas and Tennessee', 'Only three states have individual totals in this summary: Florida 2,304; Texas 1,781; Tennessee 1,622. Other states have no individual value in this extract. Alaska and Hawaii shown as insets, not at the same scale.')
    for fs,box,project in regions:
        pts=[project(x,y) for f in fs for p in polygons(f) for ring in p for x,y,*_ in ring]
        xmin=min(x for x,y in pts);xmax=max(x for x,y in pts);ymin=min(y for x,y in pts);ymax=max(y for x,y in pts)
        bx,by,bw,bh=box; scale=min(bw/(xmax-xmin),bh/(ymax-ymin))
        def xy(x,y):
            a,b=project(x,y);return bx+(a-xmin)*scale,by+(b-ymin)*scale
        for f in fs:
            name=f['properties']['NAME']; paths=[]
            for polygon in polygons(f):
                for ring in polygon:
                    points=[xy(*p[:2]) for p in ring]
                    # Subpixel rounding compresses the geographic drawing without altering data.
                    points=list(dict.fromkeys((round(x,1),round(y,1)) for x,y in points))
                    paths.append('M'+'L'.join(f'{x},{y}' for x,y in points)+'Z')
            label=f'{name}: {values[name]:,} instances' if name in values else f'{name}: individual count not supplied in this summary'
            s+=f'<path d="{" ".join(paths)}" fill="{COLORS.get(name,"#dde5e1")}" stroke="#fff" stroke-width=".8" fill-rule="evenodd"><title>{html.escape(label)}</title></path>'
        if len(fs)>2:
            for name,lon,lat,abbr in [('Florida',-82,28,'FL'),('Texas',-99.5,31,'TX'),('Tennessee',-86,35.8,'TN')]:
                x,y=xy(lon,lat);s+=f'<text x="{x:.1f}" y="{y:.1f}" text-anchor="middle" style="fill:white" font-size="16" font-weight="bold">{abbr}</text>'
    s+='<text x="32" y="556" font-size="13">Alaska</text><text x="208" y="550" font-size="13">Hawaii</text>'
    return s+'</svg>'

def main():
    out=ROOT/'dist'/'data';out.mkdir(parents=True,exist_ok=True)
    d=summarize(read_csv(ROOT/'data/annual_series.csv'),read_csv(ROOT/'data/published_counts.csv'))
    (out/'findings.json').write_text(json.dumps(d,indent=2)+'\n')
    (ROOT/'dist/trend.svg').write_text(trend_svg(d['annual']))
    (ROOT/'dist/map.svg').write_text(map_svg(json.loads((ROOT/'data/us_states_2024.geojson').read_text()),d['geography']))
    for name,rows in [('annual_series.csv',d['annual']),('published_counts.csv',d['geography'])]:
        with (out/name).open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    register=[]
    for p in sorted((ROOT/'data').glob('*')):
        register.append({'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
                         'provenance':'Recovered user-approved 2026-09-03 project package',
                         'recovered_date':'2026-09-25',
                         'original_acquisition_date':'Not recorded in recovered package',
                         'source_url':SOURCE if p.suffix=='.csv' else 'See original QGIS package; geographic boundaries reused unchanged',
                         'reuse':'Attribution retained; no new license asserted for source data'})
    (out/'source_register.json').write_text(json.dumps(register,indent=2)+'\n')
    print(f"PASS: {d['latest_total']:,} current instances; {d['total_four_years']:,} across four years; geographic totals reconciled.")

if __name__=='__main__':main()
