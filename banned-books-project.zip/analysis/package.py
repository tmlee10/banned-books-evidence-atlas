"""Create a portable, secret-free research source download."""
from pathlib import Path
import zipfile
ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'dist/downloads';out.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(out/'banned-books-code-and-data.zip','w',zipfile.ZIP_DEFLATED) as z:
    for part in ['analysis','tests','data','results']:
        for p in sorted((ROOT/part).rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts:z.write(p,p.relative_to(ROOT))
    for name in ['README.md','run_review.py','requirements.txt','CORRECTION_NOTICE.txt']:
        z.write(ROOT/name,name)
    report=ROOT/'dist/downloads/banned-books-earlier-report.docx'
    if not report.exists():
        raise FileNotFoundError('Missing original report required by affiliation_visuals.py')
    z.write(report,report.relative_to(ROOT))
    for p in sorted((ROOT/'dist').rglob('*')):
        if p.is_file() and 'downloads' not in p.relative_to(ROOT/'dist').parts:
            z.write(p,p.relative_to(ROOT))
print('Created dist/downloads/banned-books-code-and-data.zip')
