"""Audit historical predictions against recorded 2022–23 PEN instances; draw web figures.
Run with Python + matplotlib. Source workbook is preserved, never modified.
"""
from pathlib import Path
import csv, json, collections, hashlib, zipfile, xml.etree.ElementTree as ET
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Patch
from analyze import albers
R=Path(__file__).resolve().parents[1]; D=R/'dist'; N={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
SOURCE='https://docs.google.com/spreadsheets/d/1a6v7R7pidO7TIwRZTIh9T6c0--QNNVufcUUrDcz2GJM/edit'
REPORT='https://pen.org/report/book-bans-pressure-to-censor/'
rows=list(csv.DictReader((R/'data/historical_forecasts_2022_2023.csv').open()))
forecasts={' '.join(r['state'].split()).replace('Hawai i','Hawaii'):float(r['predicted_bans']) for r in rows}
assert len(forecasts)==50
with zipfile.ZipFile(R/'data/pen_2022_2023.xlsx') as z:
    ss=[''.join(e.itertext()) for e in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('x:si',N)]
    counters=[]
    for name in ['sheet1','sheet2']:
        counter=collections.Counter()
        for row in ET.fromstring(z.read('xl/worksheets/'+name+'.xml')).findall('.//x:sheetData/x:row',N):
            vals={}
            for c in row.findall('x:c',N):
                v=c.find('x:v',N)
                if v is not None: vals[''.join(filter(str.isalpha,c.attrib['r']))]=ss[int(v.text)] if c.attrib.get('t')=='s' else v.text
            if vals.get('G') in forecasts:
                assert vals.get('H') and vals.get('J')
                counter[vals['G']]+=1
        counters.append(counter)
    assert counters[0]==counters[1]
counts=counters[0]
assert sum(counts.values())==3362 and len(counts)==33
assert [counts[x] for x in ['Florida','Texas','Missouri','Utah','Pennsylvania']]==[1406,625,333,281,186]
records=[dict(state=s,predicted_bans=v,pen_recorded_instances=counts[s],record_status='recorded' if counts[s] else 'no_records_in_index',prediction_status='negative_invalid_count' if v<0 else 'historical_unvalidated',school_year='2022-2023') for s,v in sorted(forecasts.items())]
for target in [R/'data/forecast_comparison_2022_2023.csv',D/'data/forecast_comparison_2022_2023.csv']:
    with target.open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
(D/'data/forecast_comparison_2022_2023.json').write_text(json.dumps(records,indent=2)+'\n')
neg=sum(v<0 for v in forecasts.values())
plt.rcParams.update({'font.family':'DejaVu Sans','text.color':'#17383a','axes.labelcolor':'#17383a','xtick.color':'#46645f','ytick.color':'#17383a','svg.fonttype':'none','savefig.facecolor':'#fbfcfa'})
def save(fig,name):
    for ext in ['svg','png']:fig.savefig(D/(name+'.'+ext),dpi=150,bbox_inches='tight')
    plt.close(fig)

# Choropleth with a separate invalid category, never clipped to zero.
geo=json.loads((R/'data/us_states_2024.geojson').read_text())
fig=plt.figure(figsize=(12,7.8),facecolor='#fbfcfa');ax=fig.add_axes([.02,.18,.96,.70]);ax.axis('off')
colors=['#dcebe1','#a4cabb','#5e9b8a','#286d62','#143d3b']
def color(v):return '#f3dfdb' if v<0 else colors[0 if v<50 else 1 if v<100 else 2 if v<200 else 3 if v<300 else 4]
def polys(f):return f['geometry']['coordinates'] if f['geometry']['type']=='MultiPolygon' else [f['geometry']['coordinates']]
regions=[([f for f in geo['features'] if f['properties']['NAME'] in forecasts and f['properties']['NAME'] not in ['Alaska','Hawaii']],(0,0,810,450),albers),([f for f in geo['features'] if f['properties']['NAME']=='Alaska'],(15,410,145,105),lambda x,y:(x if x<0 else x-360,-y)),([f for f in geo['features'] if f['properties']['NAME']=='Hawaii'],(188,458,100,55),lambda x,y:(x,-y))]
seen=set()
for fs,box,project in regions:
    pts=[project(*p[:2]) for f in fs for poly in polys(f) for ring in poly for p in ring]
    xs,ys=zip(*pts); x0,x1,y0,y1=min(xs),max(xs),min(ys),max(ys);bx,by,bw,bh=box;scale=min(bw/(x1-x0),bh/(y1-y0))
    def trans(p):
        x,y=project(*p[:2]);return bx+(x-x0)*scale,by+(y-y0)*scale
    for f in fs:
        name=f['properties']['NAME'];v=forecasts[name];seen.add(name)
        for poly in polys(f):
            points=[trans(p) for p in poly[0]]
            ax.add_patch(Polygon(points,facecolor=color(v),edgecolor='#c09e99' if v<0 else 'white',lw=.6,hatch='///' if v<0 else None))
            if name=='Ohio':ax.add_patch(Polygon(points,fill=False,edgecolor='#c85535',lw=2.4,zorder=5))
    if len(fs)>2:
        x,y=trans([-82.8,40.1]);ax.annotate('OHIO\n131.8',xy=(x,y),xytext=(x+115,y-70),arrowprops={'arrowstyle':'-','color':'#c85535'},fontsize=13,weight='bold',color='#a5442b',bbox={'facecolor':'#fbfcfa','edgecolor':'none','pad':5})
assert seen==set(forecasts)
ax.set_xlim(-5,850);ax.set_ylim(540,-15);ax.set_aspect('equal')
ax.text(20,535,'Alaska',fontsize=10);ax.text(194,535,'Hawaii',fontsize=10)
fig.text(.04,.955,'Historical forecasts for 2022–2023',fontsize=23,weight='bold')
fig.text(.04,.91,'Original model output • Unvalidated • Not observed bans or a current forecast',fontsize=12)
labels=['0–<50','50–<100','100–<200','200–<300','300+']
handles=[Patch(facecolor=c,label=l) for c,l in zip(colors,labels)]+[Patch(facecolor='#f3dfdb',edgecolor='#c09e99',hatch='///',label=f'Negative / invalid ({neg} states)')]
fig.legend(handles=handles,loc='lower left',bbox_to_anchor=(.035,.105),ncol=3,frameon=False,fontsize=11)
fig.text(.04,.075,'Units: predicted ban instances. Alaska and Hawaii are inset at different scales.',fontsize=10)
fig.text(.04,.04,'Source: original Banned Books.docx, printed predicted_bans output. Boundaries: retained QGIS package.',fontsize=9)
save(fig,'historical-forecast-map')

# All original values; negative bars remain visible as diagnostic failures.
ordered=sorted(forecasts.items(),key=lambda x:(-x[1],x[0]));fig,axes=plt.subplots(1,2,figsize=(13,11.5),facecolor='#fbfcfa')
for ax,part in zip(axes,[ordered[:25],ordered[25:]]):
    ax.set_facecolor('#fbfcfa')
    for i,(name,v) in enumerate(part):
        bar=ax.barh(i,v,color='#c85535' if name=='Ohio' else '#d5a59b' if v<0 else '#22786d',height=.64)
        if v<0:bar[0].set_hatch('///')
        ax.text(max(v,0)+7,i,f'{v:.1f}'+(' *' if v<0 else ''),va='center',fontsize=9,weight='bold' if name=='Ohio' else 'normal')
    ax.set_yticks(range(25),[x[0] for x in part],fontsize=10);ax.invert_yaxis();ax.set_xlim(-35,560);ax.set_xticks([0,100,200,300,400,500]);ax.axvline(0,color='#778e88',lw=.8);ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True);ax.set_xlabel('Original predicted ban instances',fontsize=10)
    for sp in ax.spines.values():sp.set_visible(False)
fig.suptitle('All 50 historical state predictions',fontsize=22,weight='bold',x=.05,ha='left',y=.985)
fig.text(.05,.948,'Target school year: 2022–2023. Ohio is highlighted. These are model outputs, not recorded bans.',fontsize=11)
fig.subplots_adjust(left=.14,right=.98,top=.91,bottom=.10,wspace=.48)
fig.text(.05,.045,f'* Negative predictions in {neg} states are invalid counts, retained to document model limitations. Values rounded to one decimal.',fontsize=10)
fig.text(.05,.022,'Source: original Banned Books.docx, printed output. Exact values and comparisons are available in the CSV.',fontsize=9)
save(fig,'historical-forecast-states')

fig,ax=plt.subplots(figsize=(9,3.8),facecolor='#fbfcfa');ax.set_facecolor('#fbfcfa')
ax.barh([1,0],[forecasts['Ohio'],counts['Ohio']],color=['#c85535','#22786d'],height=.42);ax.scatter([0],[0],facecolors='white',edgecolors='#22786d',s=75,zorder=4)
ax.set_yticks([1,0],['Historical model estimate','PEN recorded instances']);ax.set_xlim(0,160);ax.set_ylim(-.6,1.65);ax.set_xticks([0,40,80,120,160]);ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True)
ax.text(134,1,'131.8',va='center',weight='bold',fontsize=12);ax.text(4,0,'0 — no Ohio records in the index',va='center',fontsize=11)
for sp in ax.spines.values():sp.set_visible(False)
ax.set_title('Ohio: historical estimate and recorded cases, 2022–2023',loc='left',pad=20,fontsize=15,weight='bold')
fig.subplots_adjust(left=.25,right=.95,top=.8,bottom=.24)
fig.text(.04,.08,'No recorded cases does not establish that no bans occurred. This comparison is not a validation of the model.',fontsize=10)
fig.text(.04,.025,'Sources: original Banned Books.docx; PEN America 2022–2023 index (retrieved September 29, 2026).',fontsize=9)
save(fig,'ohio-forecast-comparison')
meta={'retrieved':'2026-09-29','source_url':SOURCE,'report_url':REPORT,'file':'data/pen_2022_2023.xlsx','sha256':hashlib.sha256((R/'data/pen_2022_2023.xlsx').read_bytes()).hexdigest(),'records':3362,'states_with_records':33,'sheets_crosschecked':['Sorted by State & District','Sorted by Author & Title'],'aggregation':'Count each state-bearing event row once from one sheet; cross-check the other sheet without concatenating. States absent from the complete index have zero recorded entries, not verified absence of bans.','state_name_normalization':'Hawai i to Hawaii; collapse repeated spaces in West Virginia. Original transcription retained.', 'source_quality_note':'One state-bearing Texas entry has a blank title in both sheets and is retained to reconcile to PEN’s 3,362 total.', 'negative_predictions':neg,'forecast_source':'Banned Books.docx printed output','forecast_validation':'Not demonstrated; this is retrospective descriptive comparison, not a new or validated forecast.'}
(D/'data/forecast_sources.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({'records':3362,'states':33,'Ohio':counts['Ohio'],'state_name_normalization':'Hawai i to Hawaii; collapse repeated spaces in West Virginia. Original transcription retained.', 'source_quality_note':'One state-bearing Texas entry has a blank title in both sheets and is retained to reconcile to PEN’s 3,362 total.', 'negative_predictions':neg,'joined_states':len(seen)}))
