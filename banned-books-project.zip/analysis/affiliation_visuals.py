"""Reproduce five-state labels from supplied report figures; no demographic model is fitted."""
from pathlib import Path
import csv,json,hashlib,shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
R=Path(__file__).resolve().parents[1];D=R/'dist'
rows=[('Texas',801,'Evangelical Protestant','Democrat'),('Florida',566,'Evangelical Protestant','Democrat'),('Pennsylvania',458,'Catholic','Democrat'),('Tennessee',349,'Evangelical Protestant','Republican'),('Oklahoma',43,'Evangelical Protestant','Republican')]
fields=['state','historical_ban_count','religion_label_as_printed','party_label_as_printed','ban_school_year','verification_status']
for base in [R/'data',D/'data']:
 with (base/'historical_affiliations.csv').open('w') as f:
  w=csv.writer(f);w.writerow(fields)
  for r in rows:w.writerow([*r,'2021-2022','transcribed_from_original_figure_inputs_not_verified'])
meta={'reviewed':'2026-09-29','source':'Supplied Banned Books.docx','source_sha256':hashlib.sha256((D/'downloads/banned-books-earlier-report.docx').read_bytes()).hexdigest(),'locations':['word/media/image31.png party labels','word/media/image37.png religion classification code','word/media/image39.png combined five-state chart'],'scope':'Five selected states in the original figure; not independently verified as the national top five','religion_rule':'Largest value among affiliation columns, excluding State and Sample size; includes unaffiliated and other categories','politics_rule':'Compare Republican/lean Rep. with Democrat/lean Dem.; larger share determines label, ties remain Undecided','limitations':['Original Religion.xlsx and partisan.xlsx unavailable','Prose cites Gallup 2017 but the appendix input provenance and survey year are not established','Labels are state aggregates, not characteristics of challengers','No religion or party percentages reconstructed for these five states','Historical ban counts are figure transcriptions; 2535 source rows versus 2532 published annual instances remains unresolved','Gender, sexual orientation and age respondent results require original survey and codebook']}
for base in [R/'data',D/'data']:(base/'affiliation_sources.json').write_text(json.dumps(meta,indent=2)+'\n')
plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'none','text.color':'#17383a','axes.labelcolor':'#17383a','xtick.color':'#46645f','ytick.color':'#17383a'})
fig,ax=plt.subplots(figsize=(11,5),facecolor='#fbfcfa');ax.set_facecolor('#fbfcfa')
for i,(state,count,religion,party) in enumerate(rows):
 ax.barh(i,count,color='#24796d' if religion=='Evangelical Protestant' else '#b97249',height=.58)
 ax.text(count+12,i,str(count),va='center',fontsize=13,weight='bold')
ax.set_yticks(range(5),[r[0] for r in rows],fontsize=12);ax.invert_yaxis();ax.set_xlim(0,900);ax.set_xlabel('Ban instances printed in the earlier report',fontsize=11);ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True)
for sp in ax.spines.values():sp.set_visible(False)
fig.suptitle('Religious categories in the earlier five-state chart',x=.035,y=.97,ha='left',fontsize=19,weight='bold')
fig.text(.035,.895,'2021–2022 ban counts • State affiliation labels reproduced from the original report',fontsize=11)
fig.legend(handles=[Patch(color='#24796d',label='Evangelical Protestant'),Patch(color='#b97249',label='Catholic')],loc='lower left',bbox_to_anchor=(.025,.09),ncol=2,frameon=False,fontsize=11)
fig.text(.035,.055,'Bar lengths count bans, not adherents. Colors show the report’s largest affiliation category.',fontsize=10)
fig.text(.035,.015,'Historical transcription only. Input files and survey dates need verification; no causal relationship is established.',fontsize=9)
fig.subplots_adjust(left=.17,right=.97,top=.82,bottom=.25)
for ext in ['svg','png']:fig.savefig(D/('historical-affiliations.'+ext),dpi=150)
plt.close(fig)
print('Created affiliation CSV, provenance and chart')
