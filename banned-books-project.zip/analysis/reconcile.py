"""Offline counting audit of bundled inputs; Python 3.10+, standard library only.

No downloads, model fitting, title imputation or silent duplicate removal.
"""
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
NS = {'x': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
REL = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
STATES = set('Alabama|Alaska|Arizona|Arkansas|California|Colorado|Connecticut|Delaware|Florida|Georgia|Hawaii|Idaho|Illinois|Indiana|Iowa|Kansas|Kentucky|Louisiana|Maine|Maryland|Massachusetts|Michigan|Minnesota|Mississippi|Missouri|Montana|Nebraska|Nevada|New Hampshire|New Jersey|New Mexico|New York|North Carolina|North Dakota|Ohio|Oklahoma|Oregon|Pennsylvania|Rhode Island|South Carolina|South Dakota|Tennessee|Texas|Utah|Vermont|Virginia|Washington|West Virginia|Wisconsin|Wyoming'.split('|'))
FIELDS = ['title', 'author', 'secondary_authors', 'illustrators', 'translators', 'series', 'state', 'district', 'date_excel_serial_or_text', 'status', 'origin']

def read_workbook(path):
    """Read actual sheet names/relationships and row coordinates, not header offsets."""
    result = {}
    with ZipFile(path) as z:
        shared = []
        if 'xl/sharedStrings.xml' in z.namelist():
            shared = [''.join(t.text or '' for t in e.findall('.//x:t', NS))
                      for e in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('x:si', NS)]
        rels = {e.attrib['Id']: e.attrib['Target'] for e in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
        for sheet in ET.fromstring(z.read('xl/workbook.xml')).findall('x:sheets/x:sheet', NS):
            name = sheet.attrib['name']
            if name not in ['Sorted by State & District', 'Sorted by Author & Title']:
                continue
            target = rels[sheet.attrib[REL]]
            target = target.lstrip('/') if target.startswith('/') else 'xl/' + target
            rows = []
            for row in ET.fromstring(z.read(target)).findall('x:sheetData/x:row', NS):
                cells = {}
                for c in row.findall('x:c', NS):
                    col = ''.join(ch for ch in c.attrib['r'] if ch.isalpha())
                    v = c.find('x:v', NS)
                    value = '' if v is None else (v.text or '')
                    if c.attrib.get('t') == 's':
                        value = shared[int(value)]
                    elif c.attrib.get('t') == 'inlineStr':
                        value = ''.join(t.text or '' for t in c.findall('.//x:t', NS))
                    cells[col] = value
                state = cells.get('G', '').strip()
                if state not in STATES:
                    if cells.get('J', '').startswith('Banned'):
                        raise ValueError(f'Unrecognized event geography in {name} row {row.attrib["r"]}')
                    continue
                if not cells.get('H') or not cells.get('J'):
                    raise ValueError(f'Missing district/status in {name} row {row.attrib["r"]}')
                rec = dict(zip(FIELDS, [cells.get(chr(65+i), '') for i in range(11)]))
                rec.update(sheet=name, source_row=int(row.attrib['r']), state=state)
                rows.append(rec)
            result[name] = rows
    if set(result) != {'Sorted by State & District', 'Sorted by Author & Title'}:
        raise ValueError('Required workbook sheets are missing')
    return result

def reconcile_workbook(path):
    sheets = read_workbook(path)
    def signature(rows):
        return Counter(tuple(r[k] for k in FIELDS) for r in rows)
    first, second = sheets.values()
    if signature(first) != signature(second):
        raise ValueError('Workbook sheets disagree at event-record level')
    # Choose ONE view; never concatenate two views of the same index.
    selected = sheets['Sorted by Author & Title']
    counts = Counter(r['state'] for r in selected)
    nonblank = Counter(r['state'] for r in selected if r['title'].strip())
    return selected, counts, nonblank, sheets

def write_csv(path, rows):
    rows = list(rows)
    if not rows:
        return
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

def main():
    out = ROOT/'results'
    out.mkdir(exist_ok=True)
    events, counts, nonblank, sheets = reconcile_workbook(ROOT/'data/pen_2022_2023.xlsx')
    state_rows = [{'state': s, 'school_year': '2022-2023', 'event_rows': counts[s],
                   'nonblank_title_rows': nonblank[s], 'blank_title_rows': counts[s]-nonblank[s],
                   'record_status': 'recorded' if counts[s] else 'no_records_in_supplied_index'} for s in sorted(STATES)]
    write_csv(out/'state_counts_2022_2023.csv', state_rows)
    write_csv(out/'events_2022_2023_for_audit.csv', events)
    missing = [r for rows in sheets.values() for r in rows if not r['title'].strip()]
    write_csv(out/'blank_title_source_rows.csv', missing)
    keys = Counter(tuple(r[k] for k in FIELDS) for r in events)
    repeated = sum(n-1 for n in keys.values() if n > 1)
    from analyze import summarize, read_csv
    summary = summarize(read_csv(ROOT/'data/annual_series.csv'), read_csv(ROOT/'data/published_counts.csv'))
    dodea = next(r['instances'] for r in summary['geography'] if r['geography_code']=='DoDEA')
    rows = [
        {'measure': '2022-2023 event rows', 'value': len(events), 'basis': 'Workbook rows with recognized state and district/status; blank title retained'},
        {'measure': '2022-2023 nonblank title rows', 'value': sum(nonblank.values()), 'basis': 'Same selected sheet; blank titles excluded; NOT unique titles'},
        {'measure': '2022-2023 Texas event rows', 'value': counts['Texas'], 'basis': 'Same selected sheet'},
        {'measure': '2022-2023 Texas nonblank title rows', 'value': nonblank['Texas'], 'basis': 'Same selected sheet; blank titles excluded'},
        {'measure': '2024-2025 national instances', 'value': summary['latest_total'], 'basis': 'Supplied published-summary CSV; not rebuilt from 2024-2025 event rows'},
        {'measure': '2024-2025 top-three state instances', 'value': summary['top_three_total'], 'basis': 'Florida + Texas + Tennessee supplied summary counts'},
        {'measure': '2024-2025 top-three share percent all instances', 'value': summary['top_three_share'], 'basis': '5707 / 6870 * 100; includes DoDEA in denominator'},
        {'measure': '2024-2025 top-three share percent excluding DoDEA', 'value': 100*summary['top_three_total']/(summary['latest_total']-dodea), 'basis': '5707 / (6870 - 590) * 100'},
        {'measure': 'Four-year supplied summary total', 'value': summary['total_four_years'], 'basis': '2532 + 3362 + 10046 + 6870; published-summary arithmetic'},
    ]
    write_csv(out/'reconciliation.csv', rows)
    audit = {'workbook_sha256': hashlib.sha256((ROOT/'data/pen_2022_2023.xlsx').read_bytes()).hexdigest(),
             'selected_sheet': 'Sorted by Author & Title', 'sheet_event_multisets_equal': True,
             'event_rows': len(events), 'nonblank_title_rows': sum(nonblank.values()),
             'states_with_records': len(counts), 'extra_identical_records_retained': repeated,
             'blank_title_source_rows': [{k:r[k] for k in ['sheet','source_row','state','district']} for r in missing],
             'blank_title_policy': 'Retain source entry in event-row count; report nonblank-title count separately. Do not invent a title.',
             'duplicate_policy': 'Keep original rows. Compare the two sheet views without concatenation or automatic deduplication.',
             'limits': ['Published-summary arithmetic is not an independent row-level replication of 2024-2025.',
                        'Historical regression and affiliations not refitted; original inputs absent.',
                        'Independent comparison output not supplied; exact discrepancy not established.']}
    (out/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    print(json.dumps(audit,indent=2))

if __name__ == '__main__':
    main()
