"""Validate supplied event data and build an explicitly covered district-month panel.

No real row-level input is bundled. No geocoding, fuzzy matching or imputed dates.
Run: python3 analysis/prepare_events.py --events events.csv --coverage coverage.csv --output results
Schemas and review requirements are in README.md.
"""
import argparse
import csv
import datetime as dt
import json
import re
from collections import Counter
from pathlib import Path

def school_year(month):
    d=dt.date.fromisoformat(month+'-01');start=d.year if d.month>=7 else d.year-1
    return f'{start}-{start+1}'

def prepare(events,coverage):
    issues=[];accepted=[];statewide=[];seen=set();keys={};blocked=set();block_years=set()
    def flag(i,r,message):issues.append({'row':i,'event_id':r.get('event_id',''),'issue':message})
    for i,r in enumerate(events,2):
        if r.get('scope')=='state':statewide.append(r);continue
        before=len(issues);eid=r.get('event_id','');nces=r.get('nces_id','');month=r.get('month','')
        if not eid or eid in seen:flag(i,r,'Missing or duplicate event_id; manual review required')
        seen.add(eid)
        if r.get('scope')!='district':flag(i,r,'Scope must be district or state')
        if not re.fullmatch(r'\d{7}',nces) or r.get('nces_match_status')!='verified':flag(i,r,'Unresolved NCES identity')
        if not re.fullmatch(r'\d{4}-\d{4}',r.get('school_year','')):flag(i,r,'Missing school year')
        if not r.get('title_id') or not r.get('source_url'):flag(i,r,'Missing title ID or source')
        try:
            if not re.fullmatch(r'\d{4}-\d{2}',month):raise ValueError()
            sy=school_year(month)
            if r.get('date_precision') not in ['day','month'] or sy!=r.get('school_year'):raise ValueError()
        except ValueError:flag(i,r,'Unresolved or inconsistent event month')
        key=(nces,r.get('title_id'),month)
        if key in keys:
            flag(i,r,'Possible duplicate title-district-month; no automatic collapse')
            blocked.add((nces,month))
        keys[key]=eid
        if len(issues)==before:accepted.append(r)
        elif nces:
            if re.fullmatch(r'\d{4}-\d{2}',month):blocked.add((nces,month))
            else:block_years.add((nces,r.get('school_year')))
    # A reviewer must provide a complete eligibility/coverage frame, not only districts with bans.
    counts=Counter((r['nces_id'],r['month']) for r in accepted);panel=[];frame=set()
    for r in coverage:
        nces=r.get('nces_id','');month=r.get('month','');key=(nces,month)
        if not re.fullmatch(r'\d{7}',nces) or not re.fullmatch(r'\d{4}-\d{2}',month):raise ValueError('Invalid coverage identity/month')
        sy=school_year(month)
        if key in frame:raise ValueError('Duplicate district-month in coverage frame')
        frame.add(key)
        if r.get('coverage') not in ['covered','unknown']:raise ValueError('Coverage must be covered or unknown')
        # Covered means observed under a documented collection procedure, not proof of no unreported bans.
        covered=r['coverage']=='covered'
        if covered and not r.get('coverage_source'):raise ValueError('Covered month requires coverage_source')
        try:enrollment=int(r['enrollment'])
        except (KeyError,ValueError):enrollment=0
        valid=covered and key not in blocked and (nces,sy) not in block_years
        n=counts.get(key,0) if valid else None
        panel.append({**r,'school_year':sy,'ban_instances':n,
                      'instances_per_10000':10000*n/enrollment if n is not None and enrollment>0 else None,
                      'enrollment_valid':enrollment>0,
                      'analysis_status':'eligible' if valid and enrollment>0 else 'review_or_missing'})
    missing=set(counts)-frame
    if missing:raise ValueError('Accepted events outside supplied coverage frame')
    return {'panel':panel,'issues':issues,'state_mandated':statewide,
            'counts':{'input_events':len(events),'accepted_district_events':len(accepted),'issues':len(issues),'state_events':len(statewide)},
            'model_ready':not issues and all(r['analysis_status']=='eligible' for r in panel) and bool(panel)}

def main():
    p=argparse.ArgumentParser();p.add_argument('--events',required=True);p.add_argument('--coverage',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    def read(path):
        with open(path,newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))
    result=prepare(read(a.events),read(a.coverage));out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    (out/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
    for name in ['panel','issues','state_mandated']:
        rows=result[name]
        if rows:
            with (out/(name+'.csv')).open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print(json.dumps(result['counts']));print('Model ready:',result['model_ready'])

if __name__=='__main__':main()
