from pathlib import Path
import csv,json,html,sys,math
R=Path(__file__).resolve().parents[1];D=R/"dist";O=R/"state_reconstruction/outputs"
rows=list(csv.DictReader((O/'state_analysis_2022_2023.csv').open())); correlations=list(csv.DictReader((O/'descriptive_correlations.csv').open()))
# Reuse the verified boundary data and the existing Albers projection, keeping Alaska/Hawaii as insets.
sys.path.insert(0,str(R/'analysis'));from analyze import albers
geo=json.loads((R/'data/us_states_2024.geojson').read_text()); names={r['state']:r for r in rows}
features=[f for f in geo['features'] if f['properties']['NAME'] in names]
assert len(features)==50
polys=lambda f:f['geometry']['coordinates'] if f['geometry']['type']=='MultiPolygon' else [f['geometry']['coordinates']]
regions=[([f for f in features if f['properties']['NAME'] not in ['Alaska','Hawaii']],(18,12,810,454),albers),([f for f in features if f['properties']['NAME']=='Alaska'],(24,422,155,113),lambda x,y:(x if x<0 else x-360,-y)),([f for f in features if f['properties']['NAME']=='Hawaii'],(201,468,115,58),lambda x,y:(x,-y))]
colors=['#e5e8e5','#c8dfda','#8dbeb3','#488f80','#185d52'];paths=[]
for fs,(bx,by,bw,bh),project in regions:
 pts=[project(x,y) for f in fs for p in polys(f) for ring in p for x,y,*_ in ring];xmin=min(x for x,y in pts);xmax=max(x for x,y in pts);ymin=min(y for x,y in pts);ymax=max(y for x,y in pts);scale=min(bw/(xmax-xmin),bh/(ymax-ymin))
 for f in fs:
  name=f['properties']['NAME'];r=names[name];rate=float(r['bans_per_million_residents']);count=int(r['event_rows']);color=colors[0 if count==0 else 1 if rate<10 else 2 if rate<25 else 3 if rate<50 else 4];rings=[]
  for p in polys(f):
   for ring in p:
    xy=[project(*v[:2]) for v in ring];xy=list(dict.fromkeys((round(bx+(x-xmin)*scale,1),round(by+(y-ymin)*scale,1)) for x,y in xy));rings.append('M'+'L'.join(f'{x},{y}' for x,y in xy)+'Z')
  label=f'{name}: {count:,} recorded entries, {rate:.2f} per million residents' if count else f'{name}: no entries in the retained index; not proof of no bans'
  paths.append(f'<path d="{" ".join(rings)}" fill="{color}" stroke="white" stroke-width=".8" fill-rule="evenodd"><title>{html.escape(label)}</title></path>')
(D/'state-rates-2022-2023.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 850 565" role="img" aria-labelledby="maptitle mapdesc"><title id="maptitle">2022–2023 recorded entries per million residents</title><desc id="mapdesc">Utah has the highest rate at 83.12, followed by Florida at 63.21 and Missouri at 53.90. Gray means no entries in this index. Alaska and Hawaii are insets, not at the same scale.</desc>'+''.join(paths)+'</svg>')
print("Generated state-rates-2022-2023.svg from the verified state data")
