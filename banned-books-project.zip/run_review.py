"""One-command offline review. Core audit is standard-library only."""
import argparse
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--figures', action='store_true', help='Also regenerate historical figures; requires matplotlib')
args = parser.parse_args()
(root/'dist/data').mkdir(parents=True, exist_ok=True)
commands = [['-m','unittest','discover','-s','tests','-v'], ['analysis/reconcile.py']]
if args.figures:
    commands += [['analysis/forecast_visuals.py'], ['analysis/affiliation_visuals.py']]
commands += [['analysis/analyze.py']]
for command in commands:
    print('RUN', ' '.join(command), flush=True)
    subprocess.run([sys.executable, *command], cwd=root, check=True)
print('Completed requested checks. Read results/audit.json for limits; no historical model was fitted.')
