"""Dumbbell chart: top ten 2025-26 rate states vs the other forty (unweighted state averages).
Usage: python chart.py out/group_comparison.csv out/demographics_top10_vs_other40.png"""
import csv, sys
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
g = {r['measure']: r for r in csv.DictReader(open(sys.argv[1]))}
order = ['White, not Hispanic (%)', 'Hispanic or Latino (%)', 'Black, not Hispanic (%)', 'Asian, not Hispanic (%)',
         'Under 18 (%)', 'Aged 65 and over (%)', 'Female (%)', 'High school graduate or higher, 25+ (%)',
         "Bachelor's degree or higher, 25+ (%)", 'Below poverty level (%)', 'Urban residents (%)']
INK, TEAL, GREY = '#17383a', '#286d62', '#9aa5a2'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11})
fig, ax = plt.subplots(figsize=(11, 6.4), dpi=200)
for i, m in enumerate(order):
    t, o = float(g[m]['top10_unweighted']), float(g[m]['other40_unweighted'])
    y = len(order) - 1 - i
    ax.plot([o, t], [y, y], color='#cfd8d5', lw=3, zorder=1)
    ax.scatter([o], [y], color=GREY, s=60, zorder=2)
    ax.scatter([t], [y], color=TEAL, s=60, zorder=3)
    lo, hi = (t, o) if t < o else (o, t)
    ax.text(lo - 1.2, y, f'{lo:.1f}', ha='right', va='center', fontsize=9.5, color=TEAL if lo == t else GREY)
    ax.text(hi + 1.2, y, f'{hi:.1f}', ha='left', va='center', fontsize=9.5, color=TEAL if hi == t else GREY)
ax.set_yticks(range(len(order)), [m.replace(' (%)', '') for m in reversed(order)], color=INK)
ax.set_xlim(-6, 106); ax.set_xlabel('Per cent of residents (education: residents aged 25 and over)', color=INK)
for s in ['top', 'right', 'left']: ax.spines[s].set_visible(False)
ax.tick_params(axis='y', length=0); ax.grid(axis='x', color='#eef2f0'); ax.set_axisbelow(True)
ax.scatter([], [], color=TEAL, s=60, label='Ten highest-rate states, 2025–26')
ax.scatter([], [], color=GREY, s=60, label='Other forty states')
ax.legend(frameon=False, loc='lower left', bbox_to_anchor=(0, 1.0), ncol=2, fontsize=10)
ax.set_title('Who lives in the states with the highest recorded book-ban rates', loc='left', fontsize=14, weight='bold', color=INK, pad=34)
fig.text(0.01, 0.01, 'Unweighted averages of state figures. Sources: ACS 2025 1-year (DP05, DP02, DP03); 2020 Census (urban). '
         'Describes residents, not the people who filed challenges.', fontsize=8.5, color='#46645f')
fig.tight_layout(rect=(0, 0.03, 1, 1)); fig.savefig(sys.argv[2], facecolor='white')
print('wrote', sys.argv[2])
