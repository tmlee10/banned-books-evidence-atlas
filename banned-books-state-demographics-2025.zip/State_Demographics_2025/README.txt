State demographic profile for the 2025-26 book-ban analysis
Prepared 17 November 2026

WHAT IT DOES
  Joins Census measures to the 50-state 2025-26 table and compares the ten
  states with the highest PEN-recorded rate per million residents (Texas,
  Florida, Utah, Arkansas, Iowa, Minnesota, Ohio, Michigan, Wyoming, Idaho)
  with the other forty; and the 23 states with a count on PEN's map with the
  27 without. It describes the people who live in these states. It does not
  identify who filed challenges or made decisions, and it does not show that
  any characteristic causes bans to be recorded.

SOURCES (census_sources/, downloaded from data.census.gov on 17 November 2026)
  ACSDP1Y2025.DP05  age, sex, race and Hispanic origin
  ACSDP1Y2025.DP02  educational attainment
  ACSDP1Y2025.DP03  household income, poverty
  DECENNIALDHC2020.P2  urban and rural population (2020 Census; the ACS does
                    not publish an urban/rural split by state)
  Variables are selected by their published labels, not their codes, because
  codes shift between years. ACS 2025 state totals match the Census 2025
  estimates already in the analysis for 49 states; Kansas differs by 2 people.

RESULT
  The ten highest-rate states look much like the other forty on every Census
  measure. Unweighted state averages, top ten vs other forty:
    White, not Hispanic 67.6% vs 62.1%; Hispanic 15.0% vs 13.9%;
    Black 8.0% vs 10.4%; under 18 22.0% vs 20.6%; bachelor's degree 34.7%
    vs 36.7%; median household income $81,291 vs $84,814; urban 73.7% vs
    72.1%.
  A permutation check asks how often a random group of ten states differs
  from the other forty by as much. Only the share under 18 comes out below
  0.05 (0.031), and with 13 measures about one such result is expected by
  chance. Across all 50 states, rank correlations with the rate run from
  -0.19 to 0.30.
  For comparison, the 2024 Republican margin differs more clearly under the
  same check: +18.3 vs +3.8 points, permutation p = 0.038.
  Population-weighted figures (group_comparison.csv) are dominated by Texas
  and Florida, about 55 million of the top ten's 74 million residents. On
  that basis the top ten are more Hispanic (24.1% vs 19.1%) and have lower
  median income; that difference reflects those two states, not the group.

LIMITS
  Ten states is a small group, and several have few instances (Wyoming 3,
  Idaho 9). State averages hide wide variation inside states. PEN's coverage
  is uneven, so the ranking reflects reporting as well as bans. Sexual
  orientation is not measured by the Census and is not included.

FILES
  state_demographics_2025.csv        50 states with all measures
  group_comparison.csv               every measure by group, weighted and unweighted
  demographics_summary.txt           the printed summary
  demographics_top10_vs_other40.png  chart
  state_demographics.py, chart.py    scripts

RERUN
  python state_demographics.py state_analysis_2025_2026.csv DP05_DIR DP02_DIR DP03_DIR P2_DIR out
  python chart.py out/group_comparison.csv out/demographics_top10_vs_other40.png
  (each *_DIR may be census_sources/)
