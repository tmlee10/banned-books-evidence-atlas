"""State demographic profile for the 2025-26 book-ban analysis.

Joins Census measures to the 50-state 2025-26 table and compares
(a) the ten states with the highest PEN-recorded rate per million residents
    with the other forty, and
(b) the 23 states with a count on PEN's map with the 27 without.

This describes the people who live in each state. It does not describe the
people who filed challenges or made decisions.

Usage:
  python state_demographics.py STATE_2025_26_CSV DP05_DIR DP02_DIR DP03_DIR P2_DIR OUT_DIR

The *_DIR arguments are the unzipped data.census.gov downloads; the script
reads ACSDP1Y2025.DP05/DP02/DP03 and DECENNIALDHC2020.P2 from them.

Outputs (OUT_DIR):
  state_demographics_2025.csv   50 states: 2025-26 instances and rate + Census measures
  group_comparison.csv          each measure by group, unweighted and population-weighted,
                                with a permutation check for the top-ten comparison
  demographics_summary.txt      readable summary
"""
import csv
import os
import random
import re
import sys

st_csv, dp05_dir, dp02_dir, dp03_dir, p2_dir, out = sys.argv[1:7]
os.makedirs(out, exist_ok=True)


def load(dirpath, table, wanted):
    """wanted: {short_name: exact metadata label}. Returns {state: {short_name: float}}
    and {short_name: code}. Codes are looked up by label because they shift by year."""
    meta = list(csv.reader(open(os.path.join(dirpath, f'{table}-Column-Metadata.csv'), encoding='utf-8-sig')))
    codes = {}
    for name, label in wanted.items():
        hits = [c for c, l in meta if l == label]
        assert hits, (table, label)
        codes[name] = hits[0]          # first occurrence; checked below where labels repeat
    rows = list(csv.DictReader(open(os.path.join(dirpath, f'{table}-Data.csv'), encoding='utf-8-sig')))[1:]
    data = {}
    for r in rows:
        if r['NAME'] in ('District of Columbia', 'Puerto Rico'):
            continue                      # outside the 50-state analysis
        data[r['NAME']] = {n: float(r[c]) for n, c in codes.items()}
    assert len(data) == 50, (table, len(data))
    return data, codes


DP05 = {
    'population_acs': 'Estimate!!SEX AND AGE!!Total population',
    'median_age': 'Estimate!!SEX AND AGE!!Total population!!Median age (years)',
    'pct_female': 'Percent!!SEX AND AGE!!Total population!!Female',
    'pct_under_18': 'Percent!!SEX AND AGE!!Total population!!Under 18 years',
    'pct_65_plus': 'Percent!!SEX AND AGE!!Total population!!65 years and over',
    'pct_hispanic': 'Percent!!HISPANIC OR LATINO AND RACE!!Total population!!Hispanic or Latino (of any race)',
    'pct_white_nh': 'Percent!!HISPANIC OR LATINO AND RACE!!Total population!!Not Hispanic or Latino!!White alone',
    'pct_black_nh': 'Percent!!HISPANIC OR LATINO AND RACE!!Total population!!Not Hispanic or Latino!!Black or African American alone',
    'pct_asian_nh': 'Percent!!HISPANIC OR LATINO AND RACE!!Total population!!Not Hispanic or Latino!!Asian alone',
    'pct_aian_nh': 'Percent!!HISPANIC OR LATINO AND RACE!!Total population!!Not Hispanic or Latino!!American Indian and Alaska Native alone',
    'pct_two_plus_nh': 'Percent!!HISPANIC OR LATINO AND RACE!!Total population!!Not Hispanic or Latino!!Two or More Races',
}
DP02 = {
    'pct_hs_grad_25plus': 'Percent!!EDUCATIONAL ATTAINMENT!!Population 25 years and over!!High school graduate or higher',
    'pct_bachelors_25plus': "Percent!!EDUCATIONAL ATTAINMENT!!Population 25 years and over!!Bachelor's degree or higher",
}
DP03 = {
    'median_household_income': 'Estimate!!INCOME AND BENEFITS (IN 2025 INFLATION-ADJUSTED DOLLARS)!!Total households!!Median household income (dollars)',
    'pct_poverty': 'Percent!!PERCENTAGE OF FAMILIES AND PEOPLE WHOSE INCOME IN THE PAST 12 MONTHS IS BELOW THE POVERTY LEVEL!!All people',
}
P2 = {'p2_total': ' !!Total:', 'p2_urban': ' !!Total:!!Urban', 'p2_rural': ' !!Total:!!Rural'}

d05, c05 = load(dp05_dir, 'ACSDP1Y2025.DP05', DP05)
d02, c02 = load(dp02_dir, 'ACSDP1Y2025.DP02', DP02)
d03, c03 = load(dp03_dir, 'ACSDP1Y2025.DP03', DP03)
dp2, cp2 = load(p2_dir, 'DECENNIALDHC2020.P2', P2)
# "65 years and over" appears twice in the 2025 DP05 metadata; the first is the percentage.
assert c05['pct_65_plus'] == 'DP05_0024PE', c05['pct_65_plus']

base = list(csv.DictReader(open(st_csv, encoding='utf-8')))
assert len(base) == 50
rows = []
for b in base:
    s = b['state']
    r = {'state': s, 'abbreviation': b['abbreviation'],
         'instances_2025_26': int(b['instances']),
         'rate_per_million_2025_26': float(b['instances_per_million']),
         'republican_margin_2024_pp': float(b['republican_margin_pp']),
         'population_2025_census_estimate': int(b['population_2025'])}
    for src in (d05, d02, d03):
        r.update(src[s])
    p = dp2[s]
    assert p['p2_urban'] + p['p2_rural'] == p['p2_total'], s
    r['pct_urban_2020'] = 100 * p['p2_urban'] / p['p2_total']
    r['pct_rural_2020'] = 100 * p['p2_rural'] / p['p2_total']
    r['pct_male'] = 100 - r['pct_female']
    rows.append(r)

# The ACS 2025 totals are controlled to the Census 2025 estimates; check they agree.
mismatch = [r['state'] for r in rows if int(r['population_acs']) != r['population_2025_census_estimate']]

ranked = sorted(rows, key=lambda r: -r['rate_per_million_2025_26'])
top = {r['state'] for r in ranked[:10]}
with_count = {r['state'] for r in rows if r['instances_2025_26'] > 0}
assert len(top) == 10 and len(with_count) == 23
for r in rows:
    r['top_ten_rate'] = int(r['state'] in top)
    r['has_pen_count'] = int(r['state'] in with_count)

cols = ['state', 'abbreviation', 'instances_2025_26', 'rate_per_million_2025_26', 'top_ten_rate', 'has_pen_count',
        'republican_margin_2024_pp', 'population_acs', 'median_age', 'pct_under_18', 'pct_65_plus', 'pct_female',
        'pct_male', 'pct_hispanic', 'pct_white_nh', 'pct_black_nh', 'pct_asian_nh', 'pct_aian_nh', 'pct_two_plus_nh',
        'pct_hs_grad_25plus', 'pct_bachelors_25plus', 'median_household_income', 'pct_poverty', 'pct_urban_2020',
        'pct_rural_2020']
with open(os.path.join(out, 'state_demographics_2025.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=cols, extrasaction='ignore')
    w.writeheader()
    for r in sorted(rows, key=lambda r: r['state']):
        w.writerow({k: (round(v, 2) if isinstance(v, float) else v) for k, v in r.items() if k in cols})

MEASURES = [
    ('median_age', 'Median age (years)', 'ACS 2025'),
    ('pct_under_18', 'Under 18 (%)', 'ACS 2025'),
    ('pct_65_plus', 'Aged 65 and over (%)', 'ACS 2025'),
    ('pct_female', 'Female (%)', 'ACS 2025'),
    ('pct_white_nh', 'White, not Hispanic (%)', 'ACS 2025'),
    ('pct_hispanic', 'Hispanic or Latino (%)', 'ACS 2025'),
    ('pct_black_nh', 'Black, not Hispanic (%)', 'ACS 2025'),
    ('pct_asian_nh', 'Asian, not Hispanic (%)', 'ACS 2025'),
    ('pct_hs_grad_25plus', 'High school graduate or higher, 25+ (%)', 'ACS 2025'),
    ('pct_bachelors_25plus', "Bachelor's degree or higher, 25+ (%)", 'ACS 2025'),
    ('median_household_income', 'Median household income ($)', 'ACS 2025'),
    ('pct_poverty', 'Below poverty level (%)', 'ACS 2025'),
    ('pct_urban_2020', 'Urban residents (%)', '2020 Census'),
]


def unweighted(group, k):
    return sum(r[k] for r in group) / len(group)


def weighted(group, k):
    pop = sum(r['population_acs'] for r in group)
    return sum(r[k] * r['population_acs'] for r in group) / pop


def perm_p(k, n_top=10, reps=20000, seed=20261117):
    """Share of random 10-state groups whose unweighted mean differs from the other 40
    by at least as much as the observed top-ten difference (two-sided)."""
    vals = [r[k] for r in rows]
    obs = abs(unweighted([r for r in rows if r['top_ten_rate']], k) - unweighted([r for r in rows if not r['top_ten_rate']], k))
    rng = random.Random(seed)
    hits = 0
    for _ in range(reps):
        idx = set(rng.sample(range(50), n_top))
        a = [vals[i] for i in idx]; b = [vals[i] for i in range(50) if i not in idx]
        if abs(sum(a) / len(a) - sum(b) / len(b)) >= obs - 1e-12:
            hits += 1
    return hits / reps


def spearman(xs, ys):
    def ranks(v):
        order = sorted(range(len(v)), key=lambda i: v[i]); rk = [0.0] * len(v); i = 0
        while i < len(v):
            j = i
            while j + 1 < len(v) and v[order[j + 1]] == v[order[i]]: j += 1
            for t in range(i, j + 1): rk[order[t]] = (i + j) / 2 + 1
            i = j + 1
        return rk
    rx, ry = ranks(xs), ranks(ys); n = len(xs)
    mx, my = sum(rx) / n, sum(ry) / n
    num = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
    den = (sum((a - mx) ** 2 for a in rx) * sum((b - my) ** 2 for b in ry)) ** 0.5
    return num / den


T = [r for r in rows if r['top_ten_rate']]; O = [r for r in rows if not r['top_ten_rate']]
C = [r for r in rows if r['has_pen_count']]; Z = [r for r in rows if not r['has_pen_count']]
rates = [r['rate_per_million_2025_26'] for r in rows]
comp = []
for k, label, src in MEASURES:
    comp.append({
        'measure': label, 'source': src,
        'top10_unweighted': unweighted(T, k), 'other40_unweighted': unweighted(O, k),
        'top10_minus_other40': unweighted(T, k) - unweighted(O, k),
        'top10_permutation_p': perm_p(k),
        'top10_pop_weighted': weighted(T, k), 'other40_pop_weighted': weighted(O, k),
        'with_count23_unweighted': unweighted(C, k), 'no_count27_unweighted': unweighted(Z, k),
        'spearman_with_rate_all50': spearman([r[k] for r in rows], rates),
        'top10_min': min(r[k] for r in T), 'top10_max': max(r[k] for r in T),
    })
with open(os.path.join(out, 'group_comparison.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(comp[0].keys()))
    w.writeheader()
    for c in comp:
        w.writerow({k: (round(v, 3) if isinstance(v, float) else v) for k, v in c.items()})

fmt = lambda k, v: f'${v:,.0f}' if 'income' in k else f'{v:.1f}'
L = ['State demographic profile, 2025-26 analysis', '',
     'Sources: ACS 2025 1-year data profiles DP05, DP02, DP03 (all 50 states); 2020 Census DHC table P2 (urban/rural).',
     f'ACS 2025 total population matches the Census 2025 estimates used in the analysis for {50 - len(mismatch)} of 50 states.'
     + (f' Mismatches: {mismatch}' if mismatch else ''),
     'Top ten by 2025-26 rate: ' + ', '.join(r['state'] for r in ranked[:10]), '',
     'Group means are unweighted state averages unless marked weighted. Weighted figures are dominated by',
     'Texas and Florida (about 55 million of the top ten\'s 74 million residents). Median income is averaged',
     'across state medians, which is not a pooled median.', '',
     f'{"Measure":44s} {"Top 10":>10s} {"Other 40":>10s} {"Diff":>8s} {"perm p":>7s} {"23 w/cnt":>9s} {"27 none":>9s} {"rho":>6s}']
for c, (k, _, _) in zip(comp, MEASURES):
    L.append(f'{c["measure"]:44s} {fmt(k, c["top10_unweighted"]):>10s} {fmt(k, c["other40_unweighted"]):>10s} '
             f'{(fmt(k, c["top10_minus_other40"]) if "income" not in k else f"{c["top10_minus_other40"]:+,.0f}"):>8s} '
             f'{c["top10_permutation_p"]:7.3f} {fmt(k, c["with_count23_unweighted"]):>9s} {fmt(k, c["no_count27_unweighted"]):>9s} '
             f'{c["spearman_with_rate_all50"]:6.2f}')
L += ['', 'perm p: share of 20,000 random ten-state groups whose difference from the other forty is at least as large',
      'as the observed one. With 13 measures, a value near 0.05 is expected for about one measure by chance alone.',
      'rho: Spearman rank correlation between the measure and the 2025-26 rate across all 50 states (27 states tie at zero).',
      '', 'This describes the people who live in these states. It does not identify who filed challenges or made',
      'decisions, and it does not show that any characteristic causes bans to be recorded.']
open(os.path.join(out, 'demographics_summary.txt'), 'w', encoding='utf-8').write('\n'.join(L) + '\n')
print('\n'.join(L))
