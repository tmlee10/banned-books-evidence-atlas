BANNED BOOKS: REVISED REPORT AND REPRODUCIBLE ANALYSIS
Revised 1 October 2026 (Asia/Makassar)

Start with Banned_Books_Section_by_Section_Revised.docx.
The requested personal name has been removed from this revised report.

COMPLETED IN THIS REVISION
- Reconstructed all 50 state population, political-affiliation and religion records.
- Calculated 2022–2023 entries per million total residents and raw-count rankings.
- Calculated descriptive Pearson and Spearman correlations with sensitivity comparisons.
- Preserved rounded religion-category ties and documented the political-source mismatch.
- Added tables and a count/rate chart to the revised report.

RUN OFFLINE
1. From core_review, run: python run_review.py
   The default core audit uses the Python standard library.
   Optional figures: pip install -r requirements.txt; python run_review.py --figures
2. From state_reconstruction, run:
   python -m pip install -r requirements.txt
   python complete_state_analysis.py
   Inputs are bundled; no download or private account is needed for calculation.
3. Compare outputs/validation.json and outputs/descriptive_correlations.csv with
   the report. Each state source must match 50 distinct states; entry total is 3362.

SOURCE YEARS AND INTERPRETATION
PEN entries: 2022–2023. Census total residents: July 2022.
Gallup political shares: 2017. Pew religious shares: 2014.
These descriptive associations are not causal estimates or current affiliations.
States without index entries are coded as zero recorded entries, not proof of no bans.
Pew asterisks remain missing numeric values with original tokens preserved.
Acquisition metadata records full download hashes; source_register.json records
hashes of the bundled numerical extracts actually used by the analysis.

STILL REQUIRES SOURCE RECORDS
- Original 2021–2022 training table and dated chapter counts for the historical regression.
- Survey records/codebook for gender, sexuality, age and individual affiliations.
- NCES matches, enrollment, restriction dates and outcomes for district analysis.
- Detailed 2024–2025 index export for latest event-level analysis.
The old negative predictions and Ohio/Idaho claims remain historical outputs,
not validated forecasts. This revision does not refit that model or deploy the site.

CONTENTS
core_review: corrected earlier counting audit, tests, inputs and historical visuals.
state_reconstruction: new analysis, numerical source extracts, tables and chart.
reference/Original_Banned_Books_Report.docx: unedited source supplied by the user;
retained to make the comparison inspectable. It is not the revised report.
SHA256SUMS.txt: exact package file hashes.
