# Banned books reproducibility review

This corrected package distinguishes calculations from a retained event workbook,
arithmetic on supplied published summaries, and historical results transcribed
from an earlier report. They are not interchangeable.

## Run the review

Extract the ZIP, open a terminal in this folder and run with Python 3.10 or later:

```text
python run_review.py
```

No additional packages or network access are needed for the core review. On
Windows, `py -3 run_review.py` is an alternative. Outputs are in `results/`.
The runner stops if a test or script fails.

To also regenerate historical figures, install the optional dependency in your
own Python environment and run:

```text
python -m pip install -r requirements.txt
python run_review.py --figures
```

The figure workflow was tested with matplotlib 3.10.8. Platform-dependent fonts
may affect image appearance, not the counting rules.

## What is reproduced

- PEN 2022–2023: 3,362 event rows across 33 states in the retained workbook.
  There are 3,361 nonblank-title rows. Texas has 625 event rows, including one
  with a blank title; counting only populated titles gives 624.
- Both sheets are checked separately and complete event records compared as
  multisets. Only the Author and Title view is aggregated. Combining the two
  views would double-count the index.
- The State and District sheet starts with an event in row 1. The Author and
  Title sheet has introductory text and a header. The reader does not apply
  one common header offset to both sheets.
- Supplied 2024–2025 summary values sum to 6,870. Florida, Texas and Tennessee
  sum to 5,707. Their share is 83.1% of all 6,870 instances and 90.9% of the
  6,280 remaining after the 590 DoDEA instances are excluded.

The blank-title entry is retained to show the supplied index, not because its
title has been verified. Both counting choices remain visible. Nonblank-title
rows are not unique titles. Identical repeated records, if any, are reported in
audit.json rather than silently removed.

## Inspect the results

- `results/reconciliation.csv`: values and the basis for each calculation.
- `results/state_counts_2022_2023.csv`: all 50 states, event-row and nonblank-title
  counts, and an explicit no-records status.
- `results/events_2022_2023_for_audit.csv`: counted rows with source coordinates.
  Dates remain Excel serials or source text, not inferred months.
- `results/blank_title_source_rows.csv`: incomplete entry in both sheet views.
- `results/audit.json`: sheet comparison, checksum and unresolved limitations.
- `results/run_log.txt`: archived clean-run log. Rerunning does not automatically
  refresh this archived log.
- `Current_Python_Code.txt`: readable listings of the corrected code.

## What is not reproduced

The 2024–2025 event file is absent. The 6,870 total and state breakdown are
summary inputs, not an independently reconstructed event count. No district
regression, causal model, survey analysis or new forecast is fitted.

The original regression CSV, Religion.xlsx, partisan.xlsx and respondent survey
and codebook are missing. Historical predictions and five-state affiliation
labels are transcriptions. Redrawing a historical result does not reproduce its
model. Eighteen negative historical predictions remain invalid as counts and
are not silently replaced with zero. Ohio's zero index entries do not establish
that no bans occurred there.

The earlier study's 2,535 rows and published 2021–2022 total of 2,532 instances
remain unresolved without the original input. Do not change either solely to
make the totals agree.

## Correction scope

Read CORRECTION_NOTICE.txt before relying on earlier documents. Prior documents
and QGIS material from earlier submissions have not
been rewritten or newly validated. The supplied QGIS report mentions
scripts/run_in_qgis.py, but that script was absent from its archive. This review
does not rebuild all QGIS layers or report findings.

The inherited static website is a prior snapshot. Its prose does not update
automatically from these calculations. This package does not deploy or change
the public website. Corrected provenance labels distinguish historical report
transcriptions from the current PEN summary.

## Research safeguards retained

RQ3. What happened when a district reviewed a challenged book with input from librarians and local residents?

- Each district name will be checked against the NCES directory and assigned one NCES identification number. If the match is uncertain, the record will remain unresolved until it can be checked manually.
- Every restriction will be assigned to a school year. A month will be recorded only when the source provides enough detail; otherwise, the record will show that the date is approximate.
- Exact and possible duplicate records will be listed before any records are combined. Restrictions ordered at the state level will not be merged with actions taken by individual districts.
- The yearly, state and district totals will be recalculated and compared with PEN America’s published figures. Differences will be investigated and recorded.
- Missing information and unavailable sources will be reported for each state and school year.
- A forecasting model will use only information that existed before the period being predicted.
